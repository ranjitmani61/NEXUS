"""Guardrails for a deliberately simple trained attention control, not pretrained traces."""
import math
import numpy as np
import torch
from g5_learned_control_audit import N, PAGE, train_lookup, run


def test_learned_attention_is_locally_verified():
    torch.set_num_threads(1)
    pre, post, loss=train_lookup(21,steps=500)
    assert pre.shape == post.shape == (128,128)
    assert np.isfinite(pre).all() and np.isfinite(post).all()
    assert np.max(np.abs(pre.sum(-1)-1))<2e-7
    assert np.max(np.abs(post.sum(-1)-1))<2e-7
    assert np.mean(post.argmax(-1)==np.arange(N))>0.99
    assert np.mean(pre.argmax(-1)==np.arange(N))<0.10
    assert loss<0.01


def test_oracle_is_fragile_to_diffusion():
    torch.set_num_threads(1)
    r=run(seed=21,steps=500,sample_per_seed=16)['regimes']
    assert r['learned_attention']['median_mass_oracle_page_fraction'] == PAGE/N
    assert r['untrained_control']['median_mass_oracle_page_fraction'] == 1.0
    assert r['learned_plus_2pct_uniform']['median_mass_oracle_page_fraction'] > PAGE/N
    assert r['learned_plus_20pct_uniform']['median_mass_oracle_page_fraction'] == 1.0
    assert r['learned_attention']['median_task_l2_relative_error'] < .001
    assert r['learned_plus_20pct_uniform']['median_task_l2_relative_error'] > .1
