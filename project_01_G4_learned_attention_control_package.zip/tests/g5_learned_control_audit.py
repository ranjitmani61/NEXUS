#!/usr/bin/env python3
"""Controlled learned-query attention diagnostic (NOT pretrained LLM evidence).

Trains a 128-address, single-head softmax lookup table to attend to its address.
Measures oracle page selection on new value matrices; includes untrained and
artificially diffused controls. Actual attention is always computed densely.
No hardware or model-level latency/energy savings can be inferred.
"""
from __future__ import annotations
import argparse, hashlib, json, math, os, platform, sys
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0,str(Path(__file__).resolve().parent))
from g5_trace_oracle import evaluate_one

N=128
D=24
VD=16
PAGE=16
EPS=0.02
SEEDS=(21,37,53)


def train_lookup(seed, steps=500, lr=.12):
    torch.manual_seed(seed)
    q=torch.nn.Parameter(torch.randn((N,D))*0.25)
    k=torch.nn.Parameter(torch.randn((N,D))*0.25)
    optimizer=torch.optim.Adam([q,k],lr=lr)
    targets=torch.arange(N)
    with torch.no_grad():
        before=((q@k.T)/math.sqrt(D)).detach().clone()
    for _ in range(steps):
        optimizer.zero_grad()
        scores=q@k.T/math.sqrt(D)
        loss=F.cross_entropy(scores,targets)
        loss.backward()
        optimizer.step()
    with torch.no_grad():
        after=(q@k.T/math.sqrt(D)).detach().clone()
        return (before.softmax(-1).numpy().astype('float64'),
                after.softmax(-1).numpy().astype('float64'),
                float(loss.item()))


def run(seed=21, steps=500, sample_per_seed=128):
    prior, trained, loss=train_lookup(seed,steps)
    rng=np.random.default_rng(seed+2001)
    # Unseen values are redrawn on every test; only address matching trained.
    idx=rng.integers(0,N,size=sample_per_seed)
    regimes={
        'untrained_control':prior,
        'learned_attention':trained,
        'learned_plus_2pct_uniform':0.98*trained+0.02/N,
        'learned_plus_20pct_uniform':0.8*trained+0.2/N,
        'learned_plus_50pct_uniform':0.5*trained+0.5/N,
    }
    out={}
    for regime, p in regimes.items():
        rows=[]
        for addr in idx:
            values=rng.standard_normal((N,VD))
            w=p[int(addr)]
            r=evaluate_one(w,values,PAGE,EPS)
            # An independent *task-level* check: the output vs addressed value.
            y=w@values
            target=values[int(addr)]
            target_norm=max(np.linalg.norm(target),1e-12)
            task_error=float(np.linalg.norm(y-target)/target_norm)
            rows.append((r['oracle_mass_fraction'],r['oracle_exact_score_value_fraction'],
                         r['greedy_hindsight_fraction'],r['oracle_exact_score_value_true_error'],
                         float(w[int(addr)]),task_error))
        a=np.asarray(rows)
        out[regime]={
            'queries':len(rows),
            'mean_target_probability':float(a[:,4].mean()),
            'median_mass_oracle_page_fraction':float(np.median(a[:,0])),
            'median_value_oracle_page_fraction':float(np.median(a[:,1])),
            'median_hindsight_page_fraction':float(np.median(a[:,2])),
            'median_task_l2_relative_error':float(np.median(a[:,5])),
            'max_numerically_checked_certificate_error':float(a[:,3].max()),
            'mass_one_page_rate':float(np.mean(a[:,0]==1/(N/PAGE))),
            'value_one_page_rate':float(np.mean(a[:,1]==1/(N/PAGE))),
            'no_realizable_speedup':'All softmax attention and V information computed before page selection'
        }
    return {'seed':seed,'training_final_cross_entropy':loss,
            'trained_exact_address_accuracy':float(np.mean(trained.argmax(axis=-1)==np.arange(N))),
            'untrained_exact_address_accuracy':float(np.mean(prior.argmax(axis=-1)==np.arange(N))),
            'regimes':out}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,default=Path('results/g5_learned_control_audit.json'))
    p.add_argument('--steps',type=int,default=500)
    p.add_argument('--queries',type=int,default=128)
    a=p.parse_args()
    if a.steps<1 or a.queries<1: p.error('steps and queries must be positive')
    torch.set_num_threads(1)
    runs=[run(seed,a.steps,a.queries) for seed in SEEDS]
    result={'metadata':{
        'timestamp':'2026-11-03', 'classification':'trained small synthetic attention task; NOT pretrained LLM',
        'engine':'PyTorch CPU', 'torch':torch.__version__, 'numpy':np.__version__,
        'architecture':'128-slot learned address-to-address single-head attention; no full transformer',
        'train_task':'Cross-entropy to a known random-access address, trained on all 128 addresses',
        'evaluation':'Fresh random Gaussian value vectors; address indices resampled',
        'no_independent_training_distribution':'Address keys are seen during training; values are independent at evaluation',
        'seeds':list(SEEDS), 'token_count':N, 'query_dim':D,'value_dim':VD,
        'page_size':PAGE, 'error_tolerance':EPS,'steps':a.steps,'samples_per_seed':a.queries,
        'limit':'Trained toy, oracle-only page counts, not G5 and not physical benefits',
        'no_external_weights':True, 'no_paid_compute':True
        },'runs':runs}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'training_losses':[r['training_final_cross_entropy'] for r in runs],
        'median_mass_by_regime':{reg:float(np.median([r['regimes'][reg]['median_mass_oracle_page_fraction'] for r in runs]))
        for reg in runs[0]['regimes']}},indent=2))
    print('saved',a.output)

if __name__=='__main__':
    main()
