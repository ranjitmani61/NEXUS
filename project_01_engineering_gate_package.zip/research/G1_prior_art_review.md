# G1 Prior-art Review — Project 01

**Version/date:** 1.0 / 2026-11-03  
**Gate status:** IN PROGRESS — technical literature screened; patents/implementation details not exhaustively reviewed.  
**Lens:** A11 prior-art investigation, A1 architecture, A2 math, A3 AI systems.

The starting reference prototype screens whole KV pages using the center/radius upper bound `(q·center + ||q||*radius)/sqrt(d)` and uses a softmax-tail mass certificate to decide when to stop. **Do not call this formula a discovery.**

| Work (year) | Source | Verified published/author-described mechanism | Novelty implication |
|---|---|---|---|
| FlashAttention-2 (2024, ICLR) | https://proceedings.iclr.cc/paper_files/paper/2024/hash/98ed250b203d1ac6b24bbcf263e3d4a7-Abstract-Conference.html | Exact dense attention optimized for parallelism and GPU memory hierarchy | Essential dense implementation reference |
| QUEST (2024, ICML) | https://proceedings.mlr.press/v235/tang24l.html | Tracks per-KV-page min/max keys; estimates page importance using query; selectively loads pages | Query-aware KV page selection is pre-existing |
| SparQ Attention (2024, ICML) | https://proceedings.mlr.press/v235/ribar24a.html | Query-aware selective KV fetching for bandwidth-efficient inference | Selective cache fetching already established |
| Native Sparse Attention (2025, ACL) | https://aclanthology.org/2025.acl-long.1126/ | Hardware-aligned, trained dynamic hierarchical sparse attention | Hardware-aware sparse execution is established |
| BLASST (2026, MLSys) | https://proceedings.mlsys.org/paper_files/paper/2026/hash/c6ee784cbe46d854843e4c883a3321ef-Abstract-Conference.html | Dynamic threshold to skip low-contribution blocks; optimized kernels | Threshold/fallback research must be compared to working optimized kernels |
| Elastic Threshold Attention (2026, Google Research) | https://research.google/pubs/elastic-threshold-attention-learned-contextual-sparsity-for-long-context-decoding/ | Training-time gating, cached geometric-probabilistic screening bounds, fused kernel | Even geometric-bound screening has close modern competitors |
| Certified Block Screening for Adaptive Long-Context Attention (Apr 2026 preprint) | https://www.researchgate.net/publication/404906062_Certified_Block_Screening_for_Adaptive_Long-Context_Attention | Reports **same center-radius Cauchy–Schwarz page bound** and failure on single-token retrieval | Direct overlap; **baseline is not novel**. Preprint not established as peer reviewed |
| Runtime-Certified Bounded-Error Quantized Attention (May 2026 preprint) | https://arxiv.org/abs/2605.20868 | Runtime certification, adaptive precision and fallback | Certification-driven attention is already present |
| Certified Sparse Attention via Perturbed Retrieval (Oct 2026 preprint) | https://arxiv.org/abs/2610.24991 | Perturbed retrieval with certified sparse attention; reports CPU decoding gains under study assumptions | Certificates + selective work are also competitive research topics |
| Efficiently Approximating Attention Is Hard (Sep 2026 preprint) | https://arxiv.org/abs/2609.37261 | Conditional theoretical limitations on input-uniform subquadratic attention approximations | No claim of universally strong screening; special input distributions may still benefit |

### Outcome

- **Disconfirmed:** “Center/radius page screening + a runtime certificate constitutes a new computing mechanism.” This is **not defensible** in light of close published/preprint work.
- **Not yet established:** Any new microarchitecture, physical dataflow, certified finite-precision mechanism or favorable energy/latency/area tradeoff.
- **Open research direction, not an invention claim:** Can a physically specified memory controller reduce **end-to-end** latency/energy by scheduling metadata/blocks *better than current software kernels and near-memory designs*, while preserving useful quality? Must first research hardware and patents; this could also be existing prior art.
- **Next G1 action:** Detailed side-by-side study of closest source code and claims; search patents and deployed chips; isolate a distinct, testable mechanism **before** using the word novel.

External work's speedups and accuracies, if mentioned, are **authors' claims**, not replications by this project. URLs identify sources; no originality or freedom-to-operate opinion is given.
