import sys
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).parent))
from g2_photonic_signed_reduction import (
    balanced_signed_input, sample_measurement, error_radius_chebyshev,
    certified_accept, required_photons_chebyshev, simulation)

@pytest.mark.parametrize('k',[1.,2.,10.,100.,1000.])
def test_condition(k):
    a=balanced_signed_input(k)
    assert np.isclose(np.abs(a).sum(),1.)
    assert np.isclose(a.sum(),1/k)

def test_invalid_condition():
    for v in [0, -1, float('inf')]:
        with pytest.raises(ValueError): balanced_signed_input(v)

def test_poisson_unbiased_variance():
    rng=np.random.default_rng(1)
    x=balanced_signed_input(10)
    n=1000
    y=sample_measurement(x,n,rng,trials=80000)
    assert abs(y.mean()-x.sum()) < .003
    assert abs(np.var(y)-1/n) < 0.000025

def test_gain_bias():
    rng=np.random.default_rng(2)
    y=sample_measurement(balanced_signed_input(100),50000,rng,gain_mismatch=.02,trials=100000)
    assert abs(y.mean()-(.01+.02))<.0008

def test_required_counts_quadratic():
    assert np.isclose(required_photons_chebyshev(10,.001,.01),100*required_photons_chebyshev(1,.001,.01))

def test_guard_accepts_ideal_exact_when_possible():
    assert certified_accept(1.0,1.0,1e8,1e-3,0.01)
    assert not certified_accept(0.1,1.0,1e8,1e-3,0.01)

def test_gain_bound_rejects():
    assert certified_accept(1.02,1.0,1e8,1e-3,0.01,0)
    assert not certified_accept(1.02,1.0,1e8,1e-3,0.01,.02)

def test_guard_does_not_depend_on_truth():
    # Acceptance guard only sees observed sum, L1 and declared noise budget.
    a=certified_accept(np.array([.1,.5,1]),1,1e8,1e-3,.01)
    assert a.tolist()==[False,True,True]

@pytest.mark.parametrize('params',[(0,1,1e8,.001,.01),(11,1,1e8,.001,.01),(41,2,1e8,.001,.01)])
def test_idealized_probability_bound_empirical(params):
    seed,k,n,risk,tol=params
    rng=np.random.default_rng(seed)
    y=sample_measurement(balanced_signed_input(k),n,rng,trials=25000)
    truth=1/k
    accepted=certified_accept(y,1,n,risk,tol)
    assert not np.any(accepted & (abs(y-truth)>tol*truth))

def test_zero_all_inputs():
    r=sample_measurement(np.zeros(5),1000,np.random.default_rng(1),trials=2)
    assert r.tolist()==[0.,0.]

def test_invalid_measurement():
    rng=np.random.default_rng(1)
    for bad in [np.array([np.nan]),np.zeros((2,2))]:
        with pytest.raises(ValueError):sample_measurement(bad,1e4,rng)
    with pytest.raises(ValueError):sample_measurement([1],0,rng)
    with pytest.raises(ValueError):sample_measurement([1],1e5,rng,gain_mismatch=1)

def test_reproducible():
    x=simulation(seed=12,repetitions=20)
    y=simulation(seed=12,repetitions=20)
    assert x==y

def test_false_confidence_under_drift():
    r=simulation(seed=21,repetitions=300)
    assert r['mismatch_test']['uncorrected_false_certifications']>0
    assert r['mismatch_test']['corrected_false_certifications']==0
