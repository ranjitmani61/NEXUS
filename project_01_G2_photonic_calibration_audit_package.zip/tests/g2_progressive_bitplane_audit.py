"""G2 feasibility study: interval-certified progressive weight-bitplane reading.

The method is prior-art-adjacent and is NOT claimed novel. The certificate
preserves the argmax of an *INT8 quantized linear classifier*, not necessarily
of the underlying floating-point classifier. Packed bitplanes are the only
weights read by the candidate routine during inference.
"""
from __future__ import annotations
import json, os, platform, time
from collections import Counter
from pathlib import Path
import numpy as np

OUT = Path('/mnt/data/results/g2_progressive_bitplane.json')


def pack_planes(w: np.ndarray) -> tuple[bytes, ...]:
    w = np.asarray(w)
    assert w.ndim == 2 and np.issubdtype(w.dtype, np.integer)
    assert np.all(w >= -128) and np.all(w <= 127)
    unsigned = w.astype(np.int16) + 128
    return tuple(np.packbits(((unsigned >> p) & 1).astype(np.uint8).ravel(), bitorder='big').tobytes()
                 for p in range(7, -1, -1))


def progressive_argmax(planes: tuple[bytes, ...], shape: tuple[int, int],
                       x: np.ndarray, b: np.ndarray) -> tuple[int, int]:
    """Return (certified class, bitplanes read), using only actually-read planes.

    All score arithmetic is exact in int64 assuming dimensions/inputs small enough
    to avoid int64 overflow; an implementation must enforce that condition.
    """
    k_classes, dim = shape
    x = np.asarray(x, dtype=np.int64)
    b = np.asarray(b, dtype=np.int64)
    assert x.shape == (dim,) and b.shape == (k_classes,)
    assert len(planes) == 8
    assert np.sum(np.abs(x.astype(object))) * 255 + np.max(np.abs(b.astype(object))) < np.iinfo(np.int64).max
    prefix = np.zeros(shape, dtype=np.int64)
    negative_sum = int(np.maximum(-x, 0).sum())
    positive_sum = int(np.maximum(x, 0).sum())
    for k, plane in enumerate(planes, 1):
        bit = np.unpackbits(np.frombuffer(plane, dtype=np.uint8), bitorder='big', count=k_classes*dim)
        prefix = (prefix << 1) + bit.reshape(shape).astype(np.int64)
        remaining = 8-k
        remainder_max = (1 << remaining) - 1
        low_weight = (prefix << remaining) - 128
        partial = low_weight @ x + b
        lower = partial - remainder_max * negative_sum
        upper = partial + remainder_max * positive_sum
        champion = int(np.argmax(lower))
        competitors = np.arange(k_classes) != champion
        if np.all(lower[champion] > upper[competitors]):
            return champion, k
    return int(np.argmax(partial)), 8


def baseline_class(w: np.ndarray, x: np.ndarray, b: np.ndarray) -> int:
    return int(np.argmax(w.astype(np.int64) @ np.asarray(x, np.int64) + b.astype(np.int64)))


def digits_control(seed: int):
    from sklearn.datasets import load_digits
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    ds = load_digits()
    Xtr, Xte, ytr, yte = train_test_split(ds.data, ds.target, test_size=0.3, random_state=seed, stratify=ds.target)
    clf = LogisticRegression(max_iter=500, solver='lbfgs', C=1.0)
    # Input pixels are integers in [0,16].
    clf.fit(Xtr, ytr)
    training_iterations = clf.n_iter_.tolist()
    scale = float(np.max(np.abs(clf.coef_)) / 127)
    w = np.clip(np.rint(clf.coef_/scale), -127, 127).astype(np.int16)
    b = np.rint(clf.intercept_/scale).astype(np.int64)
    Xi = np.rint(Xte).astype(np.int64)
    planes = pack_planes(w)
    ks=[]; labels=[]; dense=[]
    t0=time.perf_counter()
    for x in Xi:
        label, k=progressive_argmax(planes,w.shape,x,b)
        ks.append(k);labels.append(label)
    prog_t=time.perf_counter()-t0
    t0=time.perf_counter()
    for x in Xi:
        dense.append(baseline_class(w,x,b))
    dense_t=time.perf_counter()-t0
    yhat_q=np.asarray(dense)
    assert np.array_equal(labels,dense), 'Candidate must preserve quantized argmax'
    def approx_k(k: int):
        # Uncertified midpoint approximation using only first k planes.
        r=8-k
        uw=w.astype(np.int64)+128
        wmid=((uw >> r) << r)-128+(2**r-1)//2
        preds=np.argmax(Xi @ wmid.T + b,axis=1)
        return {'test_accuracy':float(np.mean(preds==yte)),
                'agreement_with_int8':float(np.mean(preds==yhat_q))}
    return {
        'seed':seed,'training_iterations':training_iterations,'n_test':len(Xte),'model':'trained sklearn 10-class logistic regression on bundled digits dataset, not pretrained LLM',
        'model_input_dim':w.shape[1], 'outputs':w.shape[0], 'quantizer':'symmetric per-tensor INT8 weights; INT64 quantized bias; integer pixels',
        'fp64_model_accuracy':float(np.mean(clf.predict(Xte)==yte)),
        'int8_model_accuracy':float(np.mean(yhat_q==yte)),
        'candidate_agreement_with_int8':float(np.mean(np.asarray(labels)==yhat_q)),
        'mean_bits_read':float(np.mean(ks)), 'median_bits_read':float(np.median(ks)),
        'fraction_of_weight_bytes_read_ideal':float(np.mean(ks)/8),
        'bitplanes_distribution':dict(sorted(Counter(ks).items())),
        'approx_4_planes':approx_k(4),'approx_6_planes':approx_k(6),
        'python_candidate_seconds':prog_t,'python_dense_seconds':dense_t,
        'candidate_vs_dense_cpu_ratio':prog_t/dense_t,
        'weight_bytes_full':int(w.size), 'weight_bytes_per_plane':int((w.size+7)//8),
    }


def synthetic_control(kind: str, seed: int):
    rng=np.random.default_rng(seed)
    classes,dim=10,64
    w=rng.integers(-128,128,(classes,dim),dtype=np.int16)
    b=rng.integers(-500,501,classes,dtype=np.int64)
    if kind=='tied':
        w=np.tile(w[:1],(classes,1));b=np.zeros(classes,dtype=np.int64)
    elif kind=='huge_bias':
        b=np.zeros(classes,dtype=np.int64); b[0]=250000
    planes=pack_planes(w)
    ks=[]
    for i in range(128):
        x=rng.integers(-16,17,dim,dtype=np.int64)
        pred,k=progressive_argmax(planes,w.shape,x,b)
        assert pred == baseline_class(w,x,b)
        ks.append(k)
    return {'kind':kind,'seed':seed,'n':len(ks),'mean_bits_read':float(np.mean(ks)),
            'median_bits_read':float(np.median(ks)),
            'distribution':dict(sorted(Counter(ks).items()))}


def randomized_property(seed: int=2026,n: int=3000):
    rng=np.random.default_rng(seed)
    hist=Counter()
    for i in range(n):
        classes=int(rng.integers(2,16));dim=int(rng.integers(1,81))
        w=rng.integers(-128,128,(classes,dim),dtype=np.int16)
        x=rng.integers(-32,33,dim,dtype=np.int64)
        b=rng.integers(-1000,1001,classes,dtype=np.int64)
        if i%31==0: w[:]=w[:1];b[:]=0
        if i%37==0: x[:]=0
        p,k=progressive_argmax(pack_planes(w),w.shape,x,b)
        ref=baseline_class(w,x,b)
        if p!=ref:
            raise AssertionError(f'certificate violation seed={seed} case={i} got={p} expected={ref}')
        hist[k]+=1
    return {'cases':n,'violations':0,'bitplanes_distribution':dict(sorted(hist.items()))}


def main():
    d={
        'date':'2026-11-03','claim':'Exploratory G2 feasibility only; prior-art-adjacent progressive-precision computation',
        'environment':{'python':platform.python_version(),'numpy':np.__version__, 'platform':platform.platform()},
        'property_checks':randomized_property(),
        'digits':[digits_control(seed) for seed in (17,29)],
        'synthetic':[synthetic_control(kind,seed) for kind in ('random','tied','huge_bias') for seed in (17,29)],
        'assumptions':['Only model-weight bitplane traffic counted; exclude activation, bias, metadata, DRAM burst granularity, control and chip energy',
                       'Certified exact INT8 argmax, not preservation of FP64 classifier predictions',
                       'Model does not exploit bitplane compression; packed model storage is the same full byte count as INT8',
                       'Python timing highly implementation-dependent; no hardware speedup implied',
                       'No pretrained LLM data or accelerator measurements'],
    }
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps({'property_checks':d['property_checks'], 'digits':d['digits'],'synthetic':d['synthetic']},indent=2))

if __name__=='__main__': main()
