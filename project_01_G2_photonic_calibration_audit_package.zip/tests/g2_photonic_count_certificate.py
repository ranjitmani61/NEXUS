"""Idealized Poisson readout confidence experiment, not a physical photonic device.

Full specifications: specs/G2_self_certifying_photonic_readout.md
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
from scipy.stats import chi2

ALPHA = 100_000_000.0
DELTA = .001
EPS = .01
N = 1000
SEEDS = [20261113, 20261114, 20261115]
KAPPAS = [1, 2, 10, 100, 1000]


def garwood(counts, beta):
    """Marginal two-sided Poisson CI, coverage >=1-beta for fixed mean."""
    counts = np.asarray(counts)
    if np.any(counts < 0) or np.any(counts != np.floor(counts)):
        raise ValueError('counts must be nonnegative integers')
    if not (0 < beta < 1):
        raise ValueError('bad risk allocation')
    lo = np.zeros_like(counts, dtype=float)
    pos = counts > 0
    lo[pos] = .5*chi2.ppf(beta/2, 2*counts[pos])
    hi = .5*chi2.ppf(1-beta/2, 2*(counts+1))
    return lo, hi


def signed_interval(cp, cm, alpha, delta, gain_bound=0., pilot_pos=None, pilot_neg=None, exposure=None):
    cp=np.asarray(cp)
    cm=np.asarray(cm)
    if cp.shape != cm.shape or alpha <= 0:
        raise ValueError('shapes and alpha')
    pilot = pilot_pos is not None or pilot_neg is not None or exposure is not None
    if pilot:
        if pilot_pos is None or pilot_neg is None or exposure is None or exposure <= 0:
            raise ValueError('paired positive pilot exposure required')
        if np.asarray(pilot_pos).shape != cp.shape or np.asarray(pilot_neg).shape != cp.shape:
            raise ValueError('pilot shape mismatch')
        d_l, d_u=garwood(cp, delta/4)
        m_l, m_u=garwood(cm, delta/4)
        gpl,gpu=garwood(np.asarray(pilot_pos),delta/4)
        gml,gmu=garwood(np.asarray(pilot_neg),delta/4)
        gpl,gpu=gpl/exposure,gpu/exposure
        gml,gmu=gml/exposure,gmu/exposure
        gph=np.asarray(pilot_pos,dtype=float)/exposure
        gmh=np.asarray(pilot_neg,dtype=float)/exposure
        hat=np.full(cp.shape, np.nan, dtype=float)
        valid=(gpl>0)&(gml>0)&(gph>0)&(gmh>0)
        np.divide(cp/alpha,gph,out=hat,where=valid)
        tmp=np.zeros_like(hat)
        np.divide(cm/alpha,gmh,out=tmp,where=valid)
        hat[valid]-=tmp[valid]
    else:
        if not (0<=gain_bound<1):
            raise ValueError('gain bound must be within [0,1)')
        d_l,d_u=garwood(cp,delta/2)
        m_l,m_u=garwood(cm,delta/2)
        gpl=gml=1-gain_bound
        gpu=gmu=1+gain_bound
        hat=(cp.astype(float)-cm.astype(float))/alpha
        valid=np.ones(cp.shape,dtype=bool)
    with np.errstate(divide='ignore', invalid='ignore'):
        plo=d_l/(alpha*gpu)
        phi=d_u/(alpha*gpl)
        mlo=m_l/(alpha*gmu)
        mhi=m_u/(alpha*gml)
    lo=plo-mhi
    hi=phi-mlo
    lo=np.where(valid,lo,-np.inf)
    hi=np.where(valid,hi,np.inf)
    return hat, lo, hi


def admission(hat,lo,hi,eps=EPS):
    if not (0<eps<1):
        raise ValueError('eps 0<eps<1')
    h=np.asarray(hat,dtype=float)
    lo=np.asarray(lo,dtype=float)
    hi=np.asarray(hi,dtype=float)
    good=np.isfinite(h)&np.isfinite(lo)&np.isfinite(hi)&(lo<=hi)
    positive=good&(h>0)&(lo>=h/(1+eps))&(hi<=h/(1-eps))
    negative=good&(h<0)&(lo>=h/(1-eps))&(hi<=h/(1+eps))
    return positive|negative


def evaluate(seed, n=N, alpha=ALPHA, delta=DELTA, eps=EPS):
    rng=np.random.default_rng(seed)
    results=[]
    for name,h,exposure,drift in [
        ('known_gain_oracle',0.,None,0.),
        ('blind_drift_unsafe',0.,None,.02),
        ('bounded_drift',.02,None,.02),
        ('pilot_1e6',None,1_000_000.,.02),
        ('pilot_1e8',None,100_000_000.,.02),
        ('stale_pilot_unsafe',None,100_000_000.,.02),
    ]:
        for k in KAPPAS:
            s=1./k
            p=(1+s)/2
            m=(1-s)/2
            gp=1+drift
            gm=1-drift
            data_gp=gp*(1.02 if name=='stale_pilot_unsafe' else 1.0)
            data_gm=gm*(1.02 if name=='stale_pilot_unsafe' else 1.0)
            cp=rng.poisson(alpha*data_gp*p,n)
            cm=rng.poisson(alpha*data_gm*m,n)
            if exposure:
                rp=rng.poisson(exposure*gp,n)
                rm=rng.poisson(exposure*gm,n)
                hat,lo,hi=signed_interval(cp,cm,alpha,delta,pilot_pos=rp,pilot_neg=rm,exposure=exposure)
            else:
                hat,lo,hi=signed_interval(cp,cm,alpha,delta,gain_bound=h)
            admit=admission(hat,lo,hi,eps)
            err=np.abs(hat-s)/abs(s)
            cover=(lo<=s)&(s<=hi)
            false=admit&(err>eps)
            results.append({
                'path':name,'kappa':k,'samples':int(n),
                'admission_pct':round(100*np.mean(admit),3),
                'false_certificates':int(np.sum(false)),
                'interval_coverage_pct':round(100*np.mean(cover),3),
                'actual_accuracy_pct':round(100*np.mean(err<=eps),3),
                'relative_rmse_pct':round(100*np.sqrt(np.mean(((hat-s)/s)**2)),3),
                'ideal_expected_detected_photons_per_sample':int(round(alpha*(data_gp*p+data_gm*m)+ (0 if exposure is None else 2*exposure))),
                'ideal_pilot_photons_per_sample':int(round(0 if exposure is None else 2*exposure)),
            })
    return results


def summarize(rows):
    agg=[]
    for name in dict.fromkeys(r['path'] for r in rows):
        selected=[r for r in rows if r['path']==name]
        agg.append({'path':name,
            'admission_pct':round(sum(r['admission_pct'] for r in selected)/len(selected),3),
            'false_certificates':sum(r['false_certificates'] for r in selected),
            'n':sum(r['samples'] for r in selected),
            'ideal_mean_detected_photons_per_sample':int(round(np.mean([r['ideal_expected_detected_photons_per_sample'] for r in selected]))),
            'pilot_photons_per_sample':selected[0]['ideal_pilot_photons_per_sample']})
    return agg


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',default='/mnt/data/results/g2_photonic_count_certificate.json')
    args=parser.parse_args()
    rows=[]
    for seed in SEEDS:
        rows.extend([{'seed':seed,**r} for r in evaluate(seed)])
    data={'status':'synthetic ideal Poisson model; no measured hardware',
          'protocol':'specs/G2_self_certifying_photonic_readout.md',
          'seeds':SEEDS,'n_per_condition_per_seed':N,
          'alpha':ALPHA,'eps':EPS,'delta':DELTA,
          'aggregate':summarize(rows),'by_kappa_seed':rows}
    out=Path(args.output)
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(data,indent=2))
    print(json.dumps(data['aggregate'],indent=2))
    print('saved',out)

if __name__=='__main__':
    main()
