import numpy as np
import pytest
from g2_progressive_bitplane_audit import pack_planes, progressive_argmax,baseline_class

@pytest.mark.parametrize('classes,dim,seed', [(2,1,1),(3,7,2),(10,64,3),(11,129,4)])
def test_roundtrip_prediction(classes,dim,seed):
    rng=np.random.default_rng(seed)
    for j in range(70):
        w=rng.integers(-128,128,(classes,dim),dtype=np.int16)
        x=rng.integers(-16,17,dim,dtype=np.int64)
        b=rng.integers(-500,501,classes,dtype=np.int64)
        guess,k=progressive_argmax(pack_planes(w),w.shape,x,b)
        assert 1<=k<=8
        assert guess==baseline_class(w,x,b)


def test_identical_classes_requires_all_planes():
    w=np.ones((3,8),dtype=np.int16)*(-128)
    x=np.ones(8,dtype=np.int64)
    b=np.zeros(3,dtype=np.int64)
    guess,k=progressive_argmax(pack_planes(w),w.shape,x,b)
    assert guess==0 and k==8


def test_large_bias_can_terminate():
    w=np.zeros((3,8),dtype=np.int16)
    x=np.ones(8,dtype=np.int64)
    b=np.array([10000,0,0],dtype=np.int64)
    guess,k=progressive_argmax(pack_planes(w),w.shape,x,b)
    assert guess==0 and k==1


def test_zero_input_bias_only():
    w=np.arange(-128, -104,dtype=np.int16).reshape(3,8)
    x=np.zeros(8,dtype=np.int64)
    b=np.array([3,1,2],dtype=np.int64)
    guess,k=progressive_argmax(pack_planes(w),w.shape,x,b)
    assert guess==0 and k==1


def test_signed_extremes():
    w=np.array([[-128,127],[127,-128]],dtype=np.int16)
    x=np.array([10,-10],dtype=np.int64)
    b=np.zeros(2,dtype=np.int64)
    guess,k=progressive_argmax(pack_planes(w),w.shape,x,b)
    assert guess==baseline_class(w,x,b)


def test_plane_storage_bytes():
    w=np.zeros((10,64),dtype=np.int16)
    planes=pack_planes(w)
    assert len(planes)==8 and sum(len(p) for p in planes)==w.size
