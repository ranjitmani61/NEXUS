import numpy as np
import pytest
from g2_photonic_count_certificate import admission,garwood,signed_interval,evaluate


def test_zero_count_is_nonnegative_and_includes_positive_upper_bound():
    lo,hi=garwood(np.array([0,1,100]),.001)
    assert lo[0]==0 and hi[0]>0
    assert np.all(lo<=hi)


def test_monotone_poisson_bounds():
    lo,hi=garwood(np.arange(50),.001)
    assert np.all(np.diff(lo)>=0) and np.all(np.diff(hi)>0)


def test_known_noiseless_like_counts_cover_expected():
    x=np.array([50_000_000],dtype=np.int64)
    y=np.array([0],dtype=np.int64)
    h,l,u=signed_interval(x,y,1e8,.001,0.)
    assert l[0]<.5<u[0] and h[0]==.5
    assert admission(h,l,u)[0]


def test_kappa1000_not_certified_under_realistic_photon_count():
    alpha=1e8
    cp=np.array([50_050_000]); cm=np.array([49_950_000])
    h,l,u=signed_interval(cp,cm,alpha,.001,0.)
    assert not admission(h,l,u)[0]


def test_interval_gain_uncertainty_can_force_reject():
    cp=np.array([100_000_000]);cm=np.array([0])
    h,l,u=signed_interval(cp,cm,1e8,.001,gain_bound=.02)
    assert not admission(h,l,u)[0]


def test_blind_drift_produces_false_certificate_control():
    cp=np.array([102_000_000]);cm=np.array([0]);s=1.
    h,l,u=signed_interval(cp,cm,1e8,.001,gain_bound=0.)
    assert admission(h,l,u)[0]
    assert abs(h[0]-s)/abs(s)>.01
    h2,l2,u2=signed_interval(cp,cm,1e8,.001,gain_bound=.02)
    assert not admission(h2,l2,u2)[0]


def test_pilot_zero_counts_reject():
    cp=np.array([200]);cm=np.array([100]);r=np.array([0]);rm=np.array([1000])
    h,l,u=signed_interval(cp,cm,1e4,.001,pilot_pos=r,pilot_neg=rm,exposure=1000)
    assert not admission(h,l,u)[0]


def test_all_zero_rejects_relative_error():
    cp=np.array([0]);cm=np.array([0]);h,l,u=signed_interval(cp,cm,1e8,.001)
    assert not admission(h,l,u)[0]


def test_invalid_counts_and_params():
    with pytest.raises(ValueError): garwood(np.array([-1]),.001)
    with pytest.raises(ValueError): garwood(np.array([1]),1.1)
    with pytest.raises(ValueError): admission(np.array([1]),np.array([0]),np.array([2]),1.0)
    with pytest.raises(ValueError): signed_interval(np.array([1]),np.array([1]),1e8,.001,gain_bound=1.2)


def test_interval_endpoints_admission_equivalence_bruteforce():
    eps=.01
    for h in [-2.,-1.,1.,2.]:
        for delta in [.001,.02]:
            lo,hi=sorted([h*(1-delta),h*(1+delta)])
            a=bool(admission(np.array([h]),np.array([lo]),np.array([hi]),eps)[0])
            grid=np.linspace(lo,hi,31)
            truth=np.all(np.abs(h-grid)/np.abs(grid)<=eps)
            assert a==truth


def test_bounded_gain_intervals_contain_noiseless_signal():
    for k in [1,2,10,100,1000]:
        p=(1+1/k)/2;m=(1-1/k)/2
        cp=np.array([int(1e8*1.02*p)]);cm=np.array([int(1e8*.98*m)])
        hat,lo,hi=signed_interval(cp,cm,1e8,.001,gain_bound=.02)
        assert lo[0] <= 1/k <=hi[0]


def test_pilot_interval_can_compensate_drift():
    p=.75;m=.25
    cp=np.array([round(1e8*1.02*p)]);cm=np.array([round(1e8*.98*m)])
    rp=np.array([round(1e8*1.02)]);rm=np.array([round(1e8*.98)])
    hat,lo,hi=signed_interval(cp,cm,1e8,.001,pilot_pos=rp,pilot_neg=rm,exposure=1e8)
    assert lo[0] <= .5 <= hi[0]
    assert abs(hat[0]-.5)<1e-10


def test_smoke_reproducible():
    a=evaluate(123, n=5)
    b=evaluate(123, n=5)
    assert a==b and len(a)==30


def test_stale_pilot_can_falsely_certify():
    # Pilot estimates gain 1, but data channel gain rises by 2% afterward.
    alpha=1e8
    cp=np.array([102_000_000]); cm=np.array([0]); rp=np.array([100_000_000]); rm=np.array([100_000_000])
    h,l,u=signed_interval(cp,cm,alpha,.001,pilot_pos=rp,pilot_neg=rm,exposure=1e8)
    assert admission(h,l,u)[0]
    assert abs(h[0]-1.0)/1.0>.01
