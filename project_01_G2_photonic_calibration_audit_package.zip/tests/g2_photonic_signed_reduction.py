"""G2 optics physics screen: ideal signed two-channel, Poisson-shot-noise reduction.

This is an analytical/statistical thought experiment; NOT a fabricated photonic chip.

Under an idealized input vector with positive/negative signed intensities:
  C+ ~ Poisson(N*Splus/L1), C- ~ Poisson(N*Sminus/L1)
  s_hat = L1*(C+ - C-)/N
  Var(s_hat) = L1**2 / N (independent of cancellation).

No gain drift is allowed in the probabilistic guarantee unless an explicit gain
error budget is passed. Other physical noise is excluded from this model.
"""
from __future__ import annotations
import json
import math
import platform
from pathlib import Path
import numpy as np

H = 6.62607015e-34
C = 299792458.0
LAMBDA = 1550e-9


def balanced_signed_input(condition_number: float) -> np.ndarray:
    """Return a positive/negative pair with L1=1 and |sum|=1/kappa."""
    if not (math.isfinite(condition_number) and condition_number >= 1):
        raise ValueError('finite condition number must be >=1')
    s = 1.0 / condition_number
    return np.array([(1.0+s)/2.0, -(1.0-s)/2.0], dtype=np.float64)


def sample_measurement(x, detected_photons: float, rng, gain_mismatch=0.0, trials=1):
    """Ideal Poisson channels; mismatch scales positive by 1+g and negative by 1-g.

    gain_mismatch=0 is a required assumption for the uncorrected confidence guard.
    """
    a = np.asarray(x, dtype=np.float64)
    if a.ndim != 1 or not a.size or not np.all(np.isfinite(a)):
        raise ValueError('x must be nonempty 1D finite')
    if not (np.isfinite(detected_photons) and detected_photons > 0):
        raise ValueError('detected_photons must be positive finite')
    if not (math.isfinite(gain_mismatch) and abs(gain_mismatch) < 1):
        raise ValueError('gain mismatch magnitude must be < 1')
    if int(trials) != trials or trials < 1:
        raise ValueError('trials must be a positive integer')
    l1 = float(np.sum(np.abs(a)))
    if l1 == 0:
        return np.zeros(int(trials), dtype=np.float64)
    p = float(np.clip(a, 0, None).sum()/l1)
    q = float(np.clip(-a, 0, None).sum()/l1)
    plus = rng.poisson(detected_photons*p*(1+gain_mismatch), int(trials))
    minus = rng.poisson(detected_photons*q*(1-gain_mismatch), int(trials))
    return (plus.astype(np.float64) - minus.astype(np.float64))*l1/detected_photons


def error_radius_chebyshev(l1: float, photons: float, risk: float, gain_bound=0.0) -> float:
    if not (math.isfinite(l1) and l1 >= 0 and math.isfinite(photons) and photons > 0):
        raise ValueError('invalid l1 or photons')
    if not (math.isfinite(risk) and 0 < risk < 1):
        raise ValueError('risk must be between zero and one')
    if not (math.isfinite(gain_bound) and 0 <= gain_bound < 1):
        raise ValueError('gain bound must be in [0,1)')
    # Under mismatch up to g, Poisson count variance is <= N*(1+g).
    return l1 * (math.sqrt((1+gain_bound)/(photons*risk)) + gain_bound)


def certified_accept(measured, l1, photons, risk, tolerance, gain_bound=0.0):
    """Controls P(accepted AND relative_error > tolerance) <= risk (per fixed input).

    Strictly a model-based *probabilistic* guarantee; no deterministic physical
    bound and not valid if non-Poisson errors exceed gain_bound or input encoding
    is inaccurate. Accepts using measured result; never uses unknown exact sum.
    """
    if not (0 < tolerance < 1 and math.isfinite(tolerance)):
        raise ValueError('tolerance must be in (0,1)')
    b = error_radius_chebyshev(l1, photons, risk, gain_bound)
    y = np.asarray(measured)
    return (np.abs(y) > b) & (b <= tolerance*(np.abs(y)-b))


def required_photons_chebyshev(condition_number, risk, tolerance):
    """Minimum Poisson photons for error <= tolerance*|true| with risk <= risk,
    via Chebyshev in the ideal gain-perfect fixed-input model.
    """
    if not (condition_number >= 1 and math.isfinite(condition_number)):
        raise ValueError('kappa >= 1 required')
    if not (0 < risk < 1 and 0 < tolerance < 1):
        raise ValueError('invalid probabilities')
    return condition_number**2 / (risk*tolerance**2)


def simulation(seed=20261103, repetitions=3000, photons=1e8, risk=1e-3, tolerance=0.01):
    rows = []
    rng = np.random.default_rng(seed)
    for k in [1.0, 2.0, 10.0, 100.0, 1000.0]:
        x = balanced_signed_input(k)
        truth = float(x.sum())
        pred = sample_measurement(x, photons, rng, trials=repetitions)
        accepted = certified_accept(pred, 1.0, photons, risk, tolerance)
        rel = np.abs(pred-truth)/abs(truth)
        # Acceptance is never certified as deterministic. This statistic is a
        # Monte Carlo check of the stated probabilistic property.
        rows.append({
            'kappa':k,
            'true_sum':truth,
            'relative_rms_error':float(np.sqrt(np.mean(rel**2))),
            'relative_error_exceeds_tolerance_fraction':float(np.mean(rel>tolerance)),
            'guard_accepted_fraction':float(np.mean(accepted)),
            'false_certifications':int(np.sum(accepted & (rel>tolerance))),
            'minimum_Chebyshev_photons':float(required_photons_chebyshev(k,risk,tolerance)),
            'photon_energy_at_minimum_J':float(required_photons_chebyshev(k,risk,tolerance)*H*C/LAMBDA),
        })
    # Controlled gain mismatch: using an uncorrected guard is intentionally UNSAFE.
    x = balanced_signed_input(1)
    wrong = sample_measurement(x, photons, rng, gain_mismatch=.02, trials=repetitions)
    naive = certified_accept(wrong, 1.0, photons, risk, tolerance, gain_bound=0.0)
    guarded = certified_accept(wrong, 1.0, photons, risk, tolerance, gain_bound=0.02)
    wrong_rel = abs(wrong-1.0)
    accidental_unsafe = int(np.sum(naive & (wrong_rel>tolerance)))
    corrected_false = int(np.sum(guarded & (wrong_rel>tolerance)))
    # Hypothetical normalized energy costs, NOT measurements of physical system.
    accept = sum(r['guard_accepted_fraction'] for r in rows)/len(rows)
    hypothetical_analog_cost = 0.15
    normalized_cost = hypothetical_analog_cost + (1-accept)
    return {
        'scope':'Ideal shot-noise signed optical reduction, NOT hardware or measured energy',
        'inputs':{'seed':seed,'repetitions_per_case':repetitions,'detected_photons':photons,
                  'risk_limit_per_reduction':risk,'relative_error_tolerance':tolerance,
                  'gain_mismatch_stress':0.02,'wavelength_m':LAMBDA},
        'rows':rows,
        'mismatch_test':{'uncorrected_false_certifications':accidental_unsafe,
                         'corrected_false_certifications':corrected_false,
                         'uncorrected_accept_fraction':float(np.mean(naive)),
                         'corrected_accept_fraction':float(np.mean(guarded)),
                         'true_abs_rel_error_median':float(np.median(wrong_rel))},
        'hypothetical_energy_study':{'case_mix':'equal 20% per kappa, hypothetical only',
                                     'analog_cost_normalized':hypothetical_analog_cost,
                                     'accepted_fraction':accept,
                                     'cost_with_exact_fallback':normalized_cost,
                                     'speed_ratio_vs_digital':1/normalized_cost,
                                     'accept_fraction_needed_for_2x':0.5+hypothetical_analog_cost},
        'runtime':{'python':platform.python_version(),'numpy':np.__version__},
    }


if __name__=='__main__':
    d=simulation()
    out=Path(__file__).resolve().parents[1]/'results'/'g2_photonic_signed_reduction.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
    print('Wrote',out)
    for x in d['rows']:
        print('kappa=%g rms_rel=%8.5f unsafe_raw_rate=%5.3f guard_accept=%5.3f false_cert=%s' % (
            x['kappa'],x['relative_rms_error'],x['relative_error_exceeds_tolerance_fraction'],
            x['guard_accepted_fraction'],x['false_certifications']))
    print('mismatch:',d['mismatch_test'])
    print('hypothetical cost:',d['hypothetical_energy_study'])
