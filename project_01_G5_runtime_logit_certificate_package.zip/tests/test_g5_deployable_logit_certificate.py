"""Positive and negative unit tests: deployable residual-MLP logit certificate."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import numpy as np
import pytest
from g5_deployable_logit_certificate import (
 ResidualMLP,build_model,offline_coefficients,online_bounds,top1_certificate,forward,lipschitz,run_experiment,activate
)

def test_zero_error_exact_certified_if_untied():
    m=build_model(13,d=8,depth=3,classes=5)
    x=np.linspace(-1,1,8)
    exact=forward(m,x)
    approx=forward(m,x,eps=np.zeros(3),noise=[np.zeros(8)]*3)
    assert np.array_equal(exact,approx)
    b=online_bounds(offline_coefficients(m),np.zeros(3))
    safe,_,_=top1_certificate(approx,b)
    assert safe

def test_single_layer_recurrence():
    d=4; W=np.eye(d)*0.3
    m=ResidualMLP((W,),(np.zeros(d),),np.eye(d), 'relu')
    coeff=offline_coefficients(m)
    assert np.allclose(coeff,np.ones_like(coeff))
    x=np.array([2.,1.,0.1,.01])
    approx=forward(m,x,eps=np.array([0.2]),noise=[np.array([0.2,-0.2,0.1,-0.1])])
    exact=forward(m,x)
    assert np.all(np.abs(approx-exact) <=online_bounds(coeff,np.array([0.2]))+1e-12)

def test_deep_linear_residual_bound_expansion():
    d=3; m=ResidualMLP(tuple([np.eye(d)]*3),tuple([np.zeros(d)]*3),np.eye(d),'relu')
    # three additions: injection in layer 0 is magnified by 2 twice; layer 1 by 2 once, layer2 by 1
    C=offline_coefficients(m)
    assert np.allclose(C,np.array([[4.,2.,1.]]*3))

def test_deployable_certificate_does_not_need_exact_logits():
    z=np.array([10.,1.,0.]); b=np.array([.4,.5,.5])
    assert top1_certificate(z,b)[0]
    assert not top1_certificate(np.array([.3,.2,0]),b)[0]

def test_adversarial_unaccounted_layer_false_certification():
    # A deliberately BROKEN computation omits the final layer noise: the false
    # certificate would say safe; correct accounting rejects it.
    m=ResidualMLP((np.zeros((2,2)),),(np.zeros(2),),np.eye(2),'relu')
    # Choose x to make approx's top class 1, true top class 0
    x=np.array([.25,.15]); eps=np.array([1.0]); noise=[np.array([-1.,1.])]
    exact=forward(m,x)
    approx=forward(m,x,eps=eps,noise=noise)
    assert int(np.argmax(exact))==0 and int(np.argmax(approx))==1
    bad=top1_certificate(approx,np.zeros(2))[0]
    correct=top1_certificate(approx,online_bounds(offline_coefficients(m),eps))[0]
    assert bad and not correct

def test_errors_exceed_bound_rejected():
    m=build_model(15,d=8,depth=2)
    with pytest.raises(ValueError): forward(m,np.zeros(8),eps=np.array([0.,0.]),noise=[np.ones(8),np.zeros(8)])

def test_invalid_budget_and_nonfinite_rejected():
    m=build_model(15,d=8,depth=2)
    for budgets in ([0.1],[-0.1,0.0],[np.nan,0.1]):
        with pytest.raises(ValueError): forward(m,np.zeros(8),eps=np.array(budgets))
    with pytest.raises(ValueError): online_bounds(np.ones((3,2)),np.array([1,np.inf]))
    with pytest.raises(ValueError):top1_certificate(np.array([0.,0.]),np.array([0.,-1.]))

@pytest.mark.parametrize('activation',["gelu","relu"])
@pytest.mark.parametrize('d',[3,16])
def test_random_bounds_all_layers(activation,d):
    for seed in range(10):
        rng=np.random.default_rng(seed)
        m=build_model(seed,d=d,depth=5,classes=7,gain=0.15,activation=activation)
        eps=np.array([1e-3,0.01,0.002,0.003,1e-4])
        x=rng.normal(size=d)
        ns=[rng.uniform(-v,v,size=d) for v in eps]
        exact=forward(m,x)
        approx=forward(m,x,eps=eps,noise=ns)
        bound=online_bounds(offline_coefficients(m),eps)
        assert np.all(np.abs(exact-approx)<bound+1e-12)
        safe,cls,_=top1_certificate(approx,bound)
        if safe:assert cls==np.argmax(exact)

def test_gelu_derivative_max_under_lipschitz():
    from scipy.special import ndtr
    x=np.linspace(-12,12,100_000)
    gd=ndtr(x)+x*np.exp(-x*x/2)/np.sqrt(2*np.pi)
    assert np.max(np.abs(gd))<lipschitz('gelu')

def test_smoke_experiment():
    r=run_experiment(seeds=(1,),widths=(8,),gains=(0.1,),activations=('relu',),error_levels=(0,1e-4),samples=3)
    assert r['total_checks']==6 and r['violations']==0 and r['false_certifications']==0
