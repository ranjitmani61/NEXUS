#!/usr/bin/env python3
"""G3/G5 diagnostic: deployable sufficient top-1 certificate for residual MLPs.

No pretrained checkpoint; no claim about full transformers, hardware, or novelty.
Error is injected after each residual branch's affine transform, before activation.
Each injection coordinate is bounded in absolute value by a known eps_l.

Exact arithmetic derivation:
  x_{l+1}=x_l + phi(W_l x_l+b_l)
  x~_{l+1}=x~_l + phi(W_l x~_l+b_l+e_l)
  |x~-x|_{l+1} <= (I + L_phi |W_l|) |x~-x|_l + L_phi eps_l * 1.
  |logits~-logits| <= |W_head| |x~-x|_L.

With fixed W, coefficients C_{l,c} can be precomputed so that
  |logits~-logits|_c <= sum_l C_{l,c} eps_l.
Inference uses only approx logits and eps_l, not the exact model logits.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import platform
import time
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from scipy.special import ndtr


@dataclass
class ResidualMLP:
    W: tuple[np.ndarray, ...]
    bias: tuple[np.ndarray, ...]
    head: np.ndarray
    activation: str


def lipschitz(activation: str) -> float:
    if activation == 'relu': return 1.0
    if activation == 'gelu': return 1.13  # conservative >= max_x d(x*Phi(x))/dx = 1.128904145...
    raise ValueError('Unsupported activation')


def activate(x, activation):
    if activation == 'relu': return np.maximum(x, 0.0)
    if activation == 'gelu': return x * ndtr(x)
    raise ValueError('Unsupported activation')


def validate(model, eps):
    if not isinstance(model, ResidualMLP) or not model.W: raise ValueError('Empty model')
    if len(model.W) != len(model.bias): raise ValueError('Mismatched weights and biases')
    d = model.W[0].shape[0]
    if d < 2: raise ValueError('Need at least two input coordinates')
    for w,b in zip(model.W,model.bias):
        if w.shape!=(d,d) or b.shape!=(d,) or not np.isfinite(w).all() or not np.isfinite(b).all():
            raise ValueError('Invalid residual layer parameters')
    if model.head.ndim!=2 or model.head.shape[1]!=d or model.head.shape[0]<2 or not np.isfinite(model.head).all():
        raise ValueError('Invalid output head')
    if len(eps)!=len(model.W) or not np.isfinite(eps).all() or np.any(eps<0):
        raise ValueError('Invalid local error budgets')
    lipschitz(model.activation)


def build_model(seed=7, d=32, depth=6, classes=16, gain=0.1, activation='gelu'):
    rng=np.random.default_rng(seed)
    W=tuple((rng.normal(size=(d,d))*gain/np.sqrt(d)).astype(np.float64) for _ in range(depth))
    b=tuple((rng.normal(size=d)*0.02).astype(np.float64) for _ in range(depth))
    head=(rng.normal(size=(classes,d))/np.sqrt(d)).astype(np.float64)
    return ResidualMLP(W,b,head,activation)


def forward(model,x,eps=None,noise=None):
    h=np.asarray(x,dtype=np.float64).copy()
    if h.ndim!=1 or h.shape!=(model.W[0].shape[0],) or not np.isfinite(h).all():
        raise ValueError('Bad input')
    if eps is None: eps=np.zeros(len(model.W))
    eps=np.asarray(eps,dtype=np.float64)
    validate(model,eps)
    if noise is not None and (len(noise)!=len(model.W) or any(np.asarray(n).shape!=h.shape for n in noise)):
        raise ValueError('Bad noise list')
    for i,(w,b) in enumerate(zip(model.W,model.bias)):
        e=np.zeros_like(h) if noise is None else np.asarray(noise[i],dtype=np.float64)
        if not np.isfinite(e).all() or np.max(np.abs(e))>eps[i]+1e-12:
            raise ValueError('Local noise exceeds declared bound')
        h=h+activate(w@h+b+e,model.activation)
    return model.head@h


def offline_coefficients(model):
    # For an injection of unit epsilon in layer l: propagate scalar-error envelope
    # through every subsequent layer; head maps this nonnegative vector to logits.
    depth=len(model.W); d=model.W[0].shape[0]
    lam=lipschitz(model.activation)
    c=np.empty((model.head.shape[0], depth),dtype=np.float64)
    P=[np.eye(d)+lam*np.abs(w) for w in model.W]
    head_abs=np.abs(model.head)
    for l in range(depth):
        b=np.full(d,lam)
        for j in range(l+1,depth): b=P[j]@b
        c[:,l]=head_abs@b
    return c


def online_bounds(coeff,eps):
    coeff=np.asarray(coeff,dtype=np.float64)
    eps=np.asarray(eps,dtype=np.float64)
    if coeff.ndim!=2 or eps.shape!=(coeff.shape[1],) or not np.isfinite(coeff).all() or not np.isfinite(eps).all() or np.any(coeff<0) or np.any(eps<0):
        raise ValueError('Invalid certificate inputs')
    return coeff@eps


def top1_certificate(approx_logits, output_bounds):
    z=np.asarray(approx_logits,dtype=np.float64)
    b=np.asarray(output_bounds,dtype=np.float64)
    if z.ndim!=1 or z.shape!=b.shape or len(z)<2 or not np.isfinite(z).all() or not np.isfinite(b).all() or np.any(b<0):
        raise ValueError('Invalid certification argument')
    top=int(np.argmax(z))
    competitors=np.copy(z+b); competitors[top]=-np.inf
    safe=bool(z[top]-b[top] > np.max(competitors))
    return safe,top,float((z[top]-b[top])-np.max(competitors))


def run_experiment(seeds=(20261103,20261104,20261105), widths=(16,32), gains=(0.05,0.1,0.25), activations=('relu','gelu'), error_levels=(0,1e-4,1e-3,1e-2), samples=64):
    rows=[]; violations=0; false_admissions=0
    for activation in activations:
      for d in widths:
       for gain in gains:
        for seed in seeds:
          model=build_model(seed,d=d,depth=6,classes=16,gain=gain,activation=activation)
          t0=time.perf_counter_ns()
          coeff=offline_coefficients(model)
          precompute_ns=time.perf_counter_ns()-t0
          rng=np.random.default_rng(seed+421)
          xs=rng.normal(size=(samples,d))
          noise_basis=rng.uniform(-1,1,size=(samples,len(model.W),d))
          for level in error_levels:
            eps=np.full(len(model.W),level,dtype=np.float64)
            bounds=online_bounds(coeff,eps)
            admits=flips=errors=0
            tcert=0; texact=0; tapprox=0
            max_bound_overrun=-np.inf
            for k in range(samples):
                t0=time.perf_counter_ns()
                exact=forward(model,xs[k])
                texact+=time.perf_counter_ns()-t0
                t0=time.perf_counter_ns()
                approx=forward(model,xs[k],eps=eps,noise=[level*v for v in noise_basis[k]])
                tapprox+=time.perf_counter_ns()-t0
                t0=time.perf_counter_ns()
                b=online_bounds(coeff,eps)
                safe,chosen,margin=top1_certificate(approx,b)
                tcert+=time.perf_counter_ns()-t0
                actual_err=np.abs(approx-exact)
                max_bound_overrun=max(max_bound_overrun,float(np.max(actual_err-bounds)))
                if np.any(actual_err>bounds+1e-9): violations+=1
                if safe and chosen!=int(np.argmax(exact)): false_admissions+=1
                admits+=int(safe); flips+=int(int(np.argmax(exact))!=int(np.argmax(approx)))
                errors+=int(np.max(actual_err)>0)
            rows.append(dict(activation=activation,width=d,gain=gain,seed=seed,error_per_layer=level,
                  queries=samples,certified=admits,top1_flips=flips,errored=errors,
                  max_error_minus_bound=max_bound_overrun,
                  exact_forward_ns_total=texact,approx_forward_ns_total=tapprox,
                  online_certificate_ns_total=tcert,precompute_ns=precompute_ns))
    if violations or false_admissions: raise AssertionError(f'Broken certificate: error bound violations={violations} false admissions={false_admissions}')
    return {'provenance':'random untrained residual MLP diagnostic; NOT pretrained transformer','seed_list':list(seeds),
            'dimensions':list(widths),'gain_list':list(gains),'activations':list(activations),
            'errors_per_layer':list(error_levels),'samples_per_case':samples,
            'total_checks':sum(x['queries'] for x in rows),'violations':violations,
            'false_certifications':false_admissions,'rows':rows,
            'environment':{'python':platform.python_version(),'numpy':np.__version__,'cpu':platform.processor()},
            'scope':'exact-real certificate under bounded additive local errors; float64 numerical tests only'}


def summary(report):
    groups={}
    for row in report['rows']:
        lvl=row['error_per_layer']; a=row['activation']; g=row['gain']; key=(lvl,a,g)
        v=groups.setdefault(key,{'queries':0,'certified':0,'flips':0,'cert_ns':0,'forward_ns':0,'precompute_ns':[]})
        v['queries']+=row['queries']; v['certified']+=row['certified'];v['flips']+=row['top1_flips'];
        v['cert_ns']+=row['online_certificate_ns_total'];v['forward_ns']+=row['exact_forward_ns_total'];
        v['precompute_ns'].append(row['precompute_ns'])
    return [dict(eps_per_layer=k[0],activation=k[1],gain=k[2],
       n=v['queries'],certified_fraction=v['certified']/v['queries'],flip_fraction=v['flips']/v['queries'],
       cert_time_vs_exact_forward=v['cert_ns']/v['forward_ns'],
       median_offline_precompute_ms=float(np.median(v['precompute_ns'])/1e6)) for k,v in sorted(groups.items())]


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,default=Path('results/g5_deployable_logit_certificate.json'))
    p.add_argument('--samples',type=int,default=64)
    args=p.parse_args()
    if args.samples<1 or args.samples>1024: p.error('--samples out of range')
    r=run_experiment(samples=args.samples)
    r['summary']=summary(r)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({'total_checks':r['total_checks'],'violations':r['violations'], 'false_certifications':r['false_certifications'],'summary':r['summary']},indent=2))


if __name__=='__main__':main()
