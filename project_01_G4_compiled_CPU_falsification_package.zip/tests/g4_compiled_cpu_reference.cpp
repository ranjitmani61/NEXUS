// G4 compiled CPU reference v1.0 (2026-11-03)
// EXISTING min/max page-screening idea; not a novel architecture or a GPU kernel.
// FP64 metadata/keys/values; no formal directed-rounding proof. No paid resources.
// Output rows: workload,seed,N,steps,d,vd,page,admitted,failed,numeric_errors,
//  cand_ms,dense_ms,metadata_build_ms,selected_only_ms,fallbacks,max_error,max_bound_overshoot.
// Reproduce: g++ -O3 -march=native -ffp-contract=off -std=c++17 tests/g4_compiled_cpu_reference.cpp -o /tmp/g4_cpu_ref
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
#include <cstring>

using Clock=std::chrono::steady_clock;
static double ms(Clock::time_point a,Clock::time_point b){return std::chrono::duration<double,std::milli>(b-a).count();}
static volatile double checksum=0.0;
struct Dataset {std::vector<double> k,v,q;};
struct PageSummary {std::vector<double> lo,hi;int count=0;};
struct Cache {
 int n=0,dim,vd,page;std::vector<double> k,v;std::vector<PageSummary> summaries;
 Cache(int cap,int d,int vdim,int b):dim(d),vd(vdim),page(b),k((size_t)cap*d),v((size_t)cap*vdim){}
 void build_initial(const Dataset &ds,int initial){
  std::copy(ds.k.begin(),ds.k.begin()+(size_t)initial*dim,k.begin());
  std::copy(ds.v.begin(),ds.v.begin()+(size_t)initial*vd,v.begin());
  n=initial;
 }
 void create_metadata(){
  summaries.clear();
  for(int i=0;i<n;i++) add_summary(i);
 }
 void add_summary(int row){
  if(row%page==0) {PageSummary p; p.lo.assign(dim,std::numeric_limits<double>::infinity());
    p.hi.assign(dim,-std::numeric_limits<double>::infinity()); summaries.push_back(std::move(p));}
  PageSummary &p=summaries.back();p.count++;
  for(int d=0;d<dim;d++){
   const double x=k[(size_t)row*dim+d];p.lo[d]=std::min(p.lo[d],x);p.hi[d]=std::max(p.hi[d],x);
  }
 }
 void append(const Dataset &ds,int row,bool do_meta){
  if(row!=n) throw std::runtime_error("append gap");
  std::memcpy(k.data()+(size_t)n*dim,ds.k.data()+(size_t)n*dim,(size_t)dim*sizeof(double));
  std::memcpy(v.data()+(size_t)n*vd,ds.v.data()+(size_t)n*vd,(size_t)vd*sizeof(double));
  n++;
  if(do_meta) add_summary(n-1);
 }
};
static inline double dot(const double *a,const double *b,int d){double s=0;for(int j=0;j<d;j++)s+=a[j]*b[j];return s;}

static std::vector<double> exact_dense(const Cache &c,const double *q){
 const double scale=1.0/std::sqrt((double)c.dim);
 std::vector<double> scores(c.n);double max_s=-std::numeric_limits<double>::infinity();
 for(int i=0;i<c.n;i++){double s=dot(c.k.data()+(size_t)i*c.dim,q,c.dim)*scale;
  scores[i]=s;max_s=std::max(max_s,s);}
 std::vector<double> out(c.vd,0);double z=0;
 for(int i=0;i<c.n;i++){double w=std::exp(scores[i]-max_s);z+=w;
   const double* val=c.v.data()+(size_t)i*c.vd;
   for(int j=0;j<c.vd;j++)out[j]+=w*val[j];}
 for(double &x:out)x/=z;
 return out;
}
struct Admission {std::vector<double> output;bool admitted;double bound;};
static Admission screened(const Cache &c,const double *q,double eps){
 if(c.summaries.size()!=(size_t)((c.n+c.page-1)/c.page)) throw std::runtime_error("stale metadata count");
 const int selected=c.summaries[0].count;
 const double scale=1./std::sqrt((double)c.dim);
 double m=-std::numeric_limits<double>::infinity();
 std::vector<double> logits(selected);
 for(int i=0;i<selected;i++){double s=dot(c.k.data()+(size_t)i*c.dim,q,c.dim)*scale;
  logits[i]=s;m=std::max(m,s);}
 double Z=0;std::vector<double> num(c.vd,0.0);
 for(int i=0;i<selected;i++){
  double w=std::exp(logits[i]-m);Z+=w;const double *val=c.v.data()+(size_t)i*c.vd;
  for(int j=0;j<c.vd;j++)num[j]+=w*val[j];
 }
 // A sufficient mass-bound certificate in exact arithmetic:
 // e <= 2 U/(Z+U), where U>=sum(omitted exp(score-m)) and Z=sum(selected exp(score-m)).
 // Here FP64 enclosures use a test-only 1e-8 absolute logit pad; NOT a formal roundoff bound.
 double U=0;const double max_u=Z*eps/(2.0-eps);
 for(size_t b=1;b<c.summaries.size();b++){
  const PageSummary &p=c.summaries[b];double ub=0;
  for(int j=0;j<c.dim;j++)ub+=q[j]*(q[j]>=0 ? p.hi[j]:p.lo[j]);
  ub=ub*scale+1e-8;
  double e=ub-m;
  if(e>=700.)return {exact_dense(c,q),false,std::numeric_limits<double>::quiet_NaN()};
  U+=p.count*std::exp(e);
  if(U>max_u)return {exact_dense(c,q),false,std::numeric_limits<double>::quiet_NaN()};
 }
 std::vector<double> out(c.vd);
 for(int j=0;j<c.vd;j++)out[j]=num[j]/Z;
 return {std::move(out),true,2.0*U/(Z+U)};
}
static Dataset make_data(const std::string &kind,uint64_t seed,int n,int steps,int d,int vd,int page){
 std::mt19937_64 rng(seed);std::normal_distribution<double> N(0.0,1.0);
 Dataset x;x.k.resize((size_t)(n+steps)*d);x.v.resize((size_t)(n+steps)*vd);x.q.resize((size_t)steps*d);
 for(auto &v:x.v)v=N(rng);
 for(int i=0;i<n+steps;i++)for(int j=0;j<d;j++){
  double z=N(rng);
  if(kind=="clustered") x.k[(size_t)i*d+j]=(i<page?5.0:-5.0)+0.025*z;
  else if(kind=="moderate") x.k[(size_t)i*d+j]=(i<page?0.68:-0.68)+0.025*z;
  else if(kind=="boundary") x.k[(size_t)i*d+j]=(i<page?0.58:-0.58)+0.025*z;
  else if(kind=="uniform") x.k[(size_t)i*d+j]=0.0001*z;
  else if(kind=="needle") x.k[(size_t)i*d+j]=(i==n+steps-1?9.0:-1.0)+0.25*z;
  else x.k[(size_t)i*d+j]=z;
 }
 for(int i=0;i<steps;i++)for(int j=0;j<d;j++){
  double z=N(rng);
  x.q[(size_t)i*d+j]=(kind=="clustered"||kind=="moderate"||kind=="boundary"||kind=="needle")?(1.0+0.02*z):z;
 }
 return x;
}
struct Summary {
 double dense=0, cand=0, meta=0, selected=0,max_error=0,max_over=0;
 int admitted=0, fallback=0, failures=0;
};
static Summary bench(const std::string &kind,uint64_t seed,int n,int steps,int d,int vd,int page){
 Dataset ds=make_data(kind,seed,n,steps,d,vd,page);
 Cache a(n+steps,d,vd,page),b(n+steps,d,vd,page);
 a.build_initial(ds,n);b.build_initial(ds,n);
 auto start=Clock::now();b.create_metadata();auto stop=Clock::now();
 Summary r;r.meta=ms(start,stop);
 // Warmup same kernels on identical initial cached data.
 for(int i=0;i<6;i++){
  const double *q=ds.q.data()+(size_t)(i%steps)*d;
  auto z1=exact_dense(a,q);auto z2=screened(b,q,0.02);
  checksum=checksum+z1[0]*1e-7+z2.output[0]*1e-7;
 }
 for(int i=0;i<steps;i++){
  const int row=n+i;
  const double *q=ds.q.data()+(size_t)i*d;
  Admission out;std::vector<double> ref;
  // Alternate order to reduce systematic cache/frequency advantages from always running first.
  if(i%2==0){
   auto t=Clock::now();a.append(ds,row,false);ref=exact_dense(a,q);auto t2=Clock::now();r.dense+=ms(t,t2);
   t=Clock::now();b.append(ds,row,true);out=screened(b,q,0.02);t2=Clock::now();r.cand+=ms(t,t2);
  } else {
   auto t=Clock::now();b.append(ds,row,true);out=screened(b,q,0.02);auto t2=Clock::now();r.cand+=ms(t,t2);
   t=Clock::now();a.append(ds,row,false);ref=exact_dense(a,q);t2=Clock::now();r.dense+=ms(t,t2);
  }
  if(out.admitted)r.admitted++;else r.fallback++;
  double norm=0,err=0;
  // Certificate denominator is max ||value_i||, not ||dense_output|| or task-level quality.
  for(int t=0;t<=row;t++){
   double norm_sq=0;
   for(int j=0;j<vd;j++){double x=ds.v[(size_t)t*vd+j];norm_sq+=x*x;}
   norm=std::max(norm,std::sqrt(norm_sq));
  }
  for(int j=0;j<vd;j++)err+=(out.output[j]-ref[j])*(out.output[j]-ref[j]);
  err=std::sqrt(err)/std::max(1e-30,norm);
  r.max_error=std::max(r.max_error,err);
  if(out.admitted)r.max_over=std::max(r.max_over,err-out.bound);
  if(!(err <= 0.02+1e-9) || (out.admitted && err > out.bound+1e-9))r.failures++;
  checksum=checksum+out.output[0]*1e-6+ref[0]*1e-6;
 }
 return r;
}
int main(int argc,char **argv){
 try{
 int n=4096,steps=96,d=64,vd=32,page=32,reps=2;
 if(argc>1)n=std::stoi(argv[1]);
 if(argc>2)steps=std::stoi(argv[2]);
 if(argc>3)d=std::stoi(argv[3]);
 if(argc>4)vd=std::stoi(argv[4]);
 if(argc>5)page=std::stoi(argv[5]);
 if(argc>6)reps=std::stoi(argv[6]);
 if(n<page||n%page!=0||steps<1||d<1||vd<1||page<1||reps<1)throw std::runtime_error("bad arguments");
 std::cout<<"kind,seed,n,steps,d,vd,page,admitted,fallback,failures,"
          <<"candidate_ms,dense_ms,metadata_build_ms,cold_ratio,warm_ratio,max_error,max_bound_overshoot\n";
 std::cout<<std::setprecision(12);
 for(int rep=0;rep<reps;rep++)for(uint64_t seed: {661ULL,719ULL})
  for(std::string kind: {"clustered","moderate","boundary","random","uniform","needle"}){
   Summary r=bench(kind,seed+rep*100003,n,steps,d,vd,page);
   std::cout<<kind<<','<<(seed+rep*100003)<<','<<n<<','<<steps<<','<<d<<','<<vd<<','<<page<<','
    <<r.admitted<<','<<r.fallback<<','<<r.failures<<','<<r.cand<<','<<r.dense<<','<<r.meta<<','
    <<(r.cand+r.meta)/r.dense<<','<<r.cand/r.dense<<','<<r.max_error<<','<<r.max_over<<'\n';
   if(r.failures)throw std::runtime_error("correctness failed");
  }
 std::cerr<<"checksum="<<checksum<<"\n";
 } catch(const std::exception &e){std::cerr<<"ERROR: "<<e.what()<<"\n";return 2;}
}
