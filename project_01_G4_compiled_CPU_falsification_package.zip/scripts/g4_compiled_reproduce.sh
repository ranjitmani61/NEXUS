#!/usr/bin/env bash
# Project 01 G4 compiled CPU reference — deliberate synthetic cases only.
# Usage: cd /mnt/data && bash scripts/g4_compiled_reproduce.sh
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
mkdir -p results

g++ -O3 -march=native -ffp-contract=off -std=c++17 -Wall -Wextra -Wpedantic \
    tests/g4_compiled_cpu_reference.cpp -o tests/g4_compiled_cpu_reference

tests/g4_compiled_cpu_reference 1024 96 64 32 32 1 > results/g4_compiled_cpu_1024.csv 2>results/g4_compiled_cpu_1024.stderr
tests/g4_compiled_cpu_reference 4096 96 64 32 32 2 > results/g4_compiled_cpu_4096.csv 2>results/g4_compiled_cpu_4096.stderr
tests/g4_compiled_cpu_reference 16384 64 64 32 32 1 > results/g4_compiled_cpu_16384.csv 2>results/g4_compiled_cpu_16384.stderr
if command -v taskset >/dev/null 2>&1; then
  taskset -c "$(awk '/Cpus_allowed_list/{split($2,c,/-/);print c[1]}' /proc/self/status)" \
    tests/g4_compiled_cpu_reference 4096 128 64 32 32 3 > results/g4_compiled_cpu_pinned_4096.csv 2>results/g4_compiled_cpu_pinned_4096.stderr
fi
OPENBLAS_NUM_THREADS=1 PYTHONPATH="$PWD/tests" python -m pytest -q \
    tests/test_g3_token_stream_kv.py tests/test_g3_transactional_kv.py \
    tests/test_g3_snapshot_consistency.py tests/test_g3_guarded_mixed_precision.py \
    tests/test_g5_trace_oracle.py tests/test_g5_capture_shapes.py
python scripts/g4_compiled_analyze.py
