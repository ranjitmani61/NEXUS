#!/usr/bin/env python3
"""Summarize raw G4 data; raise on any numerical failures or missing conditions.
No statistics here are model or accelerator speedups. Only synthetic CPU reference.
"""
import csv, json, platform, statistics, subprocess
from pathlib import Path
base=Path(__file__).resolve().parent.parent
paths=[base/'results'/f'g4_compiled_cpu_{n}.csv' for n in (1024,4096,16384)]
paths += [base/'results/g4_compiled_cpu_pinned_4096.csv', base/'results/g4_compiled_cpu_sanitizer.csv']
rows=[]
for p in paths:
 if not p.exists(): raise SystemExit(f'Missing result: {p}')
 with p.open() as f:
  rd=csv.DictReader(f)
  data=list(rd)
 for x in data:
  for field in ('seed','n','steps','d','vd','page','admitted','fallback','failures'):
   x[field]=int(x[field])
  for field in ('candidate_ms','dense_ms','metadata_build_ms','cold_ratio','warm_ratio','max_error','max_bound_overshoot'):
   x[field]=float(x[field])
  if x['failures']!=0 or x['admitted']+x['fallback']!=x['steps']:
   raise SystemExit(f'Failure or inconsistent counts: {p}, {x}')
  x['source']=p.name
 rows+=data
summary={'version':'1.0','date':'2026-11-03','classification':'CPU synthetic software benchmark',
 'role_lenses':['A1','A2','A3','A4','A6','A8','A10','A11'],
 'platform':platform.platform(), 'machine':platform.machine(),
 'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],
 'limitations':['No pretrained weights','No GPU','No energy measurement','No competitive BLAS/FlashAttention benchmark',
                'No rigorous finite-precision rounding proof','Compiled cache not concurrency safe',
                'Model/checking loops exclude initial KV population; check reads can perturb cache state',
                'Clock noise affects fallback comparisons','Implementation overlaps published Quest page screening'],
 'raw_files':[p.name for p in paths],
 'rows':len(rows),'query_checks':sum(x['steps'] for x in rows),
 'violations':sum(x['failures'] for x in rows),
 'scales':{},'pinned_4096':{}}
for n in (1024,4096,16384):
 ds=[x for x in rows if x['n']==n and x['source']==f'g4_compiled_cpu_{n}.csv']
 summary['scales'][str(n)]={}
 for kind in ('clustered','moderate','boundary','random','uniform','needle'):
  a=[x for x in ds if x['kind']==kind]
  summary['scales'][str(n)][kind]={'admitted':sum(x['admitted'] for x in a),
  'queries':sum(x['steps'] for x in a),'cold_ratio_min':min(x['cold_ratio'] for x in a),
  'cold_ratio_max':max(x['cold_ratio'] for x in a),'max_normalized_error':max(x['max_error'] for x in a)}
for kind in ('clustered','moderate','boundary','random','uniform','needle'):
 a=[x for x in rows if x['source']=='g4_compiled_cpu_pinned_4096.csv' and x['kind']==kind]
 summary['pinned_4096'][kind]={
 'admitted':sum(x['admitted'] for x in a),'queries':sum(x['steps'] for x in a),
 'median_cold_ratio':statistics.median(x['cold_ratio'] for x in a),
 'cold_ratio_min':min(x['cold_ratio'] for x in a),'cold_ratio_max':max(x['cold_ratio'] for x in a),
 'max_normalized_error':max(x['max_error'] for x in a),
 'max_bound_overshoot':max(x['max_bound_overshoot'] for x in a)}
p=base/'results/g4_compiled_cpu_summary.json'
p.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(f'{summary["query_checks"]} compiled query comparisons; {summary["violations"]} flagged errors; {summary["rows"]} raw-case rows.')
for kind,x in summary['pinned_4096'].items():
 print(f'{kind:10s} admit {x["admitted"]:4d}/{x["queries"]:4d}; cold median ratio {x["median_cold_ratio"]:.3f}; range [{x["cold_ratio_min"]:.3f},{x["cold_ratio_max"]:.3f}]')
print('saved',p)
