# G4 Compiled CPU falsification protocol — v1.0

**Date:** 2026-11-03. **Owner:** Project 01 (AI-assisted engineering; no independent hardware review). **Engineering roles:** A1 architecture, A2 mathematics, A3 AI systems, A4 runtime, A6 memory, A8 verification, A10 performance, A11 prior art. **Governed by:** `AGENTS.md` v1.0.

## Question and predeclared decision constraints

Does the large Python overhead in our earlier token-stream simulation hide a *real, standalone compiled CPU kernel-level* ability to skip attention reads when page extrema are favorable? Or is page screening ineffective even in that regime? Evaluate one-page selective attention with min/max screening, plus a dense fallback, against an independently implemented contiguous FP64 CPU dense baseline. This answers only a G4 implementation question, **not G5 or G12**. Do not claim this method is new: Quest (Tang et al., ICML 2024) already maintains page extrema for query-aware page selection.

Predeclared negative controls: random keys, uniform scores, rare late important-token `needle`, and a borderline mass case. Additional failure criterion: selectivity must be explicitly reported across cache lengths; no extrapolation from 1K/4K to 16K. All initial KV data are prepopulated outside the timer *for both systems*, and the candidate's one-time metadata construction time is separately added to `cold_ratio`.

## Implementation and mathematics

Source: `tests/g4_compiled_cpu_reference.cpp` (C++17, one process, no GPU). Both caches contain contiguous FP64 K and V tensors. The candidate additionally keeps FP64 min/max metadata per page, updated on each token append. Reference dense attention performs stable FP64 softmax and a weighted value sum. Candidate first scores the **first page only**, then bounds every other page using its coordinate-wise extrema and the query. With $s(k)=q\cdot k/\sqrt d$, the page score bound is $u_p=\sum_j \max(q_j \min K_{pj}, q_j \max K_{pj})/\sqrt d$.

Let $m$ be the largest selected-page logit, $Z_s=\sum_{i\in S}\exp(s_i-m)$, and $U=\sum_{p\notin S}n_p\exp(u_p+\delta-m)$ with the **heuristic** $\delta=10^{-8}$. If $2U/(Z_s+U)\le0.02$, output selected-page attention; otherwise compute exact dense attention. Early rejection is permissible when partial $U$ exceeds $Z_s\epsilon/(2-\epsilon)$. In exact real arithmetic with rigorous $U$, the output error satisfies $\|o_{full}-o_S\|_2/V_{max}\le 2U/(Z_s+U)$ where $V_{max}=\max_i\|v_i\|_2$. This is **not** a hardware/floating-point proof: the chosen $\delta$ is not a rigorously derived rounding envelope, and floating-point exp/dot/denominator errors are not comprehensively bounded.

## Benchmark configuration

- Compiler: g++ 14.2, `-O3 -march=native -ffp-contract=off -std=c++17` (no `-ffast-math`); run on Intel Xeon Platinum 8573C virtualized CPU (single-process CPU benchmark, no GPU). Fallback timings are sensitive to CPU scheduling, frequency, cache warming, and allocator state.
- Key dimension 64; value dimension 32; page size 32; 2 seeds per repetition, seed IDs in each raw CSV; initial cache lengths 1,024 / 4,096 / 16,384 tokens; new decode tokens 96 / 96 / 64. The pinned 4,096-token repetition additionally uses 128 steps and three repetitions.
- Workloads (all synthetic): `clustered` (first page K≈+5, remaining K≈−5), `moderate` (+0.68/−0.68), `boundary` (+0.58/−0.58), `random` (Gaussian K and Q), `uniform` (nearly zero K), and `needle` (a rare late key), with exact generation code in the source.
- For each query, both implementations append one K/V token, compute one attention vector, and are timed separately with alternating order. Baseline is a hand-coded but optimized-compiled contiguous FP64 CPU reference; not an optimized BLAS, FlashAttention, Quest, vLLM, GPU, trained-model or application benchmark. The full-model decode step is not timed. Error checks run outside the time window and could perturb caches; report timings as indicative rather than decisive. No peak RSS, DRAM bytes, energy or thermals measured.
- `cold_ratio = (candidate appended-token+attention time + initial metadata construction) / (dense appended-token+attention time)` summed over each repeated sequence, **not** model/token speedup. `warm_ratio` omits the initial metadata construction.
- The C++ microbenchmark accesses a mutable cache that is *not* a concurrency-safe implementation of the previous G3 immutable snapshot protocol. Do not use it to claim that the stale-metadata race was fixed in C++.

## Reproduction

```bash
cd /mnt/data
bash scripts/g4_compiled_reproduce.sh
# Optional instrumentation (not for timing conclusions):
g++ -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -std=c++17 -ffp-contract=off \
  tests/g4_compiled_cpu_reference.cpp -o tests/g4_compiled_cpu_reference_san
ASAN_OPTIONS=detect_leaks=1 tests/g4_compiled_cpu_reference_san 128 8 8 8 8 1
```

Raw files under `results/g4_compiled_cpu_{1024,4096,16384}.csv`, `results/g4_compiled_cpu_pinned_4096.csv`, and `results/g4_compiled_cpu_sanitizer.csv`; JSON aggregation under `results/g4_compiled_cpu_summary.json`. Existing Python tests `results/g4_compiled_context_pytest.txt` (113 checks) and `results/g5_harness_restored_pytest.txt` (11 checks). The G5 runner is present but no valid pretrained model was available to run it. The model checkpoint must be obtained from a controlled external environment before interpreting any pretrained trace.

## Sources and limitations

- Quest (Tang et al., ICML 2024): https://proceedings.mlr.press/v235/tang24l.html . Its existing min/max page-bounding selection is close prior art.
- PagedAttention / vLLM (Kwon et al., SOSP 2023): https://doi.org/10.1145/3600006.3613165 . Its cache/paging mechanisms are relevant systems prior art.
- FlashAttention-2 (Dao, ICLR 2024): https://proceedings.iclr.cc/paper_files/paper/2024/hash/98ed250b203d1ac6b24bbcf263e3d4a7-Abstract-Conference.html . A relevant optimized GPU dense baseline; not reproduced here.

**Gate exit:** No G5 evidence, no production baseline, no novelty, and no formal arithmetic/concurrency proof; G3/G4 remain IN PROGRESS, G5 BLOCKED, G6 NOT AUTHORIZED. This test cannot establish a processor breakthrough regardless of measured synthetic CPU speedups.
