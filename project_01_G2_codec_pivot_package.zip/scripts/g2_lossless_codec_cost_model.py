#!/usr/bin/env python3
"""Exploratory BYTES-ONLY upper bounds, not a measured LLM speedup.

Example: python scripts/g2_lossless_codec_cost_model.py
Input: results/g2_lossless_codec_run1.csv (128 synthetic pages/regime).
"""
import csv
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
with (ROOT/'results/g2_lossless_codec_run1.csv').open() as f:
    rows = {r['regime']: r for r in csv.DictReader(f)}
# Hypothetical 8B-parameter BF16 weights and 32-layer, 8-KV-head, 128-dim GQA.
# Not a measurement of a specific pretrained model.
WEIGHT_BYTES = 8_000_000_000 * 2
KV_PER_CONTEXT_TOKEN = 2 * 32 * 8 * 128 * 2  # K and V; 2 bytes/element.
out = {
    'model_assumption': {
        'parameters': 8_000_000_000, 'weight_dtype_bytes': 2, 'weight_bytes': WEIGHT_BYTES,
        'layers':32, 'kv_heads':8,'head_dim':128,'kv_dtype_bytes':2,
        'kv_bytes_per_context_token_per_sequence': KV_PER_CONTEXT_TOKEN,
        'remarks':'Byte-volume ceiling only: every step reads every weight and KV byte, ignores reuse, paging, bandwidth contention, compute, decoder cost and actual model structure.'
    },
    'workloads':[],
    'ratio_matrix':[],
}
for regime, row in rows.items():
    out['workloads'].append({
        'regime':regime,'codec_ratio':float(row['ratio']), 'zstd_ratio':float(row['zstd_ratio']),
        'codec_scan_ratio_cpu':float(row['scan_ratio']), 'zstd_scan_ratio_cpu':float(row['zstd_scan_ratio']),
        'codec_packed_pages':int(row['packed_pages']), 'pages':int(row['pages']),
    })
for regime in ('stationary','correlated','gaussian'):
    r = float(rows[regime]['ratio'])
    for batch in (1,16):
        for context in (4096,16384,131072):
            K = KV_PER_CONTEXT_TOKEN * context * batch
            W = WEIGHT_BYTES
            s = (W+K)/(W+r*K)
            out['ratio_matrix'].append({
                'regime':regime, 'batch':batch,'context_tokens':context,
                'weight_gb':round(W/1e9,4),'kv_gb':round(K/1e9,4),
                'ideal_byte_volume_speedup_upper_ceiling_if_decode_is_free':round(s,6),
            })
(ROOT/'results/g2_lossless_codec_cost_model.json').write_text(json.dumps(out, indent=2)+'\n')
for row in out['ratio_matrix']:
    if row['regime']=='correlated': print(row)
