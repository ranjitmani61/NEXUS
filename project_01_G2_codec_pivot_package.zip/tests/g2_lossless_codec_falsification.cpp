// G2 exploratory lossless KV-page codec falsification test; not a novel compression claim.
// Build: g++ -std=c++17 -O3 -ffp-contract=off -Wall -Wextra -pedantic tests/g2_lossless_codec_falsification.cpp -o tests/g2_lossless_codec_falsification
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
#include <zstd.h>

static constexpr size_t ROWS = 32, DIMS = 64, PAGE_COUNT = 128;
static constexpr uint32_t SEED = 20261103;

static uint16_t bf16(float x) {
    uint32_t b;
    std::memcpy(&b, &x, 4);
    const uint32_t lsb = (b >> 16U) & 1U;
    b += 0x7FFFU + lsb; // round-to-nearest-even for ordinary finite values
    return static_cast<uint16_t>(b >> 16U);
}
static inline void put16(std::vector<uint8_t>& b, uint16_t x) {
    b.push_back(static_cast<uint8_t>(x)); b.push_back(static_cast<uint8_t>(x>>8));
}
static inline void put32(std::vector<uint8_t>& b, uint32_t x) {
    for(int i=0;i<4;i++) b.push_back(static_cast<uint8_t>(x>>(8*i)));
}
static inline uint16_t get16(const std::vector<uint8_t>& b,size_t& pos) {
    if(pos+2>b.size()) throw std::runtime_error("truncated u16");
    uint16_t x=static_cast<uint16_t>(b[pos]) | static_cast<uint16_t>(b[pos+1]<<8); pos+=2; return x;
}
static inline uint32_t get32(const std::vector<uint8_t>& b,size_t& pos) {
    if(pos+4>b.size()) throw std::runtime_error("truncated u32");
    uint32_t x=0; for(int i=0;i<4;i++) x|=static_cast<uint32_t>(b[pos++])<<(8*i); return x;
}
static int bit_width(uint16_t w) { int n=0; while(w){n++;w>>=1;} return n; }
static void pack_bits(std::vector<uint8_t>& out, const std::vector<uint16_t>& words,int width) {
    uint32_t acc=0; int bits=0;
    for (uint16_t w: words) {
        acc |= static_cast<uint32_t>(w) << bits;
        bits+=width;
        while(bits>=8){out.push_back(static_cast<uint8_t>(acc&255)); acc>>=8; bits-=8;}
    }
    if(bits)out.push_back(static_cast<uint8_t>(acc));
}
static std::vector<uint16_t> unpack_bits(const std::vector<uint8_t>& in, size_t& pos, size_t count,int width){
    std::vector<uint16_t> out;out.reserve(count);uint32_t acc=0;int bits=0;
    for(size_t i=0;i<count;i++){
        while(bits<width){ if(pos>=in.size())throw std::runtime_error("truncated packed words");acc |= static_cast<uint32_t>(in[pos++]) << bits; bits+=8; }
        uint32_t mask=width==16?65535U:(width==0?0U:((1U<<width)-1U));
        out.push_back(static_cast<uint16_t>(acc&mask));acc>>=width;bits-=width;
    }
    if(bits && acc)throw std::runtime_error("nonzero padding");
    return out;
}
// Serialized page: codec (0 raw, 1 XOR bitpack); rows; dims u16; payload bytes u32; payload.
// Header bytes charged to BOTH cached raw and compressed representations.
static std::vector<uint8_t> encode(const std::vector<uint16_t>& a){
    if(a.size()!=ROWS*DIMS) throw std::runtime_error("invalid source length");
    std::vector<uint8_t> body; body.reserve(ROWS*DIMS*2);
    for(size_t d=0;d<DIMS;d++){
        const uint16_t anchor=a[d];
        std::vector<uint16_t> delta;delta.reserve(ROWS-1);
        uint16_t all=0, prev=anchor;
        for(size_t i=1;i<ROWS;i++){ uint16_t v=a[i*DIMS+d]; uint16_t x=v^prev; delta.push_back(x); all|=x; prev=v; }
        const int width=bit_width(all);
        body.push_back(static_cast<uint8_t>(width));put16(body,anchor);pack_bits(body,delta,width);
    }
    bool packed=body.size()<ROWS*DIMS*2;
    std::vector<uint8_t> output;output.reserve(8+std::min(body.size(),ROWS*DIMS*2));
    output.push_back(packed?1:0);output.push_back(static_cast<uint8_t>(ROWS));put16(output,static_cast<uint16_t>(DIMS));
    put32(output,static_cast<uint32_t>(packed?body.size():ROWS*DIMS*2));
    if(packed) output.insert(output.end(),body.begin(),body.end());
    else for(uint16_t v:a)put16(output,v);
    return output;
}
static std::vector<uint16_t> decode(const std::vector<uint8_t>& in){
    if(in.size()<8) throw std::runtime_error("truncated header");
    size_t pos=0; uint8_t mode=in[pos++],rows=in[pos++]; uint16_t dims=get16(in,pos);uint32_t bytes=get32(in,pos);
    if(rows!=ROWS||dims!=DIMS||pos+bytes!=in.size()||mode>1) throw std::runtime_error("invalid header / payload size");
    std::vector<uint16_t> out(ROWS*DIMS);
    if(mode==0){
        if(bytes!=ROWS*DIMS*2)throw std::runtime_error("bad raw length");
        for(auto& v:out)v=get16(in,pos);
    }else{
        for(size_t d=0;d<DIMS;d++){
            if(pos>=in.size())throw std::runtime_error("missing channel width");
            uint8_t width=in[pos++];if(width>16)throw std::runtime_error("invalid width");
            uint16_t prev=get16(in,pos);out[d]=prev;
            auto delta=unpack_bits(in,pos,ROWS-1,width);
            for(size_t i=1;i<ROWS;i++){prev^=delta[i-1];out[i*DIMS+d]=prev;}
        }
    }
    if(pos!=in.size())throw std::runtime_error("extra payload bytes");
    return out;
}
// Second, allocation-free decoder for throughput benchmark. Scratch must already be allocated.
static void decode_into(const std::vector<uint8_t>& in, std::vector<uint16_t>& out){
    if(out.size()!=ROWS*DIMS||in.size()<8)throw std::runtime_error("invalid target / header");
    size_t pos=0; uint8_t mode=in[pos++],rows=in[pos++];uint16_t dims=get16(in,pos);uint32_t bytes=get32(in,pos);
    if(rows!=ROWS||dims!=DIMS||pos+bytes!=in.size()||mode>1)throw std::runtime_error("bad size or mode");
    if(mode==0){
        if(bytes!=ROWS*DIMS*2)throw std::runtime_error("bad raw length");
        for(size_t i=0;i<out.size();i++)out[i]=get16(in,pos);
    }else{
        for(size_t d=0;d<DIMS;d++){
            if(pos>=in.size())throw std::runtime_error("truncated width");
            uint8_t width=in[pos++];if(width>16)throw std::runtime_error("bad width");
            uint16_t prev=get16(in,pos);out[d]=prev;
            uint32_t acc=0;int bits=0;
            uint32_t mask=width==16?65535U:(width==0?0U:((1U<<width)-1U));
            for(size_t i=1;i<ROWS;i++){
                while(bits<width){if(pos>=in.size())throw std::runtime_error("short payload");acc|=static_cast<uint32_t>(in[pos++])<<bits;bits+=8;}
                const uint16_t dx=static_cast<uint16_t>(acc&mask);
                acc>>=width;bits-=width;
                prev^=dx;out[i*DIMS+d]=prev;
            }
            if(bits && acc)throw std::runtime_error("nonzero padding");
        }
    }
    if(pos!=in.size())throw std::runtime_error("trailing bytes");
}
static std::vector<uint16_t> make_page(const std::string& regime,uint32_t seed){
    std::mt19937 rng(seed);std::normal_distribution<float> gauss(0.0f,1.0f);
    std::uniform_int_distribution<int> raw(0,65535);
    std::vector<uint16_t> a(ROWS*DIMS);
    std::vector<float> channel(DIMS);
    for(float& x:channel)x=gauss(rng);
    for(size_t i=0;i<ROWS;i++)for(size_t d=0;d<DIMS;d++){
        if(regime=="zeros")a[i*DIMS+d]=0;
        else if(regime=="stationary")a[i*DIMS+d]=bf16(1.0f+0.003f*gauss(rng));
        else if(regime=="correlated")a[i*DIMS+d]=bf16(channel[d]+0.02f*gauss(rng));
        else if(regime=="gaussian")a[i*DIMS+d]=bf16(gauss(rng));
        else if(regime=="adversarial")a[i*DIMS+d]=static_cast<uint16_t>(raw(rng));
        else throw std::runtime_error("unknown regime");
    }
    return a;
}
static volatile uint64_t sink = 0;
static uint64_t checksum(const std::vector<uint16_t>& x){
    uint64_t s=0;
    for(size_t i=0;i<x.size();i++) s+=static_cast<uint64_t>(x[i])*(i+1);
    return s;
}
static bool throws_invalid(const std::vector<uint8_t>& b){try{(void)decode(b);}catch(const std::runtime_error&){return true;}return false;}
int main(){
    const std::array<std::string,5> regimes={"zeros","stationary","correlated","gaussian","adversarial"};
    std::cout<<"regime,pages,raw_bytes,encoded_bytes,ratio,packed_pages,xor_encode_ms,decode_scan_ms,raw_scan_ms,scan_ratio,checks,zstd_bytes,zstd_ratio,zstd_encode_ms,zstd_scan_ms,zstd_scan_ratio,zstd_packed_pages\n";
    bool good=true;
    for(const auto& regime:regimes){
        std::vector<std::vector<uint16_t>> raws;
        std::vector<std::vector<uint8_t>> codes, zcodes;
        raws.reserve(PAGE_COUNT);codes.reserve(PAGE_COUNT);zcodes.reserve(PAGE_COUNT);
        uint64_t raw_bytes=0,encoded_bytes=0,zbytes=0;size_t packed=0,zpacked=0, checks=0;
        double xor_encode_ms=0,zstd_encode_ms=0;
        for(size_t p=0;p<PAGE_COUNT;p++){
            auto x=make_page(regime,SEED+static_cast<uint32_t>(p)*7919);
            auto c0=std::chrono::steady_clock::now();
            auto c=encode(x);
            auto c1=std::chrono::steady_clock::now();
            xor_encode_ms+=std::chrono::duration<double,std::milli>(c1-c0).count();
            std::vector<uint16_t> alt(ROWS*DIMS);
            decode_into(c,alt);
            if(decode(c)!=x || alt!=x){std::cerr<<"FAIL: roundtrip "<<regime<<" page "<<p<<"\n";return 2;}
            // Every truncation must be rejected, including valid zero-width pages.
            for(size_t n=0;n<c.size();n+=std::max<size_t>(1,c.size()/17)){
                std::vector<uint8_t> invalid(c.begin(),c.begin()+n);
                if(!throws_invalid(invalid)){std::cerr<<"FAIL: truncation "<<regime<<" page "<<p<<" at "<<n<<"\n";return 2;}
                checks++;
            }
            raw_bytes+=ROWS*DIMS*2+8;encoded_bytes+=c.size();packed+=(c[0]==1);
            std::vector<uint8_t> z(ZSTD_compressBound(ROWS*DIMS*2));
            auto z0=std::chrono::steady_clock::now();
            size_t zsize=ZSTD_compress(z.data(),z.size(),x.data(),ROWS*DIMS*2,1);
            auto z1=std::chrono::steady_clock::now();
            zstd_encode_ms+=std::chrono::duration<double,std::milli>(z1-z0).count();
            if(ZSTD_isError(zsize))throw std::runtime_error("zstd compression failure");
            bool zcomp = zsize < ROWS*DIMS*2;
            if(zcomp){z.resize(zsize);zpacked++;}
            else{z.resize(ROWS*DIMS*2);std::memcpy(z.data(),x.data(),z.size());}
            zbytes+=z.size()+8;
            std::vector<uint16_t> zz(ROWS*DIMS);
            if(zcomp){
                size_t dec=ZSTD_decompress(zz.data(),ROWS*DIMS*2,z.data(),z.size());
                if(ZSTD_isError(dec)||dec!=ROWS*DIMS*2)throw std::runtime_error("zstd decompression failure");
            } else std::memcpy(zz.data(),z.data(),z.size());
            if(zz!=x)throw std::runtime_error("zstd corruption");
            raws.push_back(std::move(x));codes.push_back(std::move(c));zcodes.push_back(std::move(z));checks++;
        }
        // Each pass decodes the complete page and then executes the same checksum as the raw pass.
        constexpr int REPS=50;
        uint64_t lhs=0,rhs=0;
        std::vector<uint16_t> scratch(ROWS*DIMS);
        auto t0=std::chrono::steady_clock::now();
        for(int r=0;r<REPS;r++)for(const auto& c:codes){decode_into(c,scratch);lhs+=checksum(scratch)+static_cast<uint64_t>(r);}
        auto t1=std::chrono::steady_clock::now();
        for(int r=0;r<REPS;r++)for(const auto& x:raws)rhs+=checksum(x)+static_cast<uint64_t>(r);
        auto t2=std::chrono::steady_clock::now();
        uint64_t zrhs=0;
        for(int r=0;r<REPS;r++)for(size_t p=0;p<zcodes.size();p++){
            if(zcodes[p].size()<ROWS*DIMS*2){
                size_t n=ZSTD_decompress(scratch.data(),ROWS*DIMS*2,zcodes[p].data(),zcodes[p].size());
                if(ZSTD_isError(n)||n!=ROWS*DIMS*2) throw std::runtime_error("bad zstd decode");
            } else std::memcpy(scratch.data(),zcodes[p].data(),ROWS*DIMS*2);
            zrhs+=checksum(scratch)+static_cast<uint64_t>(r);
        }
        auto t3=std::chrono::steady_clock::now();
        sink=lhs+rhs+zrhs;
        if(zrhs!=rhs){std::cerr<<"FAIL: zstd scan mismatch "<<regime<<"\n";good=false;}
        if(lhs!=rhs){std::cerr<<"FAIL: scan mismatch "<<regime<<"\n";good=false;}
        double decode_ms=std::chrono::duration<double,std::milli>(t1-t0).count();
        double raw_ms=std::chrono::duration<double,std::milli>(t2-t1).count();
        double zstd_ms=std::chrono::duration<double,std::milli>(t3-t2).count();
        std::cout<<regime<<","<<PAGE_COUNT<<","<<raw_bytes<<","<<encoded_bytes<<","<<std::fixed<<std::setprecision(5)
                 <<double(encoded_bytes)/double(raw_bytes)<<","<<packed<<","<<xor_encode_ms<<","<<decode_ms<<","<<raw_ms<<","<<decode_ms/raw_ms<<","<<checks<<","<<zbytes<<","<<double(zbytes)/double(raw_bytes)<<","<<zstd_encode_ms<<","<<zstd_ms<<","<<zstd_ms/raw_ms<<","<<zpacked<<"\n";
    }
    // Additional adversarial validity checks for raw and compressed page headers.
    auto code=encode(make_page("zeros",1234));
    auto altered=code;altered[1]=31;
    if(!throws_invalid(altered))good=false;
    altered=code;altered[0]=7;if(!throws_invalid(altered))good=false;
    altered=code;altered[4]=0xff;if(!throws_invalid(altered))good=false;
    altered=code;altered[8]=17;if(!throws_invalid(altered))good=false;
    if(!good){std::cerr<<"FAIL: malformed block handling\n";return 2;}
    return 0;
}
