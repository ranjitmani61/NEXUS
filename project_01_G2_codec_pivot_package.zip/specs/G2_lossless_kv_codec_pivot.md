# G2 Pivot Feasibility Contract — Lossless KV-page data representation (v1.0)

**Date:** 2026-11-03. **Governed by:** `AGENTS.md` v1.0 (read in full before work). **Roles/ACTS:** A1 architecture, A2 mathematics, A3 model representativeness, A4 runtime, A6 memory, A8 verification, A10 performance, A11 prior art. No independent human reviewer.

## Objective (a *different* exploration, not a novel-processor claim)

Explore whether lossless BF16 KV-page representation has sufficient theoretical traffic reduction to be worth investigating as a physical memory-path accelerator. The preceding query-aware page-skipping candidate is **rejected as a new architectural invention** because its key mechanism overlaps Quest 2024 and performance varies dramatically across cases.

### Hypothesis

A simple per-channel token-delta XOR + bit-width packing format can losslessly reduce byte volume on temporally coherent BF16 pages. However, compression entropy and decompression cost may negate benefits; random or mixed-sign data may be incompressible. Results will be compared to raw BF16 and unoptimized zstd level 1.

### New candidate's novelty status

**Not novel as formulated.** Lossless compressor and KV codec prior art exists, particularly AdaCode (EMNLP 2026), which directly targets bit-exact BF16 KV caching. Token-delta/XOR compression is also an established technique. A future new mechanism would need to differ materially at a circuit, execution, or information-theoretic level, not by simply attaching a codec to memory.

## Serialization

Page shape 32 tokens × 64 channels, 16-bit raw words each. For every channel: store first word (16-bit anchor), XOR each subsequent word with preceding word, select unsigned bit width sufficient for all deltas on this page/channel, bit-pack 31 deltas. Prefix page with 8-byte envelope (mode, rows, channels, payload length); charge identical envelope size to uncompressed baseline, because either layout requires a page descriptor. If compressed payload is not smaller than raw payload, store raw words. Both codecs return original 16-bit words **bit-for-bit**, including arbitrary patterns.

The format is independent of float interpretation (works for BF16/FP16 raw bit patterns). It is not an attention approximation; bitwise recovery is exact. Serialization includes 8-byte page envelope and 3-byte/channel compressed overhead. Existing test checks do not establish data-corruption detection; bit flips that retain a valid encoded layout can change decoded values silently. A hardware memory system would require ECC/integrity and transactional updates. A software format is not itself a processor architecture.

## Workloads and predeclared negative controls

Each regime: 128 distinct pages, fixed 32×64 shape and deterministic per-page RNG seeds based on 20261103.

- `zeros`: trivial upper bound control.
- `stationary`: BF16 from 1 + 0.003 × independent Gaussian noise (fixed sign, narrow exponent).
- `correlated`: per-channel shared Gaussian mean plus 0.02 × independent token noise; **synthetic**, not a model trace.
- `gaussian`: independent standard-normal BF16; realistic-looking marginal distribution but not a pretrained KV trace.
- `adversarial`: uniform arbitrary 16-bit words, deliberately noncompressible.

All 640 pages must roundtrip bit-exactly through **both an independent simple decoder and an allocation-free decoder**, and through the zstd comparator. Sampled truncations and malformed headers must be rejected. Run twice and include an ASan/UBSan execution.

## Metrics and limitations

1. Actual serialized bytes, including descriptor bytes, divided by same raw representation. Lower is better.
2. CPU checksum scan of every decoded page versus the same raw page; this is **not attention**, memory-system latency, GPU inference, energy, or HBM bandwidth.
3. Measured encode times without input generation, independent tests, or zstd operations inside the timer.
4. Compare zstd level 1 on original interleaved pages. **Not strongest codec:** zstd is not given a transposed/structure-optimized representation, and AdaCode is not implemented. Do not assert superiority over a state-of-the-art KV codec.
5. A theoretical **bytes-only**, decoder-free Amdahl-style upper ceiling on the weight + KV read volume. Assumptions: nominal 8B BF16 weights = 16 decimal GB, 32 layers, 8 KV heads, dimension 128, BF16 K and V, and every relevant weight/KV byte read once each decode step. No cache reuse, optimizations, compression of weights, compute, metadata traffic, energy, or overlap in this formula. Not model measurements.

Byte-volume ceiling: `S_bytes = (W + K)/(W + r*K)`, where `W = 16e9`, `K = batch * context * 2 * 32 * 8 * 128 * 2`, `r = codec serialized byte ratio`. Actual time benefit need not follow the byte-volume ceiling.

**Gate condition:** Treat codec as research baseline only. If it does not offer broad reduction on data relevant to target models and sufficient decoder throughput on a competitive implementation, STOP; do not proceed to RTL/ASIC. Even a positive result would not prove novelty.

## Reproduction

```bash
cd /mnt/data
g++ -std=c++17 -O3 -ffp-contract=off -Wall -Wextra -pedantic tests/g2_lossless_codec_falsification.cpp -lzstd -o tests/g2_lossless_codec_falsification
tests/g2_lossless_codec_falsification | tee results/g2_lossless_codec_run1.csv
tests/g2_lossless_codec_falsification | tee results/g2_lossless_codec_run2.csv
python scripts/g2_lossless_codec_cost_model.py
# sanitizer check, do not interpret as a timing benchmark:
g++ -std=c++17 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer tests/g2_lossless_codec_falsification.cpp -lzstd -o tests/g2_lossless_codec_falsification_san
ASAN_OPTIONS=detect_leaks=1 tests/g2_lossless_codec_falsification_san > results/g2_lossless_codec_sanitizer.csv 2> results/g2_lossless_codec_sanitizer.stderr
```

### Prior art (read on 2026-11-03)

- AdaCode (EMNLP October 2026, peer-reviewed; lossless BF16 KV): https://aclanthology.org/2026.emnlp-main.269/
- Memory-Efficient LLM Inference Algorithms (Berkeley thesis, May 2026; weight/KV bottleneck crossover): https://www2.eecs.berkeley.edu/Pubs/TechRpts/2026/EECS-2026-175.html
- RocketKV (ICML 2025, *lossy* KV compression): https://proceedings.mlr.press/v267/behnam25a.html
- DeepSeek-V2 multi-head latent attention, **model-dependent and not bit-exact KV encoding**: https://huggingface.co/docs/transformers/model_doc/deepseek_v2
- Quest query-aware page screening (2024; earlier rejected branch): https://proceedings.mlr.press/v235/tang24l.html

**Caution:** No patent search, independent specialist novelty review, or pretrained trace was obtained. G1 is incomplete for any patentability/architecture claims.
