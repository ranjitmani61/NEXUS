"""Independent properties and boundary tests for the conditional byte model."""
import math
import unittest
from g2_memory_traffic_headroom import Scenario, report

class TrafficBudgetTests(unittest.TestCase):
    def test_zero_context_is_weight_only(self):
        r=Scenario().estimate(0)
        self.assertEqual(r['kv_bytes'],0)
        self.assertEqual(r['conditional_best_case_kv_elimination_gain'],1.)
    def test_canonical_kv_bytes(self):
        r=Scenario().estimate(8192)
        self.assertEqual(r['kv_bytes'], 1_073_741_824)
        self.assertEqual(r['weight_bytes'], 16_000_000_000)
    def test_2x_threshold_is_tight_integer(self):
        s=Scenario()
        t=s.context_at_2x_kv_elimination
        self.assertGreaterEqual(s.estimate(t)['conditional_best_case_kv_elimination_gain'],2)
        self.assertLess(s.estimate(t-1)['conditional_best_case_kv_elimination_gain'],2)
    def test_kv_gain_monotonic_in_context(self):
        s=Scenario()
        prev=0
        for t in range(0,200000,1993):
            k=s.estimate(t)['conditional_best_case_kv_elimination_gain']
            self.assertGreaterEqual(k,prev)
            prev=k
    def test_batch_scaling(self):
        for t in (0,4096,8192,131072):
            s=Scenario()
            a=s.estimate(t)
            b=Scenario(batch_size=16).estimate(t)
            self.assertEqual(b['kv_bytes'],16*a['kv_bytes'])
            self.assertEqual(b['weight_bytes'],a['weight_bytes'])
    def test_kv_head_scaling(self):
        a=Scenario(kv_heads=8).estimate(4096)
        b=Scenario(kv_heads=32).estimate(4096)
        self.assertEqual(b['kv_bytes'],4*a['kv_bytes'])
    def test_halving_weights_with_zero_kv_is_2x_bytes(self):
        r=Scenario().estimate(0)
        self.assertEqual(r['conditional_best_case_weight_halving_gain'],2)
    def test_compression_changes_bound_not_real_speed(self):
        bf16=Scenario().estimate(8192)
        int4=Scenario(weight_bytes_per_param=.5).estimate(8192)
        self.assertGreater(int4['conditional_best_case_kv_elimination_gain'],bf16['conditional_best_case_kv_elimination_gain'])
    def test_peak_memory_floor_scales_with_bandwidth(self):
        a=Scenario(hbm_bandwidth_bytes_per_second=4.8e12).estimate(8192)
        b=Scenario(hbm_bandwidth_bytes_per_second=2.4e12).estimate(8192)
        self.assertAlmostEqual(b['peak_bandwidth_floor_ms']/a['peak_bandwidth_floor_ms'],2)
    def test_unrealistic_input_rejected(self):
        for s in (Scenario(params=0),Scenario(batch_size=0),Scenario(kv_heads=0),Scenario(weight_bytes_per_param=float('nan')),Scenario(hbm_bandwidth_bytes_per_second=-1)):
            with self.assertRaises(ValueError):s.estimate(8192)
        for t in (-1,1.2,'4096'):
            with self.assertRaises(ValueError):Scenario().estimate(t)
    def test_dimensionless_2x_ratio(self):
        r=Scenario().estimate(8192)
        self.assertAlmostEqual(r['conditional_best_case_kv_elimination_gain'],r['total_bytes']/r['weight_bytes'])
        self.assertAlmostEqual(r['kv_fraction_of_total'],1-1/r['conditional_best_case_kv_elimination_gain'])
    def test_report_has_declared_assumptions(self):
        result=report()
        self.assertGreaterEqual(len(result['assumptions']),8)
        self.assertIn('ANALYTIC',result['status'])
        self.assertEqual(result['variants']['bf16_batch1']['threshold_2x'],122071)

if __name__=='__main__':unittest.main()
