#!/usr/bin/env python3
"""G2 conditional memory traffic budget for autoregressive decode.

This is an illustrative analytic model, NOT measured GPU latency and NOT a claim
about a real model or GPU. It deliberately grants KV traffic elimination for free.

Method: one weight-stream per decode step, one full K+V stream per sequence;
all bytes are assumed to travel from the same memory tier at one bandwidth.
"""
from __future__ import annotations
import argparse
import json
import math
import platform
from dataclasses import dataclass, asdict
from pathlib import Path


@dataclass(frozen=True)
class Scenario:
    params: int = 8_000_000_000
    weight_bytes_per_param: float = 2.0
    layers: int = 32
    kv_heads: int = 8
    head_dim: int = 128
    kv_bytes_per_element: float = 2.0
    batch_size: int = 1
    hbm_bandwidth_bytes_per_second: float = 4.8e12

    def validate(self):
        if not isinstance(self.params, int) or self.params <= 0:
            raise ValueError('params must be positive integer')
        for field in ('layers', 'kv_heads', 'head_dim', 'batch_size'):
            v = getattr(self, field)
            if not isinstance(v,int) or v <= 0:
                raise ValueError(field+' must be positive integer')
        for field in ('weight_bytes_per_param','kv_bytes_per_element','hbm_bandwidth_bytes_per_second'):
            v = getattr(self,field)
            if not math.isfinite(v) or v <= 0:
                raise ValueError(field+' must be positive finite')

    @property
    def weight_bytes(self)->float:
        self.validate()
        return self.params*self.weight_bytes_per_param

    @property
    def kv_bytes_per_context_token(self)->float:
        self.validate()
        return (2*self.layers*self.kv_heads*self.head_dim*
                self.kv_bytes_per_element*self.batch_size)

    def estimate(self,context:int)->dict:
        self.validate()
        if not isinstance(context,int) or context < 0:
            raise ValueError('context must be nonnegative integer')
        w = self.weight_bytes
        k = self.kv_bytes_per_context_token * context
        total = w+k
        return dict(
            context_tokens=context, weight_bytes=w, kv_bytes=k, total_bytes=total,
            kv_fraction_of_total=k/total,
            conditional_best_case_kv_elimination_gain=total/w,
            conditional_best_case_weight_halving_gain=total/(w/2+k),
            peak_bandwidth_floor_ms=1000*total/self.hbm_bandwidth_bytes_per_second,
            peak_bandwidth_floor_without_kv_ms=1000*w/self.hbm_bandwidth_bytes_per_second,
            required_weight_byte_saving_fraction_for_2x=(w+k)/(2*w),
        )

    @property
    def context_at_2x_kv_elimination(self)->int:
        self.validate()
        return math.ceil(self.weight_bytes/self.kv_bytes_per_context_token)


def report()->dict:
    basis=Scenario()
    cases={str(n):basis.estimate(n) for n in (0,4096,8192,32768,65536,131072)}
    variants={
      'bf16_batch1': {'scenario':asdict(basis),'at_8192':basis.estimate(8192),'threshold_2x':basis.context_at_2x_kv_elimination},
      'bf16_batch16': {'scenario':asdict(Scenario(batch_size=16)),'at_8192':Scenario(batch_size=16).estimate(8192),'threshold_2x':Scenario(batch_size=16).context_at_2x_kv_elimination},
      'int4_weights_batch1': {'scenario':asdict(Scenario(weight_bytes_per_param=0.5)),'at_8192':Scenario(weight_bytes_per_param=0.5).estimate(8192),'threshold_2x':Scenario(weight_bytes_per_param=0.5).context_at_2x_kv_elimination},
      'mha_32kv_batch1': {'scenario':asdict(Scenario(kv_heads=32)),'at_8192':Scenario(kv_heads=32).estimate(8192),'threshold_2x':Scenario(kv_heads=32).context_at_2x_kv_elimination},
    }
    return {
        'study':'G2 processor feasibility — conditional decode traffic bound',
        'date':'2026-11-03','version':'1.0',
        'status':'ANALYTIC ONLY — NOT GPU PERFORMANCE, NOT G5',
        'runtime':{'python':platform.python_version()},
        'source_gpu_bandwidth':'NVIDIA HGX reference architecture H200 SXM 4.8 TB/s; https://docs.nvidia.com/enterprise-reference-architectures/hgx-ai-factory-h100-h200-b200/latest/components.html',
        'model_basis':'Hypothetical 8B parameters, 32 layers, 8 KV heads, head dimension 128; not a measured/reproduced model.',
        'assumptions':[
          'Every decode step streams all model weights exactly once from HBM; no on-chip caching or reuse across requests.',
          'Each decode step streams K and V exactly once across entire context for each sequence.',
          'Weights and KV bytes share a common memory tier and effective bandwidth; no overlap modeled.',
          'No metadata, page tables, activation writes, interconnect, decode compute, launch, sampling, or kernel overhead.',
          '2x KV-elimination ratio is conditional on the above simplified serial traffic model, NOT a universal physical upper bound.',
          'Weights use exact nominal bytes-per-parameter; INT4 ignores scale/index/group and dequantization overhead.',
          'The peak bandwidth floor is optimistic and NOT measured latency or predicted throughput.',
          'GQA KV size is 2*layers*kv_heads*head_dim*context*batch*bytes_per_element.',
          'A factor-2 improvement in byte volume is NOT proof of a factor-2 speedup.',
        ],
        'base_scenario':asdict(basis),
        'contexts':cases,'variants':variants,
        'key_formulae':{
          'weight_bytes':'params * weight_bytes_per_param',
          'kv_bytes':'2 * layers * kv_heads * head_dim * context * batch * kv_bytes_per_element',
          'ideal_kv_elimination_gain':'(weight_bytes + kv_bytes) / weight_bytes',
          '2x_context_threshold':'ceil(weight_bytes / kv_bytes_per_context_token)',
        },
    }


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,default=Path('results/g2_memory_traffic_headroom.json'))
    args=p.parse_args()
    out=report()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print('saved',args.output)
    for key in ('4096','8192','32768','131072'):
        r=out['contexts'][key]
        print(f'{key} tokens: KV {r["kv_bytes"]/1e9:.3f} GB; max conditional KV-only gain {r["conditional_best_case_kv_elimination_gain"]:.5f}x')
    print('2x threshold:',out['variants']['bf16_batch1']['threshold_2x'],'tokens')


if __name__=='__main__': main()
