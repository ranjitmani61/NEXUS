#!/usr/bin/env python3
"""G3 precision audit: a falsifiable FP16/BF16 certificate-failure witness.

We model a *hypothetical* page-metadata datapath with serial, low-precision
multiplication and accumulation. The project's existing NumPy benchmark uses
float64 bounds, so the failures here are NOT measured failures in that code.

A standard gamma_(2d) roundoff envelope is used as a conservative guard for
individual dot products under stated IEEE round-to-nearest assumptions and
excluding non-finite/subnormal intermediate computation. This audit does NOT
establish an end-to-end hardware, softmax, or FPGA numerical guarantee.
"""
from __future__ import annotations
import argparse
import json
import math
import platform
from pathlib import Path
import numpy as np
import torch

TOL=0.02
DTYPES=(torch.float16,torch.bfloat16)
UNIT_ROUNDOFF={torch.float16: 2.0**-11, torch.bfloat16: 2.0**-8}
MIN_NORMAL={torch.float16:2.0**-14, torch.bfloat16:2.0**-126}


def serial_low_precision_dot(q:torch.Tensor,k:torch.Tensor):
    """Intentionally naive serial dot in *stored* dtype; not torch.dot()."""
    assert q.ndim == k.ndim == 1 and q.shape == k.shape and q.dtype == k.dtype
    dtype=q.dtype
    acc=torch.tensor(0.,dtype=dtype)
    for qi,ki in zip(q,k):
        acc=(acc + (qi*ki).to(dtype)).to(dtype)
    return float(acc)


def roundoff_interval(q:torch.Tensor,k:torch.Tensor):
    """A conservative floating-point error guard for the serial dot above.

    ASSUMPTIONS: IEEE RN for each primitive, no overflow or underflow in any
    nonzero intermediate, inputs representable and finite, and d*u*2 < 1.
    The dot error bound is gamma_(2d) times sum |q_i*k_i|. An extra float64
    computational padding is used for these finite audit vectors; this is NOT
    a formal machine-checked interval arithmetic implementation.

    Returns (low, high) for the UNNORMALIZED dot or None => dense fallback.
    """
    if q.ndim!=1 or k.ndim!=1 or q.shape!=k.shape or q.dtype!=k.dtype:
        return None
    dtype=q.dtype
    if dtype not in UNIT_ROUNDOFF or len(q)==0:
        return None
    if not bool(torch.isfinite(q).all() and torch.isfinite(k).all()):
        return None
    q64=q.to(torch.float64).numpy(); k64=k.to(torch.float64).numpy()
    tiny=MIN_NORMAL[dtype]
    # Conservatively decline cases with subnormal *inputs*. For generic
    # hardware arithmetic, FTZ/subnormal semantics must be characterized.
    if np.any((np.abs(q64)>0)&(np.abs(q64)<tiny)) or np.any((np.abs(k64)>0)&(np.abs(k64)<tiny)):
        return None
    acc=torch.tensor(0.,dtype=dtype)
    for qa,ka, qexact,kexact in zip(q,k,q64,k64):
        prod=(qa*ka).to(dtype)
        exact_product=float(qexact*kexact)
        if not bool(torch.isfinite(prod)):
            return None
        if 0<abs(exact_product)<tiny or (exact_product!=0 and float(prod)==0):
            return None
        exact_sum=float(acc)+float(prod)
        if 0<abs(exact_sum)<tiny:
            return None
        acc=(acc+prod).to(dtype)
        if not bool(torch.isfinite(acc)):
            return None
    d=len(q);u=UNIT_ROUNDOFF[dtype]
    if 2*d*u>=1:return None
    gamma=2*d*u/(1-2*d*u)
    magnitude=float(np.sum(np.abs(q64*k64),dtype=np.float64))
    if not np.isfinite(magnitude):return None
    acc_value=float(acc)
    pad=8*np.finfo(np.float64).eps*(1+abs(acc_value)+gamma*magnitude)
    bound=gamma*magnitude+pad
    return (acc_value-bound,acc_value+bound)


def exact_quantized_attention(q,k,v):
    """Float64 reference over the exactly represented quantized operands."""
    q64=q.to(torch.float64).numpy()
    k64=k.to(torch.float64).numpy()
    v64=v.to(torch.float64).numpy()
    scores=k64@q64/math.sqrt(len(q64))
    exp=np.exp(scores-scores.max())
    weights=exp/exp.sum()
    return weights@v64,weights,scores


def admission(q,k,tolerance,guarded):
    """One-key/page toy certificate, not a full page-screening engine."""
    d=len(q)
    if not (0<tolerance<2):raise ValueError('bad tolerance')
    estimates=[]
    for key in k:
        if guarded:
            interval=roundoff_interval(q,key)
            if interval is None:return {'admit':False,'reason':'precision_guard_fallback'}
            estimates.append([interval[0]/math.sqrt(d),interval[1]/math.sqrt(d)])
        else:
            s=serial_low_precision_dot(q,key)/math.sqrt(d)
            if not math.isfinite(s):return {'admit':False,'reason':'nonfinite_fallback'}
            estimates.append([s,s])
    bounds=np.asarray(estimates,dtype=np.float64)
    best=int(np.argmax(bounds[:,0]))
    others=np.delete(bounds[:,1],best)
    m=float(max(bounds[best,0],float(np.max(others))))
    numerator=float(np.exp(others-m).sum())
    denominator=float(np.exp(bounds[best,0]-m))
    certificate=float(2*numerator/(numerator+denominator))
    return {'admit':bool(certificate<=tolerance),'best':best,
            'certificate':certificate, 'intervals':bounds.tolist(),
            'reason':'certificate_admit' if certificate<=tolerance else 'dense_fallback'}


def witness(dtype):
    # This creates a cancellation when accumulated serially in FP16/BF16,
    # while the usual float32-accumulating PyTorch dot retains the middle term.
    middle=16 if dtype==torch.float16 else 8
    large=32768 if dtype==torch.float16 else 2048
    q=torch.tensor([1.,1.,1.],dtype=dtype)
    k=torch.tensor([[0.,10.,0.],[large,middle,-large]],dtype=dtype)
    v=torch.tensor([[1.,0.,0.],[-1.,0.,0.]],dtype=dtype)
    exact_output,weights,scores=exact_quantized_attention(q,k,v)
    naive=admission(q,k,TOL,guarded=False)
    guarded=admission(q,k,TOL,guarded=True)
    if not naive['admit']:
        raise AssertionError('Expected naive invalid admission')
    partial_output=v[int(naive['best'])].to(torch.float64).numpy()
    vnorm=float(torch.linalg.vector_norm(v.to(torch.float64),dim=-1).max())
    error=float(np.linalg.norm(exact_output-partial_output)/vnorm)
    if error<=TOL or error<=naive['certificate']:
        raise AssertionError('Constructed counterexample did not violate certificate')
    if guarded['admit']:
        raise AssertionError('Roundoff guard falsely admitted example')
    return {'dtype':str(dtype),'q':q.tolist(),'K':k.tolist(),
            'exact_scores':scores.tolist(),'exact_probabilities':weights.tolist(),
            'serial_dots':[serial_low_precision_dot(q,kk) for kk in k],
            'naive':naive,'actual_normalized_error':error,
            'guarded':guarded}


def random_interval_stress(dtype,n=1000,dim=8,seed=20261103):
    rng=np.random.default_rng(seed)
    tested=skipped=violations=0
    max_rel_slack=0.0
    for _ in range(n):
        q=torch.tensor(rng.normal(0,3,size=dim),dtype=dtype)
        k=torch.tensor(rng.normal(0,3,size=dim),dtype=dtype)
        interval=roundoff_interval(q,k)
        if interval is None:
            skipped+=1;continue
        tested+=1
        exact=float(np.dot(q.to(torch.float64).numpy(),k.to(torch.float64).numpy()))
        if not (interval[0]-1e-10<=exact<=interval[1]+1e-10):violations+=1
        slack=max(exact-interval[0],interval[1]-exact)
        max_rel_slack=max(max_rel_slack,slack/max(1,abs(exact)))
    if violations:raise AssertionError(f'{violations} guard violations')
    return {'dtype':str(dtype),'generated':n,'bounds_tested':tested,
            'fell_back':skipped,'violations':violations,
            'max_relative_slack':max_rel_slack}



def random_certification_stress(dtype,n=500,dim=8,seed=20261104):
    """Empirical end-to-end *certificate* check for two one-key pages.

    The target reference is exact (to float64 rounding) attention over the
    stored low-precision values; full model-quality effects are not tested.
    """
    rng=np.random.default_rng(seed)
    admitted=violations=0
    max_error=0.0
    for i in range(n):
        q=torch.tensor(rng.normal(size=dim),dtype=dtype)
        if i%2:
            k=np.vstack([rng.normal(size=dim),rng.normal(size=dim)])
        else:
            k=np.vstack([10*q.to(torch.float64).numpy(),-10*q.to(torch.float64).numpy()])
        keys=torch.tensor(k,dtype=dtype)
        values=torch.tensor(rng.normal(size=(2,dim)),dtype=dtype)
        decision=admission(q,keys,TOL,guarded=True)
        if not decision['admit']:continue
        admitted+=1
        full,_,_=exact_quantized_attention(q,keys,values)
        partial=values[decision['best']].to(torch.float64).numpy()
        maxnorm=float(np.linalg.norm(values.to(torch.float64).numpy(),axis=1).max())
        error=float(np.linalg.norm(full-partial)/maxnorm) if maxnorm else 0.
        max_error=max(max_error,error)
        if error>decision['certificate']+1e-10:violations+=1
    if violations:raise AssertionError(f'{violations} certified output violations')
    return {'dtype':str(dtype),'generated':n,'guarded_admissions':admitted,
            'violations':violations,'max_normalized_error':max_error}


def run():
    return {'protocol':{'gate':'G3','date':'2026-11-03',
        'scope':'hypothetical low precision serial metadata datapath; not current float64 implementation',
        'error_tolerance':TOL,'python':platform.python_version(),
        'numpy':np.__version__,'torch':torch.__version__,
        'limitations':['gamma interval assumes IEEE RN and no underflow/overflow',
            'float64 reference is not exact real arithmetic for arbitrary cases',
            'normalization, exp, division and attention-output rounding are not covered',
            'small synthetic witnesses and randomized dot-product audits only',
            'not representative pretrained-model data or hardware timing']},
        'witnesses':[witness(dtype) for dtype in DTYPES],
        'stress':[random_interval_stress(dtype) for dtype in DTYPES],
        'certificate_stress':[random_certification_stress(dtype) for dtype in DTYPES]}


def test_fp16_false_certificate():
    w=witness(torch.float16)
    assert w['naive']['certificate'] < TOL < w['actual_normalized_error']

def test_bf16_false_certificate():
    w=witness(torch.bfloat16)
    assert w['naive']['certificate'] < TOL < w['actual_normalized_error']

def test_fp16_guard_intervals():
    assert random_interval_stress(torch.float16,n=1000)['violations']==0

def test_bf16_guard_intervals():
    assert random_interval_stress(torch.bfloat16,n=1000)['violations']==0

def test_guard_can_admit_easy_case():
    for dtype in DTYPES:
        q=torch.tensor([1.,1.,1.],dtype=dtype)
        k=torch.tensor([[0.,20.,0.],[0.,-20.,0.]],dtype=dtype)
        r=admission(q,k,TOL,True)
        assert r['admit'] and r['certificate']<TOL

def test_guard_fallback_on_nonfinite_and_subnormal():
    for dtype in DTYPES:
        q=torch.tensor([1.,1.,1.],dtype=dtype)
        assert roundoff_interval(q,torch.tensor([float('nan'),1.,2.],dtype=dtype)) is None
        assert roundoff_interval(q,torch.tensor([float('inf'),1.,2.],dtype=dtype)) is None
    q=torch.tensor([1.,1.,1.],dtype=torch.float16)
    assert roundoff_interval(q,torch.tensor([2**-20,1.,2.],dtype=torch.float16)) is None

def test_fp16_certified_output():
    assert random_certification_stress(torch.float16)['violations']==0

def test_bf16_certified_output():
    assert random_certification_stress(torch.bfloat16)['violations']==0

def test_shape_guard():
    q=torch.tensor([1.,1.,1.],dtype=torch.float16)
    assert roundoff_interval(q,torch.tensor([1.,1.],dtype=torch.float16)) is None
    assert roundoff_interval(q,torch.tensor([1.,1.,1.],dtype=torch.float32)) is None


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,default=Path('results/g3_reduced_precision_audit.json'))
    args=p.parse_args()
    out=run();args.output.parent.mkdir(exist_ok=True,parents=True)
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'witnesses':[{'dtype':r['dtype'],
        'naive_certificate':r['naive']['certificate'],
        'true_error':r['actual_normalized_error'],
        'guarded_status':r['guarded']['reason']} for r in out['witnesses']],
        'stress':out['stress'],'certificate_stress':out['certificate_stress']},indent=2))
    print(f'Saved {args.output}')

if __name__=='__main__':main()
