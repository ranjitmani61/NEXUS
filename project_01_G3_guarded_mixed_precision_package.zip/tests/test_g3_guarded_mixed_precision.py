"""Property, failure, precision, and CPU screening tests for G3 audit."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import numpy as np
import pytest
from g3_guarded_mixed_precision_audit import (
    FORMATS, TOLERANCE, gen_case, PageCache, PageMetadata, dense,
    guarded_admission, guarded_page_score_intervals, query, benchmark, test_counterexample as witness_check,
)

@pytest.mark.parametrize('fmt',FORMATS)
def test_cancellation_witness_is_safe(fmt):
    K,Q,V=gen_case('cancellation',0,pages=2,size=1,d=3,queries=1,fmt=fmt)
    c=PageCache(K,V,1);m=PageMetadata(c)
    out,yes,bound,reason=query(c,m,Q[0])
    assert np.allclose(out,dense(c,Q[0]),rtol=1e-13,atol=1e-13)
    if yes: assert 0 <= bound <= TOLERANCE

@pytest.mark.parametrize('fmt',FORMATS)
@pytest.mark.parametrize('kind',['clustered','random','uniform','needle'])
def test_full_reference_agreement(fmt,kind):
    K,Q,V=gen_case(kind,27,pages=16,size=8,d=32,queries=8,fmt=fmt)
    c=PageCache(K,V,8);m=PageMetadata(c)
    vmax=max(np.linalg.norm(c.V,axis=1))
    for q in Q:
        out,yes,bound,reason=query(c,m,q)
        error=np.linalg.norm(out-dense(c,q))/vmax
        assert error<=TOLERANCE+1e-11
        if yes: assert error<=bound+1e-11

@pytest.mark.parametrize('fmt',FORMATS)
def test_stale_version_forces_dense(fmt):
    K,Q,V=gen_case('clustered',27,pages=16,size=8,d=32,queries=1,fmt=fmt)
    c=PageCache(K,V,8);m=PageMetadata(c)
    c.version+=1
    out,yes,bound,reason=query(c,m,Q[0])
    assert not yes and reason=='stale_version'
    assert np.array_equal(out,dense(c,Q[0]))

@pytest.mark.parametrize('fmt',FORMATS)
def test_bad_q_forces_dense(fmt):
    K,Q,V=gen_case('random',27,pages=16,size=8,d=32,queries=1,fmt=fmt)
    c=PageCache(K,V,8);m=PageMetadata(c)
    q=Q[0].copy();q[0]=np.nan
    a=guarded_admission(c,m,q)
    assert not a[0] and a[3]=='nonfinite'

@pytest.mark.parametrize('fmt',FORMATS)
def test_synthetic_favorable_admits(fmt):
    K,Q,V=gen_case('clustered',27,pages=16,size=8,d=32,queries=3,fmt=fmt)
    c=PageCache(K,V,8);m=PageMetadata(c)
    for q in Q:
        out,yes,bound,reason=query(c,m,q)
        assert yes and bound<TOLERANCE

@pytest.mark.parametrize('fmt',FORMATS)
def test_synthetic_random_falls_back(fmt):
    K,Q,V=gen_case('random',27,pages=16,size=8,d=32,queries=3,fmt=fmt)
    c=PageCache(K,V,8);m=PageMetadata(c)
    for q in Q:
        assert not guarded_admission(c,m,q)[0]

@pytest.mark.parametrize('fmt',FORMATS)
def test_quantized_vs_original_not_promised(fmt):
    # Identity target here: quantized reference. No bound on original q/k quantization.
    K,Q,V=gen_case('random',27,pages=4,size=4,d=8,queries=1,fmt=fmt)
    c=PageCache(K,V,4);m=PageMetadata(c)
    out,*_=query(c,m,Q[0])
    assert np.allclose(out,dense(c,Q[0]))

@pytest.mark.parametrize('fmt',FORMATS)
@pytest.mark.parametrize('seed',range(10))
def test_random_guarantee_small_cases(fmt,seed):
    K,Q,V=gen_case('random',seed,pages=4,size=3,d=16,queries=4,fmt=fmt)
    c=PageCache(K,V,3);m=PageMetadata(c)
    for q in Q:
        out,yes,bound,reason=query(c,m,q)
        error=np.linalg.norm(out-dense(c,q))/max(np.linalg.norm(V,axis=1))
        if yes: assert error<=bound+1e-11


def test_bad_tolerance():
    K,Q,V=gen_case('random',27,pages=4,size=4,d=8,queries=1,fmt='fp16')
    c=PageCache(K,V,4);m=PageMetadata(c)
    with pytest.raises(ValueError):guarded_admission(c,m,Q[0],eps=-1)


@pytest.mark.parametrize('fmt',FORMATS)
@pytest.mark.parametrize('kind',['clustered','random','uniform','needle'])
@pytest.mark.parametrize('d',[16,64,128])
def test_fp32_guard_intervals_contain_every_exact_token_score(fmt,kind,d):
    K,Q,V=gen_case(kind,37,pages=8,size=4,d=d,queries=5,fmt=fmt)
    c=PageCache(K,V,4);m=PageMetadata(c)
    for q in Q:
        lo,hi,reason=guarded_page_score_intervals(c,m,q)
        assert reason=='ok'
        actual=(c.K64@q.astype('float64')).reshape(c.pages,c.size)/np.sqrt(c.d)
        assert np.all(lo[:,None] <= actual + 1e-12)
        assert np.all(actual <= hi[:,None] + 1e-12)

@pytest.mark.parametrize('fmt',FORMATS)
def test_fp32_guard_cancellation_interval(fmt):
    K,Q,V=gen_case('cancellation',0,pages=2,size=1,d=3,queries=1,fmt=fmt)
    c=PageCache(K,V,1);m=PageMetadata(c)
    lo,hi,reason=guarded_page_score_intervals(c,m,Q[0])
    actual=(c.K64@Q[0].astype('float64'))/np.sqrt(3)
    assert np.all(lo <= actual) and np.all(actual <= hi)
