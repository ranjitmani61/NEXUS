"""G2: ideal two-Poisson-channel shot-noise RMS and sustained flux audit.

Not measured hardware; neither a universal quantum-optics limit nor a bound on tail risk.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import numpy as np

H = 6.62607015e-34
C = 299792458.0
E_CHARGE = 1.602176634e-19
DEFAULT_WAVELENGTH_M = 1550e-9
DEFAULT_LINK_DETECTION = 0.10
DEFAULT_WALL = 0.20


def positive_finite(x, name):
    if not isinstance(x, (float, int)) or isinstance(x, bool) or not math.isfinite(x) or x <= 0:
        raise ValueError(f'{name}: must be positive and finite')


def evaluate(kappa, eps, rate, wavelength=DEFAULT_WAVELENGTH_M, link=DEFAULT_LINK_DETECTION, wall=DEFAULT_WALL):
    for k,v in (('kappa',kappa),('eps',eps),('rate',rate),('wavelength',wavelength),('link',link),('wall',wall)):
        positive_finite(v,k)
    if kappa < 1: raise ValueError('kappa must >= 1')
    if eps >= 1: raise ValueError('eps must < 1')
    if link > 1 or wall > 1: raise ValueError('efficiency must <= 1')
    detected_photons = (kappa/eps)**2
    photon_j = H*C/wavelength
    detected_energy_j = detected_photons * photon_j
    electrical_energy_j = detected_energy_j / (link * wall)
    return {
        'kappa':kappa, 'rms_target':eps, 'operations_per_s':rate,
        'detected_photons_per_op':detected_photons,
        'shot_noise_rms_relative':kappa/math.sqrt(detected_photons),
        'detected_photon_energy_nj_per_op':detected_energy_j*1e9,
        'assumed_electrical_energy_nj_per_op':electrical_energy_j*1e9,
        'aggregate_detector_current_amp':detected_photons*rate*E_CHARGE,
        'assumed_dynamic_electrical_power_w':electrical_energy_j*rate,
        'throughput_ceiling_at_10mA_aggregate':.010/(detected_photons*E_CHARGE),
    }


def monte_carlo(kappa, N=100000, n_trials=40000, seed=20261104):
    positive_finite(kappa,'kappa')
    positive_finite(N,'N')
    if kappa < 1: raise ValueError('kappa must >= 1')
    if not isinstance(n_trials,int) or n_trials < 100: raise ValueError('invalid trials')
    rng = np.random.default_rng(seed)
    mean_plus = N/2*(1+1/kappa)
    mean_minus = N/2*(1-1/kappa)
    observed = rng.poisson(mean_plus, size=n_trials)-rng.poisson(mean_minus, size=n_trials)
    expected = N/kappa
    measured_rms = float(np.sqrt(np.mean(((observed-expected)/expected)**2)))
    exact = kappa/math.sqrt(N)
    return {'kappa':kappa, 'detected_photon_mean_per_op':N,'trials':n_trials,'seed':seed,
            'relative_rms_observed':measured_rms,'relative_rms_theory':exact,
            'relative_deviation':abs(measured_rms-exact)/exact}


def audit():
    rows = [evaluate(k,e,r) for k in [1,10,100,1000] for e in [.01,.02] for r in [1e6,1e8,1e9]]
    mc = [monte_carlo(k) for k in [1,10,100]]
    reference=evaluate(1000,.01,1e8)
    return {
        'version':'1.0', 'date':'2026-11-04', 'kind':'derived hypothetical throughput and energy calculations with ideal Poisson Monte Carlo cross-check',
        'photon_energies_from':'h*c/wavelength; h and c exact SI',
        'assumed_wavelength_nm':1550,'assumed_link_plus_detection_efficiency':.10,'assumed_wall_plug_efficiency':.20,
        'rows':rows,'monte_carlo':mc,
        'illustrative_kappa1000_eps1percent_R1e8':reference,
        'hypothetical_digital_baseline_nj':30,
        'best_case_no_go_vs_30nj_under_assumptions':reference['assumed_electrical_energy_nj_per_op']>30,
        'notes':[
           'RMS noise criterion only; NOT a high-confidence relative error bound or per-operation reliability promise',
           'Only two independent Poisson channels and direct difference estimator; NOT a universal optical/computation lower bound',
           'Power and throughput are assumptions, not chip or detector measurements',
           'Aggregate detector current may be spread across many devices and time channels',
           'Excludes calibration pilots, drift, ADC/DAC, heaters, cooling, fallback, model-specific accuracy, queueing and interconnect',
           'No measured matched digital baseline or actual AI workload cancellation statistics',
        ],
        'gate_decision':'G2 photonic physical feasibility HOLD; generic G1 novelty not established; G5 blocked; G6 not authorized',
    }


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',default='results/g2_photonic_detector_flux_audit.json')
    a=p.parse_args()
    result=audit()
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result, indent=2)+'\n')
    for k in [1,10,100,1000]:
        r=evaluate(k,.01,1e8)
        print(f'kappa={k:4d}, N={r["detected_photons_per_op"]:.3g}, E_el={r["assumed_electrical_energy_nj_per_op"]:.6g} nJ/op, I={r["aggregate_detector_current_amp"]:.6g} A')
    print('Poisson checks:',[round(x['relative_deviation'],4) for x in result['monte_carlo']])
    print('G2 HOLD; no new photonic hardware result')

if __name__=='__main__':main()
