import math
import pytest
from g2_photonic_detector_flux_audit import evaluate, monte_carlo, audit, E_CHARGE, H, C


def test_si_constants():
    assert H == 6.62607015e-34
    assert C == 299792458


@pytest.mark.parametrize('k', [1,10,100,1000])
@pytest.mark.parametrize('e',[0.01,0.02])
def test_rms_target(k,e):
    r=evaluate(k,e,1e8)
    assert math.isclose(r['shot_noise_rms_relative'],e,rel_tol=1e-12)
    assert math.isclose(r['detected_photons_per_op'], (k/e)**2, rel_tol=1e-12)


def test_energy_and_current_units():
    r=evaluate(1000,.01,1e8)
    assert math.isclose(r['aggregate_detector_current_amp'],r['detected_photons_per_op']*1e8*E_CHARGE,rel_tol=1e-13)
    assert math.isclose(r['assumed_dynamic_electrical_power_w'],r['assumed_electrical_energy_nj_per_op']*1e-9*1e8,rel_tol=1e-13)


def test_kappa_scaling():
    a=evaluate(10,.01,1e6); b=evaluate(100,.01,1e6)
    assert math.isclose(b['detected_photons_per_op']/a['detected_photons_per_op'],100,rel_tol=1e-13)
    assert math.isclose(b['assumed_electrical_energy_nj_per_op']/a['assumed_electrical_energy_nj_per_op'],100,rel_tol=1e-13)


def test_epsilon_scaling():
    a=evaluate(100,.01,1e6); b=evaluate(100,.02,1e6)
    assert math.isclose(b['assumed_electrical_energy_nj_per_op']/a['assumed_electrical_energy_nj_per_op'],.25,rel_tol=1e-13)


def test_throughput_scaling():
    a=evaluate(100,.01,1e6); b=evaluate(100,.01,1e9)
    assert a['detected_photons_per_op']==b['detected_photons_per_op']
    assert math.isclose(b['aggregate_detector_current_amp']/a['aggregate_detector_current_amp'],1000,rel_tol=1e-13)


def test_efficiency_scaling():
    a=evaluate(100,.01,1e6,link=.1,wall=.2);b=evaluate(100,.01,1e6,link=.5,wall=.5)
    assert b['assumed_electrical_energy_nj_per_op']<a['assumed_electrical_energy_nj_per_op']


@pytest.mark.parametrize('kwargs',[
    {'kappa':0}, {'kappa':.9}, {'eps':0}, {'eps':1}, {'rate':0}, {'kappa':float('nan')},
    {'wall':0}, {'link':1.01}, {'wavelength':-1}
])
def test_invalid(kwargs):
    args=dict(kappa=10,eps=.01,rate=1e8);args.update(kwargs)
    with pytest.raises(ValueError):evaluate(**args)


@pytest.mark.parametrize('k',[1,10,100])
def test_monte_carlo_independent(k):
    row=monte_carlo(k)
    assert row['relative_deviation'] < .05


def test_predeclared_matrix():
    rows=audit()['rows']
    assert len(rows)==4*2*3
    assert audit()['best_case_no_go_vs_30nj_under_assumptions'] is True


def test_numerical_current_cap():
    r=evaluate(1000,.01,1e8)
    ceiling=r['throughput_ceiling_at_10mA_aggregate']
    assert math.isclose(r['detected_photons_per_op']*ceiling*E_CHARGE,.010,rel_tol=1e-12)
