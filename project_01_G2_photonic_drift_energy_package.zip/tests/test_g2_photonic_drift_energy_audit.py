import sys
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0,str(Path(__file__).parent))
from g2_photonic_drift_energy_audit import bound_reductions, energy_model, scenario, PHOTON_J, unmodeled_jump_control
from g2_photonic_count_certificate import admission


def test_photon_energy_si():
    assert 1.2e-19 < PHOTON_J < 1.4e-19


def test_pilot_overhead_amortized():
    assert energy_model(1,1)['detected_photons_per_reduction'] == 300_000_000
    assert energy_model(100,1)['detected_photons_per_reduction'] == 102_000_000
    assert energy_model(100,0)['digital_baseline_break_even_nj_per_reduction'] is None


def test_energy_decreases_as_k_increases():
    assert energy_model(1,.5)['illustrative_optical_nj_per_reduction'] > energy_model(10,.5)['illustrative_optical_nj_per_reduction']


def test_identical_interval_at_zero_drift_guard():
    cp=np.array([[10_000_000,10_000_000]],dtype=np.int64)
    cm=np.array([[0,0]],dtype=np.int64)
    rp=np.array([[100_000_000]],dtype=np.int64)
    rm=np.array([[100_000_000]],dtype=np.int64)
    a=bound_reductions(cp,cm,rp,rm,1e7,1e8,.001,0,[1,2])
    b=bound_reductions(cp,cm,rp,rm,1e7,1e8,.001,0,[100,200])
    for x,y in zip(a,b): np.testing.assert_array_equal(x,y)


def test_gain_uncertainty_never_narrows_interval():
    cp=np.array([[10_000_000,10_100_000]],dtype=np.int64)
    cm=np.array([[8_000_000,8_200_000]],dtype=np.int64)
    rp=np.array([[100_000_000]],dtype=np.int64)
    rm=np.array([[100_000_000]],dtype=np.int64)
    _,l0,u0=bound_reductions(cp,cm,rp,rm,1e8,1e8,.001,0,[1,2])
    _,l1,u1=bound_reductions(cp,cm,rp,rm,1e8,1e8,.001,.001,[1,2])
    assert np.all(l1<=l0) and np.all(u1>=u0)


def test_admission_monotone_with_guard():
    cp=np.array([[100_000_000,100_000_000]],dtype=np.int64)
    cm=np.array([[0,0]],dtype=np.int64)
    rp=np.array([[100_000_000]],dtype=np.int64)
    rm=np.array([[100_000_000]],dtype=np.int64)
    a=bound_reductions(cp,cm,rp,rm,1e8,1e8,.001,0,[1,2])
    b=bound_reductions(cp,cm,rp,rm,1e8,1e8,.001,.01,[1,2])
    assert np.all(admission(*b)<=admission(*a))


def test_invalid_config_rejected():
    cp=np.array([[1]],dtype=np.int64); r=np.array([[1]],dtype=np.int64)
    with pytest.raises(ValueError):bound_reductions(cp,cp,r,r,1,1,.001,1.,[1])
    with pytest.raises(ValueError):bound_reductions(cp,cp,r,r,1,1,.001,-1.,[1])
    with pytest.raises(ValueError):bound_reductions(cp,cp,r,r,1,1,.001,0,[-1])
    with pytest.raises(ValueError):energy_model(1,1.1)


def test_safe_scenario_has_no_false_in_seeded_case():
    r=scenario(20261103,8,.0001,2,cycles=15)
    assert r['guarded']['false_admissions']==0


def test_no_drift_same_modes():
    r=scenario(20261103,16,0,2,cycles=10)
    assert r['guarded']['admitted']==r['stale_unsafe']['admitted']
    assert r['guarded']['false_admissions']==r['stale_unsafe']['false_admissions']


def test_unmodeled_jump_invalidates_certificate():
    r=unmodeled_jump_control(cycles=40,k=8)
    assert r['false_admissions'] > 0
    assert r['admitted'] > 0
