"""G2 drift/calibration/energy audit. Synthetic Poisson optical receiver, NOT hardware data.

Architecture protocol: specs/G2_photonic_drift_energy_contract.md.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
from g2_photonic_count_certificate import garwood, admission

ALPHA=1e8
H=1e8
EPS=.01
DELTA_CYCLE=.001
CYCLES=40
SEEDS=(20261103,20261104)
KS=(1,8,64,256)
DRIFT=(0.,1e-5,1e-4)
KAPPAS=(1,2,10)
PLANCK=6.62607015e-34
LIGHT=299792458
WAVELENGTH=1550e-9
PHOTON_J=PLANCK*LIGHT/WAVELENGTH
ETA_WALL=.2
ETA_TRANSMIT=.1
FIXED_NJ=10.0


def bound_reductions(cp,cm,rp,rm,alpha,h,delta,drift_bound,age, pilot_delta_fraction=.5):
    """Simultaneous family-wise (per cycle) two-sided Poisson intervals.

    Per detector pilot has beta=delta/4, per data detector beta=delta/(4*K).
    Gain drift bounded multiplicatively relative to gain at pilot.
    """
    cp=np.asarray(cp); cm=np.asarray(cm); rp=np.asarray(rp); rm=np.asarray(rm)
    if cp.ndim != 2 or cp.shape != cm.shape or rp.shape != (cp.shape[0],1) or rm.shape != rp.shape:
        raise ValueError('expected 2D data and column pilot arrays')
    if not (0<delta<1 and h>0 and alpha>0 and drift_bound>=0):
        raise ValueError('invalid parameters')
    n,k=cp.shape
    age=np.broadcast_to(np.asarray(age,dtype=float).reshape(1,k),(n,k))
    if np.any(age<0): raise ValueError('negative elapsed time')
    frac=drift_bound*age
    if np.any(frac>=1):
        raise ValueError('gain bound cannot be nonpositive')
    # Bonferroni: pilot half and all data within this cycle half.
    beta_pilot=delta/4
    beta_data=delta/(4*k)
    pl,pu=garwood(rp,beta_pilot)
    ml,mu=garwood(rm,beta_pilot)
    p_gain_lo=(pl/h)*(1-frac)
    p_gain_hi=(pu/h)*(1+frac)
    m_gain_lo=(ml/h)*(1-frac)
    m_gain_hi=(mu/h)*(1+frac)
    dl,du=garwood(cp,beta_data)
    el,eu=garwood(cm,beta_data)
    with np.errstate(divide='ignore',invalid='ignore'):
        lower=dl/(alpha*p_gain_hi)-eu/(alpha*m_gain_lo)
        upper=du/(alpha*p_gain_lo)-el/(alpha*m_gain_hi)
        est=cp/(alpha*(rp/h))-cm/(alpha*(rm/h))
    valid=(pl>0)&(ml>0)&(rp>0)&(rm>0)
    lower=np.where(valid,lower,-np.inf)
    upper=np.where(valid,upper,np.inf)
    est=np.where(valid,est,np.nan)
    return est,lower,upper


def energy_model(k, admission_rate, alpha=ALPHA, h=H, fixed_nj=FIXED_NJ,
                 eta_wall=ETA_WALL, eta_transmit=ETA_TRANSMIT,
                 data_expected_photons=None, pilot_expected_photons=None):
    if not (k>=1 and 0<=admission_rate<=1 and 0<eta_wall<=1 and 0<eta_transmit<=1 and fixed_nj>=0):
        raise ValueError('invalid energy parameter')
    # Assumes unit total signed source magnitude (P+M=1), baseline detector gains ~1.
    data_ph = alpha if data_expected_photons is None else float(data_expected_photons)
    pilot_ph = 2*h if pilot_expected_photons is None else float(pilot_expected_photons)
    if data_ph < 0 or pilot_ph < 0:
        raise ValueError('photons must be nonnegative')
    photons=data_ph+pilot_ph/k
    min_laser_nj=photons*PHOTON_J/(eta_wall*eta_transmit)*1e9
    optical_nj=min_laser_nj+fixed_nj
    # Digital fallback if not certified; the digital energy baseline is unknown.
    digital_break_even_nj=(optical_nj/admission_rate if admission_rate>0 else None)
    return {'detected_photons_per_reduction':photons,
            'ideal_laser_supply_nj':min_laser_nj,
            'assumed_fixed_electronics_nj':fixed_nj,
            'illustrative_optical_nj_per_reduction':optical_nj,
            'digital_baseline_break_even_nj_per_reduction':digital_break_even_nj,
            'note':'Does not include fallback timing, A/D conversion detail, tuning, idle power, device area, chip interconnect.'}


def scenario(seed, k, rho, kappa, cycles=CYCLES, alpha=ALPHA, h=H):
    rng=np.random.default_rng(seed)
    s=1/kappa
    p=(1+s)/2
    m=(1-s)/2
    age=np.arange(1,k+1,dtype=float)
    g_pilot_p=1.02
    g_pilot_m=.98
    # Opposite maximum-rate signed drift: the worst direction for signed cancellation.
    gp=g_pilot_p*(1+rho*age)
    gm=g_pilot_m*(1-rho*age)
    rp=rng.poisson(h*g_pilot_p,(cycles,1))
    rm=rng.poisson(h*g_pilot_m,(cycles,1))
    cp=rng.poisson(alpha*p*gp,(cycles,k))
    cm=rng.poisson(alpha*m*gm,(cycles,k))
    expected_data_photons=alpha*float(np.mean(p*gp+m*gm))
    expected_pilot_photons=h*(g_pilot_p+g_pilot_m)
    out={}
    for name,declared_bound in [('guarded',rho),('stale_unsafe',0.)]:
        est,lo,hi=bound_reductions(cp,cm,rp,rm,alpha,h,DELTA_CYCLE,declared_bound,age)
        admitted=admission(est,lo,hi,EPS)
        actual_err=np.abs(est-s)/s
        false=admitted&(actual_err>EPS)
        covered=(lo<=s)&(s<=hi)
        rate=float(np.mean(admitted))
        out[name]={
            'reads':cycles*k,'admitted':int(admitted.sum()),'false_admissions':int(false.sum()),
            'interval_misses':int((~covered).sum()),
            'admit_rate':rate,'max_actual_relative_error_admitted':(
                float(np.max(actual_err[admitted])) if admitted.any() else None),
            'laser_energy_model':energy_model(k,rate,
                data_expected_photons=expected_data_photons,
                pilot_expected_photons=expected_pilot_photons),
            'per_age_admission':admitted.mean(axis=0).tolist(),
            'per_age_false':false.sum(axis=0).tolist(),
        }
    return out


def unmodeled_jump_control(seed=20261105, cycles=80, k=8, jump=.02):
    """Adversarial control: signed input unchanged but gains jump outside declared model."""
    rng=np.random.default_rng(seed)
    pilot_gp=1.02; pilot_gm=.98
    rp=rng.poisson(H*pilot_gp,(cycles,1))
    rm=rng.poisson(H*pilot_gm,(cycles,1))
    # kappa=1 => positive channel only; a common +2% post-pilot drift biases by ~2%.
    cp=rng.poisson(ALPHA*pilot_gp*(1+jump),(cycles,k))
    cm=np.zeros((cycles,k),dtype=np.int64)
    age=np.arange(1,k+1,dtype=float)
    est,lo,hi=bound_reductions(cp,cm,rp,rm,ALPHA,H,DELTA_CYCLE,1e-5,age)
    admit=admission(est,lo,hi,EPS)
    err=np.abs(est-1)
    return {'k':k,'cycles':cycles,'reads':cycles*k,'jump':jump,
            'declared_max_rate_per_readout':1e-5,
            'admitted':int(np.sum(admit)),
            'false_admissions':int(np.sum(admit&(err>EPS))),
            'interval_misses':int(np.sum(~((lo<=1)&(hi>=1))))}


def run_all():
    rows=[]
    for k in KS:
        for rho in DRIFT:
            for kappa in KAPPAS:
                for seed in SEEDS:
                    r=scenario(seed,k,rho,kappa)
                    rows.append({'k':k,'rho':rho,'kappa':kappa,'seed':seed,
                                 **{mode:{key:value for key,value in r[mode].items()
                                          if key not in ('per_age_admission','per_age_false')}
                                    for mode in ('guarded','stale_unsafe')}})
    agg=[]
    for k in KS:
        for rho in DRIFT:
            for kap in KAPPAS:
                rs=[r for r in rows if r['k']==k and r['rho']==rho and r['kappa']==kap]
                obj={'k':k,'rho':rho,'kappa':kap,'n_reads':sum(r['guarded']['reads'] for r in rs)}
                for mode in ('guarded','stale_unsafe'):
                    total=sum(r[mode]['reads'] for r in rs)
                    admitted=sum(r[mode]['admitted'] for r in rs)
                    obj[mode]={'admission_pct':round(100*admitted/total,3),
                               'false_admissions':sum(r[mode]['false_admissions'] for r in rs),
                               'interval_misses':sum(r[mode]['interval_misses'] for r in rs),
                               'break_even_digital_energy_nj':(rs[0][mode]['laser_energy_model']['illustrative_optical_nj_per_reduction']/(admitted/total) if admitted else None)}
                obj['photon_overhead_ratio']=1+2/k
                obj['optical_energy_nj_assumed']=rs[0]['guarded']['laser_energy_model']['illustrative_optical_nj_per_reduction']
                agg.append(obj)
    return {'type':'synthetic numerical Poisson model not optical hardware',
            'protocol':'specs/G2_photonic_drift_energy_contract.md','seeds':SEEDS,
            'k':KS,'rho':DRIFT,'kappas':KAPPAS,'cycles_per_seed':CYCLES,
            'eps':EPS,'delta_familywise_per_cycle':DELTA_CYCLE,'alpha':ALPHA,'pilot_h_each':H,
            'assumptions':{'wavelength_nm':1550,'laser_wallplug_efficiency_illustrative':ETA_WALL,
                           'channel_plus_detector_efficiency_illustrative':ETA_TRANSMIT,
                           'fixed_electronics_nj_illustrative':FIXED_NJ,
                           'drift_model':'deterministic opposite signed linear, upper bound rho per data readout',
                           'familywise_allocation':'2 pilots each delta/4; 2K data each delta/(4K)',
                           'energy_formula':'E= hc/lambda*(expected_data_photons+expected_pilot_photons/K)/(eta_laser*eta_path)+E_fixed',
                           'digital_comparison':'break even if E_digital > E_optical/admission fraction; no actual digital E known'},
            'unmodeled_jump_negative_control':unmodeled_jump_control(),
            'summary':agg,'rows':rows}


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--output',default='/mnt/data/results/g2_photonic_drift_energy_audit.json')
    args=parser.parse_args()
    out=Path(args.output);out.parent.mkdir(exist_ok=True,parents=True)
    results=run_all();out.write_text(json.dumps(results,indent=2))
    for row in results['summary']:
        print(f"K={row['k']:3} slope={row['rho']:.5f} kappa={row['kappa']:2}  safe={row['guarded']['admission_pct']:5.1f}% invalid_unsafe={row['stale_unsafe']['false_admissions']:3} break_even_nJ={row['guarded']['break_even_digital_energy_nj']}")
    print('Saved',out)

if __name__=='__main__': main()
