# Project 01: Evidence-first AI processor research — 2026-11-03

## Rules
No fabricated measurements or novelty claims. Separate observed calculations from hypotheses, and reject failed designs.

## Scope and engineering owners
First target: long-context transformer inference at batch size 1. Roles: computer architecture, applied mathematics, compiler/runtime, digital logic/verification, ML benchmarking. Semiconductor/device and packaging specialists become necessary later.

## Known prior art; novelty status
**Not novel at this stage.** Block-sparse attention, attention bounds, memory-side acceleration, and runtime-certified attention already have literature. Relevant 2026 research includes "Certified Block Screening for Adaptive Long-Context Attention", "Runtime-Certified Bounded-Error Quantized Attention", "Elastic Threshold Attention", and "Efficiently Approximating Attention Is Hard". A patent and paper investigation would be required before claiming novelty or freedom to operate.

## Initial falsifiable research question
Can attention-block metadata reduce total key/value movement while certifying an output-error limit, and in which input regimes does this fail?

## Experiment (simulation; not a chip)
Reproducible NumPy baseline script: `processor_baseline.py`. Parameters: seed 20261103, 128 blocks, 32 keys per block, 64 dimensions, tolerance 0.02 (normed by maximum value-vector norm), 32-bit representations.

For each block, compute mean key c and maximum key radius r. Then every score is bounded above by `(q · c + ||q|| r)/sqrt(d)` by Cauchy–Schwarz. Evaluate blocks descending by this upper bound. Let U be a bound on total unvisited softmax mass and Z the visited exact mass. For visited-only output O_v and dense output O, `||O-O_v|| / max_i ||v_i|| <= 2U/(Z+U)` in exact arithmetic. The experiment stops when this certificate is <= 0.02.

### Results
| Synthetic input | KV blocks loaded | Total estimated memory traffic versus dense | Certificate | Observed normalized output error |
|---|---:|---:|---:|---:|
| Strongly clustered keys, concentrated attention | 1 / 128 | 2.368% | 0.00093911 | 0.00004268 |
| Unstructured independent Gaussian keys | 128 / 128 | 101.587% | 0 | 0 |

Estimated traffic includes all precomputed centroid/radius metadata and fetched float32 KV records per query. It excludes metadata construction, cache effects, transfers between physical memory tiers, runtime scheduling, interconnect cost, energy, clock frequency, and hardware area. The clustered case was deliberately constructed to be favorable; these numbers are **not** representative workload performance or chip-level speedup.

## Decision
The known method is sensitive to input structure. On unstructured data, metadata adds traffic. Do not claim a breakthrough; the promising result is purely a validation of the baseline and its failure mode.

## Next experiment and stop conditions
1. Test actual model KV-cache traces over multiple real models, tasks, layers, and context lengths; compare against full-attention and prior sparse-attention methods.
2. Verify worst-case output error and end-to-end model quality. Use multi-seed variance, not a single favorable instance.
3. Quantify metadata construction/update cost, total bytes and bandwidth, end-to-end latency, and energy. Record overhead at batch 1 and large batches.
4. Seek a genuinely new mechanism **only if** existing mechanisms cannot achieve the required trade-off and any proposed new mechanism differs materially from prior art.
5. Reject the concept if accuracy/latency/energy gains cannot be demonstrated on representative workloads after costs and baselines are included.

## Update: 2026-11-03 engineering gate audit

Per `AGENTS.md` v1.0, the old prototype was read and reproduced. A new pre-registered 4-regime × 12-seed × 2-bound study and 192 smaller property checks were executed: `tests/attention_screening_audit.py`, machine-readable `results/attention_screening_audit.json`. No observed numerical certificate violations in 288 cases. The representative traffic comparison **does not support a broad benefit**: center/radius median modeled traffic without metadata construction is 2.39% clustered, 101.61% random, 100.83% uniform, and 101.22% rare-needle cases. Including conservative full-cache metadata-build traffic for one query makes clustered 102.39%. These are modeled bytes, not time/energy or model quality.

Strong direct prior art includes QUEST, SparQ, BLASST and especially a 2026 center/radius-screening preprint. See `research/G1_prior_art_review.md` for source URLs and status. G0 exploratory charter PASS; G1 remains IN PROGRESS; G2–G12 remain not established for a new processor. See `specs/G0_benchmark_contract.md` and `reviews/2026-11-03_gate_review.md`.

## Update: 2026-11-03 G2 feasibility (Anchor-Delta reuse)

Per `AGENTS.md`, G2 tested a **hypothesis**, not a claimed invention: cache per-page score bounds from an anchor query and reuse them for subsequent nearby queries via a safe query-difference/norm bound. On static synthetic KV, 1,120 query simulations and 900 supplemental property checks detected no violations within stated numerical tolerances. Favorable tightly correlated clustered queries gave **0.4286× the modeled per-query-metadata-and-KV-read traffic of the tested fresh screening baseline**; reducing correlation to 0.90 yielded **14.5102× worse traffic** in that regime. If full page metadata is already cached on-chip, the modeled byte savings disappear. An append-only KV counterexample shows why stale metadata breaks certification.

**Decision:** Formula feasible in exact arithmetic; not demonstrated novel, not robust, and **not authorized for hardware implementation** based on current evidence. Detailed artifacts: `specs/G2_anchor_delta_hypothesis.md`, `tests/g2_anchor_delta_audit.py`, `tests/g2_anchor_delta_properties.py`, `results/g2_anchor_delta_audit.json`, `results/g2_anchor_delta_properties.json`, `reviews/2026-11-03_G2_anchor_delta_review.md`. G1 and overall G2 remain IN PROGRESS.

## Update: 2026-11-03 G3/G4 growing KV and untrained transformer trace audit

Following `AGENTS.md` v1.0, the project tested exactly maintained page certificates under autoregressive growth and a two-layer, four-head, **untrained** causal RoPE transformer. In 48 layer/head/sequence/model-seed traces (2,304 decode queries) no page-bound or output-certificate violations were detected in float64. An additional 1,920 growing-KV property checks found no violations; a deliberate stale-metadata counterexample produced a false certificate (reported 0.00067 versus true normalized error 1.0). The invariant requires refreshing bounds before any new key is exposed.

The negative performance result is decisive **for this untrained toy distribution only**: both fresh and reused methods read >99.99% of the dense KV bytes; candidate read traffic was about 101.30% of dense with cold metadata and about 100.91% when metadata is hot (model assumes float32 bytes, float64 math). Because no KV was meaningfully skipped, the candidate did not improve against dense. The measured numeric results are CPU mathematical simulations, **not** hardware latency/energy gains or a representative LLM benchmark. Prior art for consecutive-query reuse further includes TokenSelect (2024).

**Decision:** retain anchor-delta as non-novel reference; **do not proceed to hardware** from this evidence. G3 and G4 remain IN PROGRESS; G5 is BLOCKED pending pretrained-model traces and optimized matched baselines. Full details at `reviews/2026-11-03_G3_G4_toy_trace_review.md`, `specs/G3_growing_kv_invariant.md`, machine-readable `results/g3_g4_toy_trace_audit.json` and `results/g3_dynamic_kv_properties.json`.

## Update: 2026-11-03 G4 perfect-information oracle and output-error gap

Read `AGENTS.md` v1.0 before work. A new 640-query experiment on an **UNTRAINED** 512-token transformer (`tests/g4_oracle_headroom_audit.py`) compared the original geometric certificate to an exact per-page score-max oracle and a perfect-information mass oracle. Under the existing normalized error tolerance 0.02, **all 640 queries required 100% of pages to satisfy the mass-based certificate** for all three methods. A hindsight value-error comparison, requiring full QK scores and values and therefore providing **no executable savings**, met the numerical output tolerance with a median of 81.25% of pages. A constructed uniform-logits/constant-values control requires 127/128 pages under the mass-only certificate despite its exact output being recoverable from one page. Brute-force enumeration independently validated the mass-oracle calculation in 720 small random cases. This pinpoints a **certificate limitation** for the tested distributions; it is not an impossibility theorem about all sparse attention.

**Decision:** Reject query-delta mass-only screening as a hardware development thesis on current evidence. G1 and G4 remain IN PROGRESS; G5 remains BLOCKED by absence of representative pretrained traces and optimized full-system measurements. Existing output-/value-aware research (2021–2026) further limits novelty. No RTL, hardware, or cloud resource was provisioned. See `reviews/2026-11-03_G4_oracle_headroom_review.md`, `results/g4_oracle_headroom_audit.json`, `results/g4_oracle_properties.json`.

## Update: 2026-11-03 value-geometry certificate G3/G4 audit

Read `AGENTS.md` v1.0 and prior tests. Derived and implemented a sufficient exact-arithmetic value-aware output-error certificate using per-page value means/radii and query/key score upper bounds. On 1,600 small independently brute-force-checked fractional-box optima and 480 independently generated random attention examples, no numerical violations were detected. A further **640 untrained** transformer attention queries also showed no detected violations. **However the candidate skipped zero pages on all 640**; an impractical exact-page-max-score oracle likewise skipped none. The median candidate per-query proxy traffic was **103.38%** of dense; the earlier mass-only reference was **101.69%**.

Constructed identical/near-identical value controls selected **1/128 pages** with **4.10% modeled traffic**, but independent random and pagewise value controls selected all pages (**103.32%** proxy traffic). In a 3-seed, 2,048-token noise-sensitivity control, σ≤0.01 selected 1/64 pages; σ=0.03 selected a median 63/64; σ≥0.1 selected all 64. **These favorable cases are artificial and sensitive to the value distribution.** Metadata construction/update, bound-computation, actual caching, and latency are excluded from the percentages.

**Decision:** Useful mathematical bound and falsifying tests; **REJECT value-geometry screening as a current hardware thesis.** It is not established novel. G3/G4 remain in progress on limited numerical tests; G5 remains blocked by lack of pretrained models and optimized real-hardware baselines. See `specs/G4_value_geometry_certificate.md`, `tests/g4_value_geometry_certificate.py`, `tests/g4_value_geometry_sensitivity.py`, `results/g4_value_geometry_*.json`, `reviews/2026-11-03_G4_value_geometry_review.md`. `AGENTS.md` unchanged.

## Update: 2026-11-03 G5 pretrained diagnostic harness readiness

Read `AGENTS.md` and prior G4 work before proceeding. Verified the official Pythia-14M model exists, but pretrained weights are unavailable locally, HTTPS model downloads fail in this workspace and cloud Jobs are pay-per-use. **No pretrained model was run, no cloud spending or chip experiment occurred.** Implemented a portable `tests/g5_trace_oracle.py` offline oracle evaluator and `tests/g5_pythia_capture.py` trained-model capture script (not yet integration-tested with a live pretrained model). Local PyTorch/NumPy unit tests: **11 passed**, including 250 brute-force objective checks, 120 randomized adverse configurations, and mock attention/V reconstruction. Five entirely **synthetic** page-probability/V fixtures produced median mass-oracle page fraction 1.0 and median value-oracle fraction 0.78125 (best 0.03125); these oracles require full attention data and **are not achievable inference speedups**. G5 remains BLOCKED; Pythia-14M's 2K context is only a future capture pilot and cannot satisfy the long-context G5 contract. See `specs/G5_pretrained_trace_protocol.md`, `reviews/2026-11-03_G5_harness_readiness_review.md`, `results/g5_trace_pipeline_smoke.json`, and `results/g5_harness_environment.json`. AGENTS.md unchanged, no G6 hardware authorization.

## Update: 2026-11-03 trained attention control (G4 exploratory)

Read `AGENTS.md` and G5 protocol. Because real pretrained weights are still inaccessible locally (no paid cloud provisioned), trained a CPU-only, 128-slot, single-head softmax lookup attention module on a **synthetic address-retrieval task** with three seeds. On 1,920 oracle evaluations (5 regimes × 3 seeds × 128 queries), the mass certificate selected a median 1/8 KV pages with sharply learned attention, 5/8 under a 2% uniform mixture, and 8/8 under a 20% mixture; untrained control required 8/8. Exact attention and V were fully evaluated before page selection, hence **none are realizable speedups**. A precision test initially failed due to an overly strict 1e-9 tolerance for float32 and was corrected to 2e-7. All 13 final tests passed, and rerunning the full audit produced byte-identical JSON. This only confirms extreme selectivity under memorized synthetic addresses and sensitivity to diffusion; it **does not clear G5** or demonstrate a novel processor. See `reviews/2026-11-03_G4_learned_attention_control_review.md`, `tests/g5_learned_control_audit.py`, `tests/test_g5_learned_control.py`, and `results/g5_learned_control_audit.json`.

## Update: 2026-11-03 G4 executable CPU certificate/fallback performance audit

Read `AGENTS.md` before work; applied A1/A2/A3/A4/A6/A8/A10/A11 review lenses. The pretrained G5 model route remained unavailable (no checkpoint locally, missing Transformers package, and Hugging Face DNS download unavailable), so **no G5 pretrained results were produced** and no paid remote job was launched.

Executed real local FP64 NumPy CPU timing against matching exact dense attention for two fixed seeds and four explicitly synthetic data regimes (clustered, random, uniform and needle), 20 correlated queries per seed. Tested a known-adjacent mathematical idea: one-page admission when a conservative page-key center/radius lower/upper bound certifies the 2% normalized output-error tolerance; otherwise compute exact dense attention. Two complete corrected v1.1 runs each included **160 timed queries** and no detected numerical violations; 27 combined automated tests passed.

On deliberately clustered data, all 40 queries per run were admitted with only one out of 128 pages; per-query candidate/dense measured CPU latency median ratio was 0.234–0.242, and including a one-time key metadata build amortized over 20 static-K queries yielded total ratio 0.670–0.717. The observed static-K break-even was about 11–13 queries. **This does not predict dynamic autoregressive KV-cache results.** On random, uniform and needle cases, none were admitted, and the fallback's median CPU latency ratio was 1.21–1.26 (roughly 20–26% slower); Q20 amortization further penalized the method. All results are tiny synthetic CPU reference measurements, NOT GPU speedups, hardware power, or pretrained quality.

Correction to exploratory v1.0 cost accounting: a full V vector norm scan was incorrectly charged as necessary online metadata; it is only needed for offline normalized-error verification. The retained v1.0 files are not overwritten; v1.1 uses a key-only metadata build timer. Negative results unchanged. Relevant source: QUEST 2024 already uses query-aware page summaries; the tested admission policy is **NOT established novel**. See `specs/G4_cpu_admission_cost_model.md`, `reviews/2026-11-03_G4_cpu_admission_review.md`, `tests/g4_hybrid_admission_benchmark.py`, `tests/test_g4_hybrid_admission.py`, `results/g4_hybrid_admission_v1_1_rep1.json`, `results/g4_hybrid_admission_v1_1_rep2.json` and `results/g4_hybrid_final_pytest.txt`.

Decision: G4 IN PROGRESS (new CPU reference evidence, insufficient strong baselines), G5 BLOCKED pending trained-model evidence. G6–G12 not authorized. No processor breakthrough demonstrated.
