#!/usr/bin/env python3
"""Project 01: executable CPU reference timing, v1.0 (2026-11-03).

Purpose: falsify the assumption that reduced modeled KV-page reads imply
lower end-to-end execution latency. This is a NumPy CPU reference benchmark,
not GPU/ASIC benchmarking. It uses synthetic attention, not a trained model.

Run:
  cd /mnt/data
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python tests/g4_executable_cpu_timing.py \
      --output results/g4_executable_cpu_timing.json
"""
from __future__ import annotations
import argparse
import json
import math
import os
import platform
import statistics
import time
from pathlib import Path
import numpy as np

B = 128
L = 32
D = 64
TOL = 0.02
SEEDS = (1029, 1031)
QUERIES = 20
REPEATS = 3


def build_problem(seed: int, kind: str):
    rng = np.random.default_rng(seed)
    q0 = rng.normal(size=D)
    v = rng.normal(size=(B, L, D)).astype(np.float64)
    if kind == 'clustered':
        center = rng.normal(size=(B, D))
        center[11] = 1.5 * q0 + rng.normal(0, .15, size=D)
        k = center[:, None, :] + rng.normal(0, .04, size=(B, L, D))
    elif kind == 'random':
        k = rng.normal(size=(B, L, D))
    else:
        raise ValueError(kind)
    # Similar successive queries are not representative of all trained LLMs.
    q = q0[None, :] + rng.normal(0, .025, size=(QUERIES, D))
    return q, np.ascontiguousarray(k), np.ascontiguousarray(v)


def precompute(k, v):
    # Explicitly charge the one-time key AND value scans necessary for metadata.
    centers = k.mean(axis=1)
    radius = np.linalg.norm(k - centers[:, None, :], axis=-1).max(axis=1)
    vmax = float(np.linalg.norm(v, axis=-1).max())
    return centers, radius, vmax


def dense_attention(q, k, v):
    score = np.matmul(k.reshape(-1, q.size), q) / math.sqrt(q.size)
    ex = np.exp(score - score.max())
    return (ex @ v.reshape(-1, q.size)) / ex.sum()


def certified_screen(q, k, v, meta, tol=TOL):
    centers, radius, vmax = meta
    b,l,d = k.shape
    upper = (centers @ q + np.linalg.norm(q)*radius)/math.sqrt(d)
    order = np.argsort(-upper, kind='stable')
    shift = float(upper.max())
    mass_upper = l * np.exp(upper[order] - shift)
    remaining_upper = float(mass_upper.sum())
    sum_w = 0.0
    sum_wv = np.zeros(d, dtype=np.float64)
    chosen = 0
    cert = 2.0
    for j, idx in enumerate(order):
        # Only read full K/V for selected block; metadata was already built.
        scores = k[idx] @ q / math.sqrt(d)
        weight = np.exp(scores - shift)
        sum_w += float(weight.sum())
        sum_wv += weight @ v[idx]
        remaining_upper = float(max(0.0, remaining_upper - mass_upper[j]))
        # Safe *real arithmetic* bound, verified numerically in float64.
        cert = 2.0 * remaining_upper / (sum_w + remaining_upper)
        chosen = j+1
        if cert <= tol:
            break
    if sum_w <= 0:
        raise ArithmeticError('zero accumulated weight')
    return sum_wv/sum_w, chosen, cert, vmax


def call_timed(fn, repeats=REPEATS):
    times=[]
    result=None
    for _ in range(repeats):
        start = time.perf_counter_ns()
        result=fn()
        times.append((time.perf_counter_ns()-start)/1e6)
    return float(np.median(times)), result


def run():
    rows=[]
    for regime in ('clustered','random'):
        for seed in SEEDS:
            qs,k,v = build_problem(seed, regime)
            # Build-time measurement separately, with no free cached summaries.
            build_ms, meta = call_timed(lambda:precompute(k,v),repeats=5)
            # Warm both paths to reduce first-call confounds.
            for q in qs[:3]:
                dense_attention(q,k,v)
                certified_screen(q,k,v,meta)
            for qi,q in enumerate(qs):
                # Alternate measurement order across queries.
                if qi % 2:
                    sparse_ms, sparse = call_timed(lambda:certified_screen(q,k,v,meta))
                    dense_ms, dense = call_timed(lambda:dense_attention(q,k,v))
                else:
                    dense_ms, dense = call_timed(lambda:dense_attention(q,k,v))
                    sparse_ms, sparse = call_timed(lambda:certified_screen(q,k,v,meta))
                approx, pages, cert, vmax = sparse
                err=float(np.linalg.norm(approx-dense)/vmax)
                if err > cert + 2e-10 or cert > TOL + 2e-10:
                    raise AssertionError((regime,seed,qi,pages,err,cert))
                rows.append({
                    'regime':regime, 'seed':seed, 'query':qi,
                    'selected_pages':pages,'page_fraction':pages/B,
                    'dense_latency_ms':dense_ms,'sparse_latency_ms':sparse_ms,
                    'metadata_build_ms_median':build_ms,
                    'relative_output_error':err,'certificate':float(cert),
                    'latency_ratio_sparse_over_dense':sparse_ms/dense_ms,
                    # Metadata bytes and KV bytes assumed float64; not observed DRAM counters.
                    'modeled_total_bytes_ratio_no_build':
                        ((pages*L*D*2)+(B*(D+2))) / (B*L*D*2),
                })
    summary=[]
    for regime in ('clustered','random'):
        rr=[x for x in rows if x['regime']==regime]
        dm=np.array([x['dense_latency_ms'] for x in rr]); sm=np.array([x['sparse_latency_ms'] for x in rr]);
        bm=np.array([x['metadata_build_ms_median'] for x in rr]);
        q=np.array([x['page_fraction'] for x in rr]);
        # Constructions below represent Q consecutive queries sharing metadata.
        item={
            'regime':regime, 'queries':len(rr),
            'median_selected_pages':float(np.median([r['selected_pages'] for r in rr])),
            'median_page_fraction':float(np.median(q)),
            'median_modeled_traffic_no_build':float(np.median([r['modeled_total_bytes_ratio_no_build'] for r in rr])),
            'p50_dense_ms':float(np.median(dm)),
            'p50_candidate_ms':float(np.median(sm)),
            'p95_dense_ms':float(np.percentile(dm,95)),
            'p95_candidate_ms':float(np.percentile(sm,95)),
            'median_latency_ratio':float(np.median(sm/dm)),
            'amortized_ratio_with_build_Q1':float((sm.sum()+len(rr)*float(np.median(bm)))/dm.sum()),
            'amortized_ratio_with_build_Q20':float((sm.sum()+len(rr)/20*float(np.median(bm)))/dm.sum()),
            'max_error':float(max(x['relative_output_error'] for x in rr)),
            'max_certificate':float(max(x['certificate'] for x in rr)),
            'certificate_violations':0,
        }
        summary.append(item)
    return {
        'metadata':{
            'date':'2026-11-03','version':'1.0','gate':'G4 performance falsification, not G5 real workloads',
            'type':'ACTUAL WALL-CLOCK CPU MEASUREMENT + MODELED BYTE COUNTS',
            'model':'NONE, artificially synthetic q/K/V',
            'processor':platform.processor(), 'python':platform.python_version(),
            'numpy':np.__version__,'blas_env':{k:os.getenv(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')},
            'dtype':'float64','blocks':B,'block_length':L,'dimension':D,
            'tolerance_normalized_L2':TOL,'seeds':list(SEEDS), 'queries_per_seed':QUERIES,'timing_repeats_per_query':REPEATS,
            'important_limitations':[
                'No pretrained model, GPU/ASIC, end-to-end LLM decoding, throughput, energy or silicon measurement',
                'Python loop and NumPy library calls dominate sparse CPU runtime; cannot project to accelerator PPA',
                'Even dense baseline is a NumPy reference, not optimized FlashAttention/other top baseline',
                'Simulated byte ratio assumes full K/V page reads and metadata; not hardware DRAM traffic measurement',
                'Cache warmup affects timing; outputs are on this machine only',
                'Build amortization uses observed metadata-build wall time spread over Q queries; Q=1/20 illustrative',
            ],
        },'summary':summary,'rows':rows,
    }


def main():
    pa=argparse.ArgumentParser()
    pa.add_argument('--output',type=Path,default=Path('results/g4_executable_cpu_timing.json'))
    args=pa.parse_args()
    result=run()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result['summary'],indent=2))
    print('saved',args.output.resolve())

if __name__=='__main__':main()
