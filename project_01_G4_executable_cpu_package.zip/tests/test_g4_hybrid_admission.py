"""Numerical and negative-control verification of conservative one-page admission."""
import numpy as np
import pytest
from g4_hybrid_admission_benchmark import admit_one_page,case_problem,build_online_key_metadata
from g4_executable_cpu_timing import B,L,D,TOL,precompute,dense_attention

@pytest.mark.parametrize('regime',['clustered','random','uniform','needle'])
@pytest.mark.parametrize('seed',[1029,1031,4567])
def test_admission_matches_certificate(regime,seed):
    qs,k,v=case_problem(seed,regime)
    meta=build_online_key_metadata(k)
    for q in qs[::3]:
        pred,pages,mode,cert=admit_one_page(q,k,v,meta)
        dense=dense_attention(q,k,v)
        true_error=np.linalg.norm(pred-dense)/np.linalg.norm(v,axis=-1).max()
        assert cert>=0 and cert<=TOL+2e-10
        assert true_error<=cert+2e-10
        assert mode in ('certified_single_page','exact_dense_fallback')
        assert pages == (1 if mode=='certified_single_page' else B)

def test_admission_does_not_use_full_k_on_fallback_by_inference():
    # Unstructured should trigger fallback; no selectivity promise.
    qs,k,v=case_problem(1029,'random')
    mode=admit_one_page(qs[0],k,v,build_online_key_metadata(k))[2]
    assert mode=='exact_dense_fallback'

def test_bad_shape_rejected():
    q,k,v=case_problem(1029,'clustered')
    with pytest.raises(ValueError):
        admit_one_page(q[0,:-1],k,v,build_online_key_metadata(k))
