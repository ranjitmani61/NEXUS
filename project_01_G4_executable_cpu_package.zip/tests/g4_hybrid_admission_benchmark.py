#!/usr/bin/env python3
"""Project 01 G4 v1: certified one-page admission vs exact dense fallback.

Novelty NOT claimed. Reports measured local CPU reference latency, not accelerator
performance, model quality, or pretrained workloads.
"""
from __future__ import annotations
import argparse,json,math,os,platform,sys,time
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).parent))
from g4_executable_cpu_timing import (B,L,D,TOL,SEEDS,QUERIES,REPEATS,
   dense_attention, build_problem,call_timed)


def build_online_key_metadata(k):
    """Only the online summaries needed by admission. No offline V scans."""
    center = k.mean(axis=1)
    radius = np.linalg.norm(k-center[:,None,:],axis=-1).max(axis=1)
    return center,radius


def admit_one_page(q,k,v,metadata,tol=TOL):
    """If conservative preflight certifies single page, read it; else exact dense.

    Proven real-arithmetic guarantee (if metadata current):
      score_i in [q.c_b-||q||r_b, q.c_b+||q||r_b]/sqrt(d)
      U_rest <= L sum_{b != j} exp(upper_b)
      Z_j >= L exp(lower_j).
      Err/Vmax <= 2 U_rest/(Z_j + U_rest).
    Floating-point computation is checked numerically, not formally rounded.
    """
    centers,radius=metadata[:2]
    b,l,d=k.shape
    if not (b>0 and l>0 and d==len(q) and centers.shape==(b,d) and radius.shape==(b,)):
        raise ValueError('invalid q/K/metadata shapes')
    base=(centers @ q)/math.sqrt(d)
    fuzz=np.linalg.norm(q)*radius/math.sqrt(d)
    upper=base+fuzz
    lower=base-fuzz
    best=int(np.argmax(upper))
    sh=float(np.max(upper))
    # Bound every omitted token mass above, and selected page mass below.
    exp_u=l*np.exp(upper-sh)
    omit=float(exp_u.sum()-exp_u[best])
    zlower=float(l*np.exp(lower[best]-sh))
    cert=2*omit/(omit+zlower) if omit+zlower else 2.0
    if cert <= tol:
        scores=k[best]@q/math.sqrt(d)
        ww=np.exp(scores-scores.max())
        return ww@v[best]/ww.sum(),1,'certified_single_page',float(cert)
    return dense_attention(q,k,v),b,'exact_dense_fallback',0.0


def case_problem(seed,regime):
    if regime in ('clustered','random'):return build_problem(seed,regime)
    rng=np.random.default_rng(seed)
    q0=rng.normal(size=D)
    q=q0[None,:]+rng.normal(0,.025,size=(QUERIES,D))
    v=rng.normal(size=(B,L,D))
    if regime=='uniform':k=np.zeros((B,L,D))
    elif regime=='needle':
        k=rng.normal(size=(B,L,D)); k[-1,-1]=2*q0
    else:raise ValueError(regime)
    return q,np.ascontiguousarray(k),np.ascontiguousarray(v)


def run():
    rows=[]
    for regime in ('clustered','random','uniform','needle'):
        for seed in SEEDS:
            qs,k,v=case_problem(seed,regime)
            # Offline verification uses Vmax but it is not required for online admission.
            # Do not bill the V scan as a hardware metadata prerequisite.
            validation_vmax=float(np.linalg.norm(v,axis=-1).max())
            build_ms,meta=call_timed(lambda:build_online_key_metadata(k),repeats=5)
            for q in qs[:2]:
                dense_attention(q,k,v); admit_one_page(q,k,v,meta)
            for qi,q in enumerate(qs):
                if qi%2:
                    hybrid_ms,out=call_timed(lambda:admit_one_page(q,k,v,meta))
                    dense_ms,truth=call_timed(lambda:dense_attention(q,k,v))
                else:
                    dense_ms,truth=call_timed(lambda:dense_attention(q,k,v))
                    hybrid_ms,out=call_timed(lambda:admit_one_page(q,k,v,meta))
                approx,pages,mode,certificate=out
                err=float(np.linalg.norm(approx-truth)/validation_vmax)
                if err > certificate+2e-10 or certificate > TOL+2e-10:
                    raise AssertionError((regime,seed,qi,mode,err,certificate))
                rows.append({'regime':regime,'seed':seed,'query':qi,
                  'mode':mode,'selected_pages':pages,
                  'hybrid_ms':hybrid_ms,'dense_ms':dense_ms,
                  'build_ms':build_ms,'actual_normalized_error':err,
                  'certificate':certificate})
    summary=[]
    for regime in ('clustered','random','uniform','needle'):
        rr=[r for r in rows if r['regime']==regime]
        dm=np.array([r['dense_ms'] for r in rr]); hm=np.array([r['hybrid_ms'] for r in rr]);
        bm=np.median([r['build_ms'] for r in rr]);
        summary.append({'regime':regime,'queries':len(rr),
           'admission_rate':float(np.mean([r['mode']=='certified_single_page' for r in rr])),
           'p50_dense_ms':float(np.median(dm)),'p50_hybrid_ms':float(np.median(hm)),
           'p95_dense_ms':float(np.percentile(dm,95)),'p95_hybrid_ms':float(np.percentile(hm,95)),
           'median_hybrid_over_dense':float(np.median(hm/dm)),
           'mean_dense_ms':float(dm.mean()),'mean_hybrid_ms':float(hm.mean()),
           'build_ms_median':float(bm),
           'break_even_queries_if_positive':float(bm/(dm.mean()-hm.mean())) if dm.mean()>hm.mean() else None,
           'Q1_amortized_ratio':float((hm.sum()+len(rr)*bm)/dm.sum()),
           'Q20_amortized_ratio':float((hm.sum()+len(rr)/20*bm)/dm.sum()),
           'max_actual_error':float(max(r['actual_normalized_error'] for r in rr)),
           'violations':0})
    return {'metadata':{
       'date':'2026-11-03','version':'1.1','gate':'G4', 'type':'local CPU measured timings',
       'precision':'float64; real-arithmetic certificate numerically tested',
       'non_novelty':'Simple sufficient bound + exact fallback. Known-adjacent idea, not novelty proven.',
       'scope':'synthetic attention; NumPy reference; no pretrained traces or optimized GPU baselines',
       'block_count':B,'block_len':L,'head_dim':D,'seed_list':list(SEEDS),
       'queries_per_seed':QUERIES,'repeats':REPEATS,'tolerance':TOL,
       'environment':{'python':platform.python_version(),'numpy':np.__version__,
           'OPENBLAS_NUM_THREADS':os.environ.get('OPENBLAS_NUM_THREADS'),
           'OMP_NUM_THREADS':os.environ.get('OMP_NUM_THREADS')},
       'limitations':[
          'One-page admission is conservative, can miss profitable multi-page sparse queries',
          'Dense fallback is exact but still pays preflight metadata reads/computation',
          'No finite-precision formal guarantee, FP64 numerically checked only',
          'Only K center/radius metadata construction is charged; offline Vmax error checking is excluded',
          'Metadata builds and refreshes are not free; include amortized CPU build time',
          'No trained LLM quality, ppa, thermal, energy or accelerator benchmarks',
          'Benchmark is Python/NumPy and cache-sensitive; not evidence for actual processor advantage',
       ]},'summary':summary,'rows':rows}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=Path('results/g4_hybrid_admission_benchmark.json'))
    a=parser.parse_args()
    out=run()
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out['summary'],indent=2))
    print('saved',a.output.resolve())

if __name__=='__main__':main()
