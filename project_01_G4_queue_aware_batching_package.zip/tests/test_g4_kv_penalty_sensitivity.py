import unittest
from g4_kv_penalty_sensitivity import service_with_penalty

class KvPenaltyTests(unittest.TestCase):
    def test_zero(self): self.assertEqual(service_with_penalty({'1':2.0,'8':12.0},0),{1:2.0,8:12.0})
    def test_linear(self): self.assertEqual(service_with_penalty({'1':2.0,'8':12.0},1.0),{1:3.0,8:20.0})
    def test_negative(self):
        with self.assertRaises(ValueError): service_with_penalty({'1':2},-1)

if __name__=='__main__': unittest.main()
