"""G4: CPU projection microbenchmark + deterministic discrete-event batching toy simulator.

This is NOT a model inference benchmark; not a novel processor mechanism.
Reproduce: OPENBLAS_NUM_THREADS=1 python tests/g4_queue_aware_batching.py
"""
from __future__ import annotations
import argparse
import bisect
import json
import math
import os
import platform
import statistics
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits, threadpool_info

@dataclass(frozen=True)
class Policy:
    name: str
    cap: int
    window_ms: float = 0.0


def simulate(arrivals_ms: list[float], service_ms: dict[int,float], policy: Policy) -> dict:
    """Single server. All requests perform one independent projection; FCFS batching.

    Windowing starts when server idle and first queued request is eligible; server
    dispatches immediately when batch fills. Service time is per batch, no preemption.
    """
    if policy.cap < 1 or policy.window_ms < 0:
        raise ValueError('invalid policy')
    if any(not math.isfinite(x) or x < 0 for x in arrivals_ms):
        raise ValueError('invalid arrival')
    if any(a>b for a,b in zip(arrivals_ms,arrivals_ms[1:])):
        raise ValueError('arrivals not sorted')
    if len(arrivals_ms)==0:
        return {'count':0,'p50_ms':0,'p95_ms':0,'p99_ms':0,'max_ms':0,
                'makespan_ms':0,'throughput_s':0,'batches':0,'mean_batch':0,
                'queue_wait_p95_ms':0,'completion_times_ms':[],'batch_sizes':[]}
    for b in range(1,policy.cap+1):
        if b not in service_ms or service_ms[b]<=0 or not math.isfinite(service_ms[b]):
            raise ValueError('invalid service curve')
    n=len(arrivals_ms)
    i=0
    now=0.0
    completion=[]
    wait=[]
    batch_sizes=[]
    while i<n:
        now=max(now,arrivals_ms[i])
        if policy.window_ms:
            close=arrivals_ms[i]+policy.window_ms
            if i+policy.cap-1 < n:
                close=min(close, arrivals_ms[i+policy.cap-1])
            now=max(now,close)
        available=bisect.bisect_right(arrivals_ms,now)-i
        count=min(policy.cap, available)
        assert 1<=count<=policy.cap
        finish=now+service_ms[count]
        for j in range(i,i+count):
            completion.append(finish)
            wait.append(now-arrivals_ms[j])
        batch_sizes.append(count)
        i+=count
        now=finish
    lats=np.asarray(completion)-np.asarray(arrivals_ms)
    makespan=now-arrivals_ms[0]
    return {'count':n,'p50_ms':float(np.percentile(lats,50)),
            'p95_ms':float(np.percentile(lats,95)),
            'p99_ms':float(np.percentile(lats,99)),
            'max_ms':float(np.max(lats)),
            'makespan_ms':float(makespan),
            'throughput_s':float(1000*n/makespan),
            'batches':len(batch_sizes),
            'mean_batch':n/len(batch_sizes),
            'queue_wait_p95_ms':float(np.percentile(wait,95)),
            'completion_times_ms':completion,'batch_sizes':batch_sizes}


def arrival_trace(kind:str, seed:int, n:int, rate_s:float)->list[float]:
    rng=np.random.default_rng(seed)
    if kind=='poisson':
        out=np.cumsum(rng.exponential(1000/rate_s,size=n))
    elif kind=='bursty':
        # Simultaneous arrivals are a deliberate burst-stress scenario.
        burst_size=16
        out=np.repeat(np.arange(math.ceil(n/burst_size))*burst_size*1000/rate_s,
                      burst_size)[:n]
    else: raise ValueError(kind)
    return out.tolist()


def measure(N=4096, seed=81, reps=5)->dict:
    rng=np.random.default_rng(seed)
    W=np.asarray(rng.standard_normal((N,N)),dtype=np.float32,order='F')
    X=np.asarray(rng.standard_normal((N,32)),dtype=np.float32,order='F')
    Y=np.empty((N,32),dtype=np.float32,order='F')
    raw={}
    with threadpool_limits(limits=1):
        for b in rng.permutation(np.arange(1,33)):
            b=int(b)
            if b==1:
                def fn(): np.dot(W,X[:,0],out=Y[:,0])
            else:
                def fn(b=b): np.matmul(W,X[:,:b],out=Y[:,:b])
            for _ in range(2): fn()
            times=[]
            for _ in range(reps):
                start=time.perf_counter_ns(); fn(); times.append((time.perf_counter_ns()-start)/1e6)
            raw[b]=times
    # Independent GEMV route as numerical cross-check; the prior W@X check used
    # the same GEMM backend as the tested implementation and was too weak.
    reference=np.column_stack([W@X[:,j] for j in range(32)])
    max_error=float(np.max(np.abs(reference-Y)))
    if not np.allclose(reference,Y,rtol=6e-4,atol=2e-3):
        raise AssertionError('batch and GEMV outputs disagree')
    return {'N':N,'seed':seed,'reps':reps,
            'raw_ms':{str(k):v for k,v in sorted(raw.items())},
            'service_ms':{b:float(statistics.median(v)) for b,v in raw.items()},
            'max_abs_difference_vs_independent_gemv':max_error }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',default='results/g4_queue_aware_batching.json')
    ap.add_argument('--dimension',type=int,default=4096)
    ap.add_argument('--reps',type=int,default=5)
    args=ap.parse_args()
    # Two independent CPU timing runs to check result sensitivity.
    curves=[measure(N=args.dimension,seed=s,reps=args.reps) for s in (81,82)]
    policies=[Policy('serial',1),Policy('greedy_8',8),
              Policy('greedy_32',32),Policy('window_32_2ms',32,2),
              Policy('window_32_8ms',32,8)]
    cases=[]
    for kind in ('poisson','bursty'):
        for rate_s in (150,300,450,650):
            for seed in (101,102,103):
                a=arrival_trace(kind,seed,1200,rate_s)
                for idx,curve in enumerate(curves):
                    for policy in policies:
                        r=simulate(a,curve['service_ms'],policy)
                        # Omit raw completion times from output to keep artifact small
                        r.pop('completion_times_ms'); r.pop('batch_sizes')
                        cases.append({'kind':kind,'rate_s':rate_s,'seed':seed,
                            'timing_run':idx+1,'policy':policy.name,**r})
    out={'title':'G4 modeled queue-delay stress test, backed by CPU projection service curves',
         'date':'2026-11-03',
         'disclaimer':'CPU matrix projection kernels + discrete-event simulated arrivals; no pretrained LLM, GPU, KV cache, real serving or new hardware',
         'curves':[{'N':c['N'],'seed':c['seed'],'reps':c['reps'],
                    'raw_ms':c['raw_ms'],
                    'service_ms':{str(b):t for b,t in sorted(c['service_ms'].items())},
                    'max_abs_difference_vs_independent_gemv':c['max_abs_difference_vs_independent_gemv']} for c in curves],
         'workloads':{'arrivals': 'Poisson or idealized burst of 16 simultaneous arrivals',
                      'requests_per_trace':1200,'rates_s':[150,300,450,650],
                      'seeds':[101,102,103], 'precision':'float32',
                      'kernel':'one-thread OpenBLAS single GEMV b1; GEMM b2..32'},
         'policies':[p.__dict__ for p in policies],
         'environment':{'python':platform.python_version(),'numpy':np.__version__,
                        'blas':threadpool_info()},'cases':cases}
    p=Path(args.output); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(out,indent=2))
    for kind in ('poisson','bursty'):
        for rate in (150,300,450,650):
            print(kind,rate)
            for policy in policies:
                rows=[r for r in cases if r['kind']==kind and r['rate_s']==rate and r['policy']==policy.name]
                print(' ',policy.name,'p95_ms',round(statistics.median(r['p95_ms'] for r in rows),2),
                      'throughput_s',round(statistics.median(r['throughput_s'] for r in rows),1),
                      'batch',round(statistics.median(r['mean_batch'] for r in rows),2))
    print('saved',p)

if __name__=='__main__': main()
