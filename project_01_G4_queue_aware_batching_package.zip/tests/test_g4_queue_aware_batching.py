import unittest
from g4_queue_aware_batching import Policy, simulate, arrival_trace

class QueueTests(unittest.TestCase):
    def setUp(self):
        self.service={1:2.0,2:3.0,3:3.5,4:4.0}
    def test_empty(self):
        self.assertEqual(simulate([],self.service,Policy('x',1))['count'],0)
    def test_one(self):
        r=simulate([0.0],self.service,Policy('one',1))
        self.assertEqual(r['completion_times_ms'],[2.0])
    def test_separated_arrivals(self):
        r=simulate([0,10,20],self.service,Policy('one',1))
        self.assertEqual(r['completion_times_ms'],[2,12,22])
    def test_serial_queue(self):
        r=simulate([0,0,0],self.service,Policy('one',1))
        self.assertEqual(r['completion_times_ms'],[2,4,6])
    def test_full_batch(self):
        r=simulate([0]*4,self.service,Policy('batch',4))
        self.assertEqual(r['completion_times_ms'],[4]*4)
    def test_window_no_future_lookahead(self):
        r=simulate([0,2,100],self.service,Policy('wait',4,5))
        self.assertEqual(r['completion_times_ms'][:2],[8,8])
        self.assertEqual(r['completion_times_ms'][2],107)
    def test_window_full_ready_early(self):
        r=simulate([0,1,2,3],self.service,Policy('wait',4,50))
        self.assertEqual(r['completion_times_ms'],[7]*4)
    def test_no_past_arrivals(self):
        r=simulate([0,0,30,50],self.service,Policy('batch',4))
        self.assertEqual(r['completion_times_ms'],[3,3,32,52])
    def test_no_overlap(self):
        r=simulate([0,0,0,0,0],self.service,Policy('batch',4))
        self.assertEqual(r['completion_times_ms'],[4,4,4,4,6])
    def test_invalid_unsorted(self):
        with self.assertRaises(ValueError): simulate([3,2],self.service,Policy('x',1))
    def test_invalid_negative(self):
        with self.assertRaises(ValueError): simulate([-1],self.service,Policy('x',1))
    def test_invalid_service(self):
        with self.assertRaises(ValueError): simulate([0],{},Policy('x',1))
    def test_invalid_cap(self):
        with self.assertRaises(ValueError): simulate([0],self.service,Policy('x',0))
    def test_fixed_seed_arrivals(self):
        self.assertEqual(arrival_trace('poisson',3,10,200),arrival_trace('poisson',3,10,200))
    def test_burst_size(self):
        a=arrival_trace('bursty',3,32,100)
        self.assertEqual(len(set(a)),2)
    def test_all_finished_order(self):
        a=arrival_trace('poisson',4,100,200)
        r=simulate(a,self.service,Policy('batch',4))
        self.assertEqual(len(r['completion_times_ms']),100)
        self.assertEqual(sorted(r['completion_times_ms']),r['completion_times_ms'])

if __name__=='__main__': unittest.main()

class DifferentialValidation(unittest.TestCase):
    def test_against_simple_reference_150_cases(self):
        # Deliberately separate queue selection logic without bisect.
        import random
        from g4_queue_aware_batching import simulate
        sv={1:1.5,2:2.7,3:3.3,4:4.4,5:5.0}
        for seed in range(50):
            rng=random.Random(seed)
            arr=sorted(round(rng.uniform(0,20),2) for _ in range(14))
            for p in (Policy('s',1),Policy('g',5),Policy('w',5,2)):
                idx=0; clock=0; expected=[]
                while idx<len(arr):
                    clock=max(clock,arr[idx])
                    if p.window_ms:
                        closing=arr[idx]+p.window_ms
                        if idx+p.cap-1<len(arr):
                            closing=min(closing,arr[idx+p.cap-1])
                        clock=max(clock,closing)
                    b=sum(t<=clock for t in arr[idx:])
                    b=min(b,p.cap)
                    clock+=sv[b]
                    expected.extend([clock]*b)
                    idx+=b
                actual=simulate(arr,sv,p)['completion_times_ms']
                self.assertEqual(len(expected),len(actual))
                for x,y in zip(expected,actual): self.assertAlmostEqual(x,y,places=10)
