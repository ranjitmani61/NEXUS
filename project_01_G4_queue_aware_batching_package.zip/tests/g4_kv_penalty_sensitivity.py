"""Hypothetical KV-cost sensitivity using measured CPU projection-only service curves.

Add h milliseconds per request to ALL policies; h is not measured KV scan time.
No cross-device speedup or hardware-time claim is authorized.
"""
import json
from pathlib import Path
from statistics import median
from g4_queue_aware_batching import Policy, arrival_trace, simulate

BASE=Path('results/g4_queue_aware_batching_verified.json')
OUTPUT=Path('results/g4_kv_penalty_sensitivity_verified.json')

def service_with_penalty(curve, per_request_ms):
    if per_request_ms < 0: raise ValueError('negative KV penalty')
    return {int(b):float(t)+int(b)*per_request_ms for b,t in curve.items()}


def run():
    j=json.loads(BASE.read_text())
    rates=(150,300,450,650)
    penalties=(0,0.25,1.0,2.0,4.0)
    records=[]
    for penalty in penalties:
        for rate in rates:
            for kind in ('poisson','bursty'):
                for policy in (Policy('serial',1),Policy('greedy_32',32)):
                    for seed in (101,102,103):
                        a=arrival_trace(kind,seed,1200,rate)
                        for trial,curve in enumerate(j['curves'],start=1):
                            s=service_with_penalty(curve['service_ms'],penalty)
                            r=simulate(a,s,policy)
                            records.append({'penalty_ms_per_request':penalty,'rate_s':rate,
                                            'kind':kind,'seed':seed,'trial':trial,
                                            'policy':policy.name,'p95_ms':r['p95_ms'],
                                            'throughput_s':r['throughput_s'],
                                            'mean_batch':r['mean_batch']})
    out={'title':'G4 KV proxy cost sensitivity on CPU projection timing',
         'source_file':str(BASE),'not_measured_kv':'Penalty values are hypothetical additional milliseconds per queued request; no real KV scan, GPU, or pretrained model measured',
         'penalties_ms_per_request':list(penalties),'records':records}
    OUTPUT.write_text(json.dumps(out,indent=2))
    for kind in ('poisson','bursty'):
        for rate in (150,450,650):
            for penalty in penalties:
                def m(name):
                    return median(r['p95_ms'] for r in records if r['rate_s']==rate and r['kind']==kind and r['penalty_ms_per_request']==penalty and r['policy']==name)
                print(kind,rate,'penalty',penalty,'p95 serial',round(m('serial'),1),'batch',round(m('greedy_32'),1))
    print('saved',OUTPUT)

if __name__=='__main__':run()
