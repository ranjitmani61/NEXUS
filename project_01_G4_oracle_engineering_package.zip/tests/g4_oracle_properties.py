#!/usr/bin/env python3
"""Independent small-case checks for mass-certificate page-count oracle.
Run: OPENBLAS_NUM_THREADS=1 python tests/g4_oracle_properties.py
"""
import itertools
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).parent))
from g4_oracle_headroom_audit import mass_oracle, hindsight_value_oracle

rng=np.random.default_rng(20261103)
checks=0
for page_cnt in range(2,8):
    for trial in range(120):
        token_count=page_cnt*4
        logits=rng.normal(0,rng.uniform(.1,5),(token_count,))
        target=float(rng.choice([.02,.1,.5]))
        k,masses=mass_oracle(logits,token_count,page_size=4,tol=target)
        # Deliberately expensive brute force verifies no set of k-1 pages can
        # retain enough mass. This establishes only the mass-certificate bound.
        maxmass=[max(sum(masses[j] for j in ix) for ix in itertools.combinations(range(page_cnt),size)) for size in range(1,page_cnt+1)]
        true_min=next(i+1 for i,amt in enumerate(maxmass) if amt>=1-target/2-1e-12)
        assert true_min==k,(page_cnt,trial,k,true_min)
        checks+=1
# Constant values expose mass certification conservatism: exact output can
# be obtained from one block although uniform logits require nearly all pages.
logits=np.zeros(128*32)
values=np.tile(np.array([.2,-.7,1.1]),(len(logits),1))
y=values.mean(axis=0)
maxval=float(np.linalg.norm(y))
k,masses=mass_oracle(logits,len(logits),page_size=32,tol=.02)
h=hindsight_value_oracle(logits,values,y,maxval,page_size=32,tol=.02)
assert (k,h)==(127,1),(k,h)
output={'date':'2026-11-03','small_brute_force_tests':checks,'violations':0,
        'uniform_constant_value_mass_oracle_pages':k,
        'uniform_constant_value_hindsight_pages':h,
        'note':'Proof-of-conservatism control; offline full scores/values. Not a new algorithm or hardware result.'}
f=Path('results/g4_oracle_properties.json')
f.parent.mkdir(parents=True,exist_ok=True)
f.write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
