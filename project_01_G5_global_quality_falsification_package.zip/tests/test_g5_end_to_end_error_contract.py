"""G5 local->global safety negative controls. No pretrained checkpoints."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import numpy as np
import pytest
import torch
from torch import nn
from g5_end_to_end_error_contract import (
    thresholded_delta_update,relative_l2,output_error_bound,
    margin_guarantees_top1,counterexample,monte_carlo_linear_chain_check,
    repeated_error_example)
from g5_projection_delta_capture import evaluate_projection_deltas


def test_actual_G5_local_diagnostic_approves_counterexample():
    """Regression: previous local oracle returns PASS, but final top1 flips."""
    layer=nn.Linear(2,2,bias=False,dtype=torch.float64)
    with torch.no_grad():layer.weight.copy_(torch.eye(2,dtype=torch.float64))
    inputs={'layer':torch.tensor([[0,0],[1,.015]],dtype=torch.float64)}
    results=evaluate_projection_deltas(inputs,{'layer':layer},thresholds=(0.02,),tolerance=.02)
    row=results['rows'][0]
    assert row['all_pairs_meet_tolerance'] is True
    assert row['selected_fraction']==.5
    assert 0.014 < row['max_relative_projection_l2_error'] < .016
    evidence=counterexample()
    assert evidence['local_passes_2_percent']
    assert evidence['exact_class']!=evidence['approx_class']
    assert evidence['final_relative_l2_error'] > .9
    assert not evidence['margin_guarantee']


def test_thresholded_delta_and_exact_baseline():
    w=np.eye(2)
    x=np.array([1.,.015])
    true,approx=thresholded_delta_update([0.,0.],x,w,.02)
    np.testing.assert_allclose(true,x)
    np.testing.assert_allclose(approx,[1.,0.])
    true2,approx2=thresholded_delta_update([0.,0.],x,w,0.)
    np.testing.assert_allclose(true2,approx2,atol=1e-15)


def test_small_local_errors_can_accumulate():
    r=repeated_error_example()
    assert r['layers']==8
    assert r['total_relative_error']==pytest.approx(.08,abs=1e-12)
    assert r['global_absolute_error_bound']==pytest.approx(.08,abs=1e-12)


def test_margin_sufficient_not_necessary():
    ok,gap=margin_guarantees_top1([1.,0.],.1)
    assert ok and gap==1
    not_certified,_=margin_guarantees_top1([1.,0.],.6)
    assert not not_certified
    # A negative certificate is UNKNOWN, not evidence that argmax flipped.


def test_property_bound_500_random_chains():
    r=monte_carlo_linear_chain_check(seed=20261103,cases=500)
    assert r['bound_violations']==0
    assert r['max_observed_error_minus_bound']<=1e-10


@pytest.mark.parametrize('bad',[-1,float('nan'),float('inf')])
def test_reject_invalid_threshold(bad):
    with pytest.raises(ValueError):thresholded_delta_update([0,0],[1,1],np.eye(2),bad)


def test_reject_shape_mismatch():
    with pytest.raises(ValueError):thresholded_delta_update([0],[1,1],np.eye(2),0)
    with pytest.raises(ValueError):output_error_bound([np.eye(3),np.eye(2)],[.01,.01])
    with pytest.raises(ValueError):relative_l2(np.array([1,2]),np.array([1]))


def test_reject_invalid_bounds():
    with pytest.raises(ValueError):output_error_bound([np.eye(2)],[-.01])
    with pytest.raises(ValueError):output_error_bound([],[])
    with pytest.raises(ValueError):margin_guarantees_top1([0],0.)
    with pytest.raises(ValueError):margin_guarantees_top1([0,1],float('nan'))
