#!/usr/bin/env python3
"""G5 safety-gate falsification: local projection tolerance != model-output tolerance.

Research/reference implementation. No pretrained weights, no inference speed claims.
Version 1.0, 2026-11-03. Governing protocol: /mnt/data/AGENTS.md.
"""
from __future__ import annotations
import json
import math
from pathlib import Path
import numpy as np


def thresholded_delta_update(previous_input, current_input, weight, threshold):
    """For a bias-free affine projection, exact and approximate *adjacent-token* outputs.

    Uses a fully dense previous projection as an optimistic oracle. A practical
    implementation must pay for and preserve that state (excluded here).
    """
    p = np.asarray(previous_input, dtype=np.float64)
    x = np.asarray(current_input, dtype=np.float64)
    w = np.asarray(weight, dtype=np.float64)
    if p.ndim != 1 or x.ndim != 1 or p.shape != x.shape:
        raise ValueError('Input vectors must have identical 1D shape')
    if w.ndim != 2 or w.shape[1] != x.size:
        raise ValueError('Weight matrix shape does not match inputs')
    if not np.isfinite(p).all() or not np.isfinite(x).all() or not np.isfinite(w).all():
        raise ValueError('Inputs must be finite')
    if not math.isfinite(threshold) or threshold < 0:
        raise ValueError('threshold must be nonnegative and finite')
    dx = x - p
    y_prev = w @ p
    y_exact = w @ x
    y_approx = y_prev + w @ (dx * (np.abs(dx) > threshold))
    return y_exact, y_approx


def relative_l2(approx, exact):
    exact = np.asarray(exact, dtype=np.float64)
    approx = np.asarray(approx, dtype=np.float64)
    if exact.shape != approx.shape or not np.isfinite(exact).all() or not np.isfinite(approx).all():
        raise ValueError('Vectors must be matched and finite')
    return float(np.linalg.norm(approx-exact) / max(np.linalg.norm(exact), 1e-12))


def output_error_bound(weights, local_error_bounds):
    """Valid for a chain of linear maps h[i+1]=W[i]@h[i].

    Assumption: approximate step i produces W[i]@h_approx[i] + e[i], with
    ||e[i]||_2 <= local_error_bounds[i]. For nonlinear layers, additional
    Lipschitz and rounding terms are required; this function is NOT a proof
    for a transformer.
    """
    if len(weights) != len(local_error_bounds) or not weights:
        raise ValueError('Must provide one bound per nonempty chain of matrices')
    b = 0.0
    prev_out = None
    for w, e in zip(weights, local_error_bounds):
        w = np.asarray(w, dtype=np.float64)
        if w.ndim != 2 or not np.isfinite(w).all() or (prev_out is not None and w.shape[1] != prev_out):
            raise ValueError('Invalid matrix chain')
        if not np.isfinite(e) or e < 0:
            raise ValueError('Invalid local error budget')
        b = float(np.linalg.norm(w, ord=2)) * b + float(e)
        prev_out = w.shape[0]
    return b


def margin_guarantees_top1(exact_logits, absolute_l2_bound):
    """Sufficient criterion: true top1 margin > 2*||logit_error||_2.

    It is NOT necessary: if it fails, answer is UNKNOWN rather than wrong.
    """
    z = np.asarray(exact_logits, dtype=np.float64)
    if z.ndim != 1 or z.size < 2 or not np.isfinite(z).all():
        raise ValueError('Need at least 2 finite logits')
    if not np.isfinite(absolute_l2_bound) or absolute_l2_bound < 0:
        raise ValueError('Bound must be finite and nonnegative')
    top2 = np.partition(z, -2)[-2:]
    gap = float(np.max(top2) - np.min(top2))
    return bool(gap > 2.0 * absolute_l2_bound), gap


def counterexample():
    """Chosen algebraic example; not learned weights or representative model."""
    x_old = np.array([0.0, 0.0])
    x_new = np.array([1.0, 0.015])
    w = np.eye(2)
    head = np.diag([0.001, 1.0])
    y, ya = thresholded_delta_update(x_old, x_new, w, 0.02)
    true_logits = head @ y
    approx_logits = head @ ya
    local_err = float(np.linalg.norm(y-ya))
    final_bound = output_error_bound([head], [local_err])
    certified, margin = margin_guarantees_top1(true_logits, final_bound)
    return {
        'purpose':'counterexample to local error <= 2% implying unchanged model prediction',
        'threshold':0.02,
        'local_relative_l2_error':relative_l2(ya,y),
        'local_passes_2_percent':relative_l2(ya,y) < 0.02,
        'exact_logits':true_logits.tolist(),
        'approx_logits':approx_logits.tolist(),
        'exact_class':int(np.argmax(true_logits)),
        'approx_class':int(np.argmax(approx_logits)),
        'final_relative_l2_error':relative_l2(approx_logits,true_logits),
        'final_abs_l2_error':float(np.linalg.norm(approx_logits-true_logits)),
        'propagated_bound':final_bound,
        'exact_margin':margin,
        'margin_guarantee':certified,
        'note':'adversarial constructed two-layer example: not a pretrained or realistic LLM'
    }


def monte_carlo_linear_chain_check(seed=20261103, cases=500):
    """Independent property checks for linear error recursion, not a hardware proof."""
    rng = np.random.default_rng(seed)
    max_violation = -float('inf')
    guaranteed_cases = 0
    flipped_cases = 0
    for _ in range(cases):
        d = int(rng.integers(2,8))
        depth = int(rng.integers(1,7))
        weights = [rng.normal(size=(d,d))*float(rng.uniform(0.1,1.2))/np.sqrt(d)
                   for _ in range(depth)]
        injected = [rng.normal(size=d)*float(rng.uniform(0,0.04)) for _ in range(depth)]
        bounds = [np.linalg.norm(e) for e in injected]
        x = rng.normal(size=d)
        h = x.copy(); ha = x.copy()
        for w,e in zip(weights,injected):
            h=w@h; ha=w@ha+e
        total_bound=output_error_bound(weights,bounds)
        total_error=float(np.linalg.norm(ha-h))
        max_violation=max(max_violation, total_error-total_bound)
        if total_error > total_bound+1e-10:
            raise AssertionError('Error bound violated')
        if d>=2:
            is_guaranteed, margin = margin_guarantees_top1(h,total_bound)
            if is_guaranteed:
                guaranteed_cases+=1
                if int(np.argmax(h)) != int(np.argmax(ha)):
                    raise AssertionError('Wrong certification: top1 changed')
            flipped_cases+=int(np.argmax(h)!=np.argmax(ha))
    return {'seed':seed,'cases':cases,'bound_violations':0,
            'max_observed_error_minus_bound':max_violation,
            'certified_stable_cases':guaranteed_cases,
            'top1_flips_without_certificate':flipped_cases}


def repeated_error_example():
    """Each layer introduces 1% local absolute error; 8 layers exceed 2%."""
    depth=8
    x=np.array([1.,0.]); exact=x.copy(); approx=x.copy()
    for _ in range(depth):
        exact=np.eye(2)@exact
        approx=np.eye(2)@approx+np.array([0.,0.01])
    bound=output_error_bound([np.eye(2)]*depth,[0.01]*depth)
    return {'layers':depth,'local_step_error_bound':0.01,'total_relative_error':relative_l2(approx,exact),
            'global_absolute_error_bound':bound, 'exact':exact.tolist(),'approx':approx.tolist()}


def main():
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,default=Path('results/g5_local_to_global_error_audit.json'))
    p.add_argument('--cases',type=int,default=500)
    args=p.parse_args()
    if not (1<=args.cases<=100000):
        p.error('--cases must be between 1 and 100000')
    report={
        'date':'2026-11-03','scope':'G5 safety-falsification / theoretical linear-chain counterexample',
        'model':'synthetic constructed matrices ONLY',
        'counterexample':counterexample(),
        'accumulation':repeated_error_example(),
        'property_checks':monte_carlo_linear_chain_check(cases=args.cases),
        'gate':'G5 remains BLOCKED (no real pretrained inference); local-only quality criterion disproven',
    }
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
