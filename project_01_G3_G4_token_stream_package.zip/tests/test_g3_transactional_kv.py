"""Deterministic reference checks, aliasing, optimistic transaction conflicts, concurrent publication."""
import threading
import numpy as np
import pytest
from g3_transactional_kv import TransactionalKV, WriteConflict, dense_stream, guarded_query
from g3_guarded_mixed_precision_audit import FORMATS


def fixture(fmt='fp16',pages=8,size=4,d=16,vd=3):
    rng=np.random.default_rng(19)
    K=rng.normal(size=(pages*size,d)).astype(FORMATS[fmt]); V=rng.normal(size=(pages*size,vd)).astype('float64')
    return TransactionalKV(K,V,size),K,V

@pytest.mark.parametrize('fmt',list(FORMATS))
def test_old_snapshot_immutability_and_no_alias(fmt):
    s,K,V=fixture(fmt); old=s.capture()
    baseline=dense_stream(old,np.ones(old.d,dtype=old.key_dtype))
    K[:]=100;V[:]=100
    for arr in (old.pages[0].K,old.pages[0].V,old.pages[0].lo,old.pages[0].hi):
        assert not arr.flags.writeable
        with pytest.raises(ValueError): arr.flags.writeable=True
    k=np.full((old.page_size,old.d),20,dtype=old.key_dtype)
    v=np.full((old.page_size,old.vd),20.,dtype='float64')
    new=s.commit(old,replacements={1:(k,v)})
    assert new.epoch==old.epoch+1 and new.pages[0] is old.pages[0] and new.pages[1] is not old.pages[1]
    assert np.allclose(dense_stream(old,np.ones(old.d,dtype=old.key_dtype)),baseline)
    k[:]=44; v[:]=44
    assert np.all(new.pages[1].K == 20) and np.all(new.pages[1].V==20)

@pytest.mark.parametrize('fmt',list(FORMATS))
def test_conflict_and_failed_validation_rollback(fmt):
    s,_,_=fixture(fmt); old=s.capture()
    K=np.ones((old.page_size,old.d),dtype=old.key_dtype);V=np.ones((old.page_size,old.vd),dtype='float64')
    with pytest.raises(ValueError): s.commit(old,replacements={0:(K,V),1:(K[:1],V)})
    assert s.capture() is old
    newer=s.commit(old,replacements={0:(K,V)})
    with pytest.raises(WriteConflict): s.commit(old,replacements={1:(K,V)})
    assert s.capture() is newer
    with pytest.raises(ValueError): s.commit(newer,replacements={len(newer.pages):(K,V)})
    assert s.capture() is newer
    appended=s.commit(newer,appended=[(K,V)])
    assert len(appended.pages)==len(newer.pages)+1
    assert all(a is b for a,b in zip(appended.pages,newer.pages))

@pytest.mark.parametrize('fmt',list(FORMATS))
def test_dense_and_certificate_matches_full_reference(fmt):
    s,_,_=fixture(fmt,pages=4,size=8)
    rng=np.random.default_rng(123)
    for turn in range(16):
        root=s.capture(); q=rng.normal(size=root.d).astype(root.key_dtype)
        K=np.vstack([p.K for p in root.pages]).astype('float64');V=np.vstack([p.V for p in root.pages]);
        score=K@q.astype('float64')/np.sqrt(root.d)
        w=np.exp(score-np.max(score)); w/=w.sum()
        ref=w@V
        assert np.allclose(dense_stream(root,q),ref,rtol=2e-12,atol=1e-12)
        pred,yes,bound,_=guarded_query(root,q)
        err=np.linalg.norm(pred-ref)/max(np.linalg.norm(V,axis=1).max(),1e-30)
        assert err<=0.02+1e-10
        if yes: assert err<=bound+1e-10
        kp=rng.normal(size=(root.page_size,root.d)).astype(root.key_dtype)
        vp=rng.normal(size=(root.page_size,root.vd)).astype('float64')
        s.commit(root,replacements={turn%len(root.pages):(kp,vp)})


def test_atomic_multi_page_commit_under_concurrent_read():
    size=4;d=8;dtype='float16'
    K=np.zeros((size*2,d),dtype=dtype); V=np.zeros((size*2,1),dtype='float64')
    s=TransactionalKV(K,V,size)
    start=threading.Barrier(2)
    errors=[];seen=[]
    def writer():
        try:
            start.wait()
            for i in range(200):
                root=s.capture()
                v=np.full((size,1),float(i%2),'float64'); k=np.zeros((size,d),dtype=dtype)
                s.commit(root,replacements={0:(k,v),1:(k,v)})
        except Exception as exc: errors.append(repr(exc))
    def reader():
        try:
            start.wait()
            q=np.zeros(d,dtype=dtype)
            for i in range(400):
                snap=s.capture(); y=dense_stream(snap,q)
                if not (abs(float(y[0]))<1e-12 or abs(float(y[0])-1)<1e-12):
                    errors.append(f'torn state: epoch={snap.epoch} output={y}')
                seen.append(snap.epoch)
        except Exception as exc: errors.append(repr(exc))
    a=threading.Thread(target=writer);b=threading.Thread(target=reader)
    a.start();b.start();a.join(timeout=10);b.join(timeout=10)
    assert not a.is_alive() and not b.is_alive()
    assert not errors,errors
    assert s.capture().epoch==200 and len(seen)==400


def test_simultaneous_writers_only_one_wins():
    s,_,_=fixture(); root=s.capture();bar=threading.Barrier(2); outcomes=[]
    k=np.zeros((root.page_size,root.d),dtype=root.key_dtype);v=np.zeros((root.page_size,root.vd),'float64')
    def writer(index):
        bar.wait()
        try: s.commit(root,replacements={index:(k,v)});outcomes.append('ok')
        except WriteConflict: outcomes.append('conflict')
    a=threading.Thread(target=writer,args=(0,));b=threading.Thread(target=writer,args=(1,))
    a.start();b.start();a.join();b.join()
    assert sorted(outcomes)==['conflict','ok']


def test_nonfinite_rejected_without_commit():
    s,_,_=fixture();root=s.capture()
    k=np.zeros((root.page_size,root.d),dtype=root.key_dtype);v=np.zeros((root.page_size,root.vd),'float64')
    k[0,0]=np.nan
    with pytest.raises(ValueError): s.commit(root,replacements={0:(k,v)})
    assert s.capture() is root
    q=np.zeros(root.d,dtype=root.key_dtype);q[0]=np.nan
    with pytest.raises(ValueError): guarded_query(root,q)
