#!/usr/bin/env python3
"""G3/G4 CPU reference: token-granular append with immutable page snapshots.

Not a novel processor, production paged-KV allocator, GPU kernel, or formal
floating-point proof. Dense baseline is exact FP64 attention on stored operands.
"""
from __future__ import annotations
from dataclasses import dataclass
from threading import Lock
from types import SimpleNamespace
import math
import numpy as np
from g3_transactional_kv import _sealed, WriteConflict
from g3_guarded_mixed_precision_audit import FORMATS, guarded_admission


@dataclass(frozen=True, slots=True)
class TokenPage:
    K: np.ndarray
    V: np.ndarray
    lo: np.ndarray
    hi: np.ndarray

    @classmethod
    def make(cls, K, V, *, page_size, d, vd, key_dtype):
        K, V = np.asarray(K), np.asarray(V)
        if K.ndim != 2 or V.ndim != 2 or K.shape[0] != V.shape[0]:
            raise ValueError('page row counts differ')
        if not (1 <= len(K) <= page_size) or K.shape[1:] != (d,) or V.shape[1:] != (vd,):
            raise ValueError('invalid partial/full page shape')
        if K.dtype != key_dtype or V.dtype != np.dtype('float64'):
            raise ValueError('incorrect stored dtype')
        if not np.isfinite(K.astype('float64')).all() or not np.isfinite(V).all():
            raise ValueError('nonfinite key/value')
        key, val = _sealed(K), _sealed(V)
        return cls(key, val, _sealed(np.min(key, axis=0).astype('float32')),
                   _sealed(np.max(key, axis=0).astype('float32')))


@dataclass(frozen=True, slots=True)
class TokenRoot:
    pages: tuple[TokenPage, ...]
    epoch: int
    length: int
    page_size: int
    d: int
    vd: int
    key_dtype: np.dtype


class TokenStreamKV:
    def __init__(self, K, V, page_size=16):
        K, V = np.asarray(K), np.asarray(V)
        if not isinstance(page_size, int) or page_size <= 0:
            raise ValueError('page size must be positive integer')
        if K.ndim != 2 or V.ndim != 2 or K.shape[0] != V.shape[0] or len(K) == 0:
            raise ValueError('invalid initial shape')
        if K.shape[1] == 0 or V.shape[1] == 0 or K.dtype not in tuple(FORMATS.values()):
            raise ValueError('bad dimension or key dtype')
        if V.dtype != np.dtype('float64'):
            raise ValueError('values must be FP64 (reference-only)')
        d, vd = K.shape[1], V.shape[1]
        ps = tuple(TokenPage.make(K[j:j+page_size], V[j:j+page_size],
                                  page_size=page_size, d=d, vd=vd, key_dtype=K.dtype)
                   for j in range(0, len(K), page_size))
        self._lock=Lock()
        self._root=TokenRoot(ps,0,len(K),page_size,d,vd,K.dtype)

    def capture(self):
        with self._lock:
            return self._root

    def append(self, expected:TokenRoot, k, v):
        """Append one token; copy at most one page payload plus O(number pages) pointers.

        A stale expected root causes conflict; previously captured roots remain
        unchanged. This is a Python lock contract, NOT a lock-free GPU contract.
        """
        if not isinstance(expected,TokenRoot):
            raise TypeError('expected root required')
        k,v = np.asarray(k),np.asarray(v)
        if k.shape != (expected.d,) or v.shape != (expected.vd,) or k.dtype != expected.key_dtype or v.dtype != np.dtype('float64'):
            raise ValueError('invalid token size/dtype')
        if not np.isfinite(k.astype('float64')).all() or not np.isfinite(v).all():
            raise ValueError('nonfinite token')
        if expected.epoch >= 2**64-1:
            raise OverflowError('epoch exhausted')
        tail=expected.pages[-1]
        if len(tail.K) < expected.page_size:
            updated=TokenPage.make(np.concatenate([tail.K,k[None,:]]),
                                   np.concatenate([tail.V,v[None,:]]),
                                   page_size=expected.page_size,d=expected.d,vd=expected.vd,key_dtype=expected.key_dtype)
            pages=expected.pages[:-1]+(updated,)
        else:
            updated=TokenPage.make(k[None,:],v[None,:],page_size=expected.page_size,
                                   d=expected.d,vd=expected.vd,key_dtype=expected.key_dtype)
            pages=expected.pages+(updated,)
        next_root=TokenRoot(pages,expected.epoch+1,expected.length+1,
                            expected.page_size,expected.d,expected.vd,expected.key_dtype)
        with self._lock:
            if self._root is not expected:
                raise WriteConflict('stale expected root')
            self._root=next_root
        return next_root


def flat(root):
    return np.concatenate([p.K for p in root.pages],axis=0), np.concatenate([p.V for p in root.pages],axis=0)


def dense_exact_arrays(K, V, q):
    scores=K.astype('float64')@q.astype('float64')/math.sqrt(K.shape[1])
    weights=np.exp(scores-np.max(scores)); weights/=np.sum(weights)
    return weights@V


def paged_online(root, q, only_page=None):
    q=np.asarray(q)
    if q.shape != (root.d,) or q.dtype != root.key_dtype or not np.isfinite(q.astype('float64')).all():
        raise ValueError('bad query')
    if only_page is not None and (only_page<0 or only_page>=len(root.pages)):
        raise ValueError('bad page')
    ps=root.pages if only_page is None else (root.pages[only_page],)
    m=-math.inf;z=0.;numer=np.zeros(root.vd,dtype='float64')
    q64=q.astype('float64')
    for p in ps:
        s=p.K.astype('float64')@q64/math.sqrt(root.d)
        mn=max(m,float(np.max(s)))
        rs=0. if m==-math.inf else math.exp(m-mn)
        w=np.exp(s-mn)
        numer=numer*rs+w@p.V
        z=z*rs+float(w.sum());m=mn
    return numer/z


def guarded_stream(root, q, eps=0.02):
    q=np.asarray(q)
    if q.shape != (root.d,) or q.dtype != root.key_dtype or not np.isfinite(q.astype('float64')).all():
        raise ValueError('bad query')
    # Recomputed per-query stack is counted in benchmark. For highly paged
    # caches this cost can dominate. Metadata belongs to the SAME immutable root.
    meta=SimpleNamespace(lo=np.stack([p.lo for p in root.pages]),
                         hi=np.stack([p.hi for p in root.pages]),version=root.epoch)
    cache=SimpleNamespace(d=root.d,pages=len(root.pages),version=root.epoch)
    yes, page, bound, reason=guarded_admission(cache,meta,q,eps=eps)
    return paged_online(root,q,only_page=page if yes else None),yes,bound,reason
