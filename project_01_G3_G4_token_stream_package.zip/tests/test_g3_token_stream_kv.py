"""G3/G4: partial pages, immutability, atomic publication, matched stored-input outputs."""
from __future__ import annotations
import threading
import numpy as np
import pytest
from g3_guarded_mixed_precision_audit import FORMATS
from g3_transactional_kv import WriteConflict
from g3_token_stream_kv import TokenStreamKV,flat,dense_exact_arrays,paged_online,guarded_stream


def make(fmt='fp16',n=13,ps=8,d=16,vd=5):
    rng=np.random.default_rng(244)
    k=rng.normal(size=(n,d)).astype(FORMATS[fmt]);v=rng.normal(size=(n,vd)).astype('float64')
    return TokenStreamKV(k,v,ps)

@pytest.mark.parametrize('fmt',list(FORMATS))
@pytest.mark.parametrize('start', [1,7,8,9,15,16,17])
def test_partial_page_boundaries_and_reference(fmt,start):
    c=make(fmt,n=start)
    rng=np.random.default_rng(57)
    initial=c.capture();q=rng.normal(size=initial.d).astype(initial.key_dtype)
    old=paged_online(initial,q)
    for j in range(18):
        root=c.capture(); k=rng.normal(size=root.d).astype(root.key_dtype)
        v=rng.normal(size=root.vd).astype('float64')
        next_root=c.append(root,k,v)
        assert next_root.length==start+j+1 and next_root.epoch==j+1
        assert len(next_root.pages)==(next_root.length+next_root.page_size-1)//next_root.page_size
        assert sum(len(p.K) for p in next_root.pages)==next_root.length
        assert all(len(p.K)==next_root.page_size for p in next_root.pages[:-1])
        assert all(not p.K.flags.writeable and not p.V.flags.writeable for p in next_root.pages)
        assert all(np.array_equal(p.lo,p.K.min(axis=0).astype('float32')) for p in next_root.pages)
        assert all(np.array_equal(p.hi,p.K.max(axis=0).astype('float32')) for p in next_root.pages)
        kk,vv=flat(next_root)
        assert np.allclose(paged_online(next_root,q),dense_exact_arrays(kk,vv,q),rtol=1e-11,atol=1e-11)
        out,admitted,bound,_=guarded_stream(next_root,q)
        vmax=max(1e-30,float(np.linalg.norm(vv,axis=1).max()))
        err=np.linalg.norm(out-dense_exact_arrays(kk,vv,q))/vmax
        assert err<=0.02+1e-9
        if admitted: assert err<=bound+1e-9
    assert np.allclose(paged_online(initial,q),old,rtol=0,atol=0)

@pytest.mark.parametrize('fmt',list(FORMATS))
def test_inputs_no_alias_and_failure_atomicity(fmt):
    c=make(fmt);old=c.capture()
    k=np.ones(old.d,dtype=old.key_dtype);v=np.ones(old.vd,dtype='float64')
    changed=c.append(old,k,v)
    k[:]=-9;v[:]=-9
    assert np.all(changed.pages[-1].K[-1]==1) and np.all(changed.pages[-1].V[-1]==1)
    with pytest.raises(WriteConflict):c.append(old,k,v)
    assert c.capture() is changed
    k2=np.ones(old.d,dtype=old.key_dtype);k2[0]=np.nan
    with pytest.raises(ValueError):c.append(changed,k2,v)
    with pytest.raises(ValueError):c.append(changed,k2[:-1],v)
    with pytest.raises(ValueError):c.append(changed,k2.astype('float64'),v)
    assert c.capture() is changed

@pytest.mark.parametrize('fmt',list(FORMATS))
def test_concurrent_writer_reader_consistent(fmt):
    c=make(fmt,n=7,ps=8,d=8,vd=1)
    q=np.zeros(8,dtype=FORMATS[fmt]);initial=c.capture()
    bar=threading.Barrier(2);fails=[];seen=[]
    def writer():
        try:
            bar.wait()
            for t in range(64):
                r=c.capture();k=np.zeros(8,dtype=r.key_dtype);v=np.ones(1,dtype='float64')
                c.append(r,k,v)
        except Exception as exc:fails.append(repr(exc))
    def reader():
        try:
            bar.wait()
            for _ in range(128):
                r=c.capture();k,v=flat(r)
                assert len(k)==r.length and len(v)==r.length
                assert np.allclose(paged_online(r,q),dense_exact_arrays(k,v,q),rtol=1e-11,atol=1e-11)
                seen.append((r.epoch,r.length))
        except Exception as exc:fails.append(repr(exc))
    a=threading.Thread(target=writer);b=threading.Thread(target=reader)
    a.start();b.start();a.join(timeout=12);b.join(timeout=12)
    assert not a.is_alive() and not b.is_alive()
    assert not fails,fails
    assert len(seen)==128 and all(n==epoch+initial.length for epoch,n in seen)
    assert c.capture().length==initial.length+64


def test_two_writers_one_wins():
    c=make(n=8);root=c.capture();bar=threading.Barrier(2);seen=[]
    k=np.ones(root.d,dtype=root.key_dtype);v=np.ones(root.vd,dtype='float64')
    def f():
        bar.wait()
        try:c.append(root,k,v);seen.append('ok')
        except WriteConflict:seen.append('conflict')
    a=threading.Thread(target=f);b=threading.Thread(target=f);a.start();b.start();a.join();b.join()
    assert sorted(seen)==['conflict','ok']
