#!/usr/bin/env python3
"""G4 CPU single-head synthetic decode: append + attention vs dense preallocated.

All data are synthetic. No vLLM/FlashAttention GPU kernels are executed. Two
contiguous dense references are reported: matched FP16 storage and a faster
FP64 converted-key cache (at larger memory cost). Both compute the same FP64
softmax on identical low-precision *stored* keys and FP64 reference values.
"""
from __future__ import annotations
import argparse
import json
import os
import platform
from pathlib import Path
import time
import numpy as np
from g3_token_stream_kv import TokenStreamKV, guarded_stream, paged_online


def pstats(x):
    x=np.asarray(x,dtype='float64')
    return {'p50_ms':float(np.median(x)),'p95_ms':float(np.percentile(x,95)),
            'sum_ms':float(np.sum(x)), 'min_ms':float(np.min(x)), 'max_ms':float(np.max(x))}


def data(kind,seed,n,steps,dim,vd,page_size):
    rng=np.random.default_rng(seed)
    if kind=='clustered':
        k=rng.normal(-6,.02,(n+steps,dim));k[:page_size]=rng.normal(6,.02,(page_size,dim))
        q=1+rng.normal(0,.03,(steps,dim))
    elif kind=='random':
        k=rng.normal(size=(n+steps,dim));q=rng.normal(size=(steps,dim))
    elif kind=='uniform':
        k=rng.normal(0,.0001,(n+steps,dim));q=rng.normal(size=(steps,dim))
    else:raise ValueError(kind)
    v=rng.normal(size=(n+steps,vd))
    return k.astype('float16'),v.astype('float64'),q.astype('float16')


def exact_cached(k64,v,q):
    s=(k64@q.astype('float64'))/np.sqrt(k64.shape[1]);w=np.exp(s-np.max(s));w/=w.sum()
    return w@v


def bench(kind, seed=661, n=512,steps=64, page_size=16,dim=32,vd=16):
    K,V,Q=data(kind,seed,n,steps,dim,vd,page_size)
    kv=TokenStreamKV(K[:n],V[:n],page_size)
    # Dense contiguous implementation with extra converted-key cache and
    # reserved capacity, a competitive NumPy single-head reference.
    dense_k64=np.empty((n+steps,dim),dtype='float64');dense_v=np.empty((n+steps,vd),dtype='float64')
    dense_k64[:n]=K[:n].astype('float64');dense_v[:n]=V[:n]
    dense_low=np.empty((n+steps,dim),dtype='float16');dense_low[:n]=K[:n]
    # Call warmup away from timed region; warmups do not mutate the cache.
    q=Q[0]
    for _ in range(4):
        exact_cached(dense_k64[:n],dense_v[:n],q)
        exact_cached(dense_low[:n].astype('float64'),dense_v[:n],q)
        guarded_stream(kv.capture(),q)
    t_dense_opt=[];t_dense_low=[];t_stream=[];t_append=[];t_query=[];t_paged_dense=[]; admissions=0;fallbacks=0
    max_err=0.;max_over=0.;reasons={};first_page_new=[]
    for i in range(steps):
        total=n+i+1
        tic=time.perf_counter_ns()
        dense_k64[n+i]=K[n+i].astype('float64'); dense_v[n+i]=V[n+i]
        expected=exact_cached(dense_k64[:total],dense_v[:total],Q[i])
        t_dense_opt.append((time.perf_counter_ns()-tic)/1e6)

        tic=time.perf_counter_ns()
        dense_low[n+i]=K[n+i]
        expected_low=exact_cached(dense_low[:total].astype('float64'),dense_v[:total],Q[i])
        t_dense_low.append((time.perf_counter_ns()-tic)/1e6)
        assert np.allclose(expected,expected_low,atol=1e-11,rtol=1e-11)

        tic=time.perf_counter_ns()
        old=kv.capture()
        new=kv.append(old,K[n+i],V[n+i])
        app_ms=(time.perf_counter_ns()-tic)/1e6
        tic=time.perf_counter_ns()
        out,yes,bound,reason=guarded_stream(new,Q[i])
        query_ms=(time.perf_counter_ns()-tic)/1e6
        t_append.append(app_ms);t_query.append(query_ms);t_stream.append(app_ms+query_ms)
        tic=time.perf_counter_ns()
        paged_out=paged_online(new,Q[i])
        t_paged_dense.append((time.perf_counter_ns()-tic)/1e6)
        if not np.allclose(paged_out,expected,atol=1e-11,rtol=1e-11):
            raise AssertionError('paged dense baseline mismatch')
        if old.length%page_size==0: first_page_new.append(i)
        admissions+=int(yes);fallbacks+=int(not yes)
        reasons[reason]=reasons.get(reason,0)+1
        norm=max(1e-30,float(np.linalg.norm(V[:total],axis=1).max()))
        err=float(np.linalg.norm(out-expected)/norm)
        max_err=max(err,max_err)
        if err>0.02+1e-9: raise AssertionError(f'error threshold violated {kind} {i} {err}')
        if yes:
            overshoot=err-float(bound);max_over=max(overshoot,max_over)
            if overshoot>1e-9: raise AssertionError(f'bound violated {kind} {i} {overshoot}')
        if i in (0,15,31,63):
            assert np.allclose(paged_online(new,Q[i]),expected,atol=1e-11,rtol=1e-11)
    x=pstats(t_dense_opt);y=pstats(t_dense_low);z=pstats(t_stream)
    app=pstats(t_append);gq=pstats(t_query);paged=pstats(t_paged_dense)
    root=kv.capture()
    meta_bytes=sum(p.lo.nbytes+p.hi.nbytes for p in root.pages)
    page_payload=sum(p.K.nbytes+p.V.nbytes for p in root.pages)
    return {'kind':kind,'seed':seed,'initial_tokens':n,'steps':steps,'page_size':page_size,
            'dimension':dim,'value_dimension':vd,'admitted':admissions,'fallbacks':fallbacks,
            'reasons':reasons,'max_normalized_error':max_err,'max_admitted_bound_overshoot':max_over,
            'initial_metadata_build_included':False,'stream_metadata_reads_included':True,
            'dense_preallocated_converted_keys':x, 'dense_preallocated_same_dtype_keys':y,
            'transactional_paged_screening':z,'stream_append_only':app,
            'stream_screening_query_only':gq,'paged_dense_query_only':paged,
            'stream_vs_converted_dense_total_ratio':z['sum_ms']/x['sum_ms'],
            'stream_vs_same_dtype_dense_total_ratio':z['sum_ms']/y['sum_ms'],
            'stream_screening_query_vs_paged_dense_query_ratio':gq['sum_ms']/paged['sum_ms'],
            'final_page_payload_bytes':page_payload,'final_metadata_bytes':meta_bytes,
            'final_pointer_table_bytes_estimate':len(root.pages)*8,
            'competing_converted_key_cache_extra_bytes':dense_k64[:root.length].nbytes - K[:root.length].nbytes,
            'page_boundary_update_indices':first_page_new}


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',default='results/g4_token_stream_benchmark.json')
    p.add_argument('--steps',type=int,default=64);p.add_argument('--n',type=int,default=512)
    p.add_argument('--seeds',type=int,nargs='+',default=[661,719]); args=p.parse_args()
    out=[]
    for seed in args.seeds:
        for kind in ('clustered','random','uniform'):
            row=bench(kind,seed=seed,n=args.n,steps=args.steps)
            out.append(row)
            print(kind,seed,'admitted',row['admitted'],'/',args.steps,
                  'stream / cached dense',round(row['stream_vs_converted_dense_total_ratio'],2),
                  'maxerr',round(row['max_normalized_error'],8))
    res={'version':'1.1','date':'2026-11-03','status':'G3 G4 IN PROGRESS / G5 BLOCKED',
         'environment':{'python':platform.python_version(),'platform':platform.platform(),
                        'numpy':np.__version__,'openblas_num_threads':os.getenv('OPENBLAS_NUM_THREADS')},
         'workload':'synthetic CPU FP16 key storage, FP64 value and FP64 attention, one head, one decode query per token',
         'setup':'one-time initial page construction excluded for both stream and dense; append, update, selection and query measured per step',
         'limitations':'GPU kernels/vLLM/FlashAttention not executed; no pretrained LLM; no robust concurrency/system memory; timing noise',
         'cases':out}
    path=Path(args.output);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
    print('saved',path)
if __name__=='__main__':main()
