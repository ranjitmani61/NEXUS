"""G3 immutable snapshot reliability checks, with an expected legacy failure witness."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import numpy as np
import pytest
from g3_snapshot_consistency_audit import (FORMATS, FrozenSnapshot, build_meta, check_snapshot,
    stress,witness_old_mutable_api,safe_snapshot_query)
from g3_guarded_mixed_precision_audit import guarded_admission

@pytest.mark.parametrize('fmt',FORMATS)
def test_old_api_has_reproducible_invalid_certificate(fmt):
    w = witness_old_mutable_api(fmt)
    assert w['admitted'] and w['reported_bound'] < 0.02
    assert w['actual_normalized_error'] > .99

@pytest.mark.parametrize('fmt',FORMATS)
def test_new_snapshot_immutability_and_update(fmt):
    assert check_snapshot(fmt)['stale_metadata_rejected']

@pytest.mark.parametrize('fmt',FORMATS)
@pytest.mark.parametrize('seed',[11,29,43])
def test_stress_update_correctness(fmt,seed):
    x=stress(seed,fmt,updates=16)
    assert x['stale_rejects']==16

@pytest.mark.parametrize('fmt',FORMATS)
def test_cross_snapshot_metadata_rejected(fmt):
    q=np.ones(4,dtype=FORMATS[fmt]);K=np.ones((4,4),dtype=FORMATS[fmt]);V=np.ones((4,2))
    a=FrozenSnapshot.from_data(K,V,2);b=FrozenSnapshot.from_data(K,V,2)
    assert a.version!=b.version
    assert guarded_admission(b,build_meta(a),q)[3]=='stale_version'

@pytest.mark.parametrize('fmt',FORMATS)
def test_frozen_snapshot_rejects_bad_shape_or_nonfinite(fmt):
    K=np.ones((4,4),dtype=FORMATS[fmt]);V=np.ones((4,2))
    with pytest.raises(ValueError):FrozenSnapshot.from_data(K,V,3)
    with pytest.raises(ValueError):FrozenSnapshot.from_data(K,V,0)
    broken=K.copy();broken[0,0]=np.nan
    with pytest.raises(ValueError):FrozenSnapshot.from_data(broken,V,2)
    good=FrozenSnapshot.from_data(K,V,2)
    with pytest.raises(ValueError): good.replace_page(0,np.ones((3,4)),np.ones((3,2)))
    with pytest.raises(ValueError): good.append_page(np.ones((2,5)),np.ones((2,2)))

@pytest.mark.parametrize('fmt', FORMATS)
def test_nonfinite_queries_fail_closed(fmt):
    K=np.ones((4,4),dtype=FORMATS[fmt]);V=np.ones((4,2))
    s=FrozenSnapshot.from_data(K,V,2);m=build_meta(s)
    for bad in (float('nan'),float('inf'),-float('inf')):
        q=np.ones(4,dtype=FORMATS[fmt]);q[0]=bad
        with pytest.raises(ValueError):safe_snapshot_query(s,m,q)

@pytest.mark.parametrize('fmt', FORMATS)
def test_query_precision_and_shape_must_match(fmt):
    K=np.ones((4,4),dtype=FORMATS[fmt]);V=np.ones((4,2))
    s=FrozenSnapshot.from_data(K,V,2);m=build_meta(s)
    with pytest.raises(ValueError):safe_snapshot_query(s,m,np.ones(4,dtype='float64'))
    with pytest.raises(ValueError):safe_snapshot_query(s,m,np.ones((1,4),dtype=FORMATS[fmt]))
