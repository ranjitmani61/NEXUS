# G3/G4 Contract — Token-granular transactional KV snapshots

**Version:** 1.1; **date:** 2026-11-03; **owner/review lenses:** A1 architecture, A2 numerical analysis, A3 AI systems, A4 runtime, A6 memory, A8 verification, A10 performance, A11 prior art. **Independent specialist review:** none.

## Objective
Investigate whether immutable page-level copy-on-write can append exactly one KV token at a time and publish a coherent metadata-and-data root, without changing numerical attention outputs beyond a conditional `0.02` normalized value error certificate. Measure update-plus-query CPU latency versus contiguous dense attention on the *same stored inputs*. This is an existing-technique systems reference, not a new processor proposal.

## API and invariants
- `TokenStreamKV.capture()` returns an immutable root with `epoch`, `length`, and ordered pages.
- All non-tail pages have exactly `page_size` valid rows; the tail has 1–`page_size` valid rows. No padded invalid token contributes to attention or metadata.
- Page K and V data and coordinate extrema are separately allocated into read-only byte-backed arrays. A committed root always pairs page metadata with the K of that same page.
- `append(expected,k,v)` validates shape, stored dtype and finiteness, copies only the current tail page or creates a new tail, and constructs an O(P)-size tuple of page references; under the same lock as `capture()`, it atomically replaces the root only if `expected` is still current.
- A failed update leaves the published root unchanged. Readers holding an older root see a stable version; failed competing writers receive `WriteConflict`.
- Append operation costs **O(P) reference-table allocation + O(B·(d+v)) data copying** per token in this Python design, with P pages and B tokens per page. Old retained snapshots can increase resident memory; full peak memory is not measured.
- The screening mechanism is the existing conditional guarded mixed-precision per-page min/max bound, *not* a new algorithm. Queries must match stored FP16/BF16 key types, and one page is considered for admission; otherwise exact dense paged attention runs.

## Numerical caveats
- `guarded_admission` computes FP32 page-score enclosures plus a classical roundoff pad. It does not implement fully directed-rounded interval endpoints; therefore there is **no formal hardware correctness proof**.
- Values are stored FP64 strictly for reference convenience. Dense and candidate outputs use FP64 arithmetic applied to the **same quantized stored keys**, not unquantized original model inputs.
- The `0.02` error criterion is `||output_candidate-output_dense||_2 / max_i ||value_i||_2`. This is not a pretrained-LM quality metric.
- The reported max observed error `0.0` is a floating-point test observation in this deliberately small set of cases and does not imply universal zero error.

## Benchmark matrix (exploratory, fixed before final v1.1 reruns)
- CPU NumPy, single BLAS thread (`OPENBLAS_NUM_THREADS=1`), no GPU or model checkpoint.
- Workloads: clustered keys (first page highly preferred), random keys, near-uniform scores.
- Seeds: 661 and 719; 2 repeated runs of all conditions; 512 initial tokens, 64 token appends, pages of 16, key dimension 32, value dimension 16; 1 query per appended token.
- References: (a) preallocated contiguous dense attention with an additional FP64-converted key cache; (b) preallocated contiguous dense attention converting stored FP16 keys each query; (c) exact page-by-page dense query with online stable softmax. No actual optimized vLLM/PagedAttention kernel was run.
- Candidate time includes capture, token append, tail reconstruction, metadata extrema, atomic publication, metadata stacking, admission decision, and one-page or paged dense attention. References include preallocated append plus dense attention. **All initial cache construction is excluded for every system**; the difference in preprocessing/memory provisioning and separate cost of model execution are not measured.
- Report individual total query+append times and p50/p95; memory values are model payload sizes, not OS RSS or DRAM bytes moved. Memory accounting excludes retained old roots, allocators and temporary arrays.
- Baseline timing is not GPU-optimized and no throughput, power, energy, silicon area or thermal measurement is available.

## Reproduce
```bash
cd /mnt/data
OPENBLAS_NUM_THREADS=1 PYTHONPATH=/mnt/data/tests pytest -q tests/test_g3_token_stream_kv.py tests/test_g3_transactional_kv.py tests/test_g3_snapshot_consistency.py tests/test_g3_guarded_mixed_precision.py
OPENBLAS_NUM_THREADS=1 PYTHONPATH=/mnt/data/tests python tests/g4_token_stream_end_to_end.py --output results/g4_token_stream_v1_1_rep1.json
OPENBLAS_NUM_THREADS=1 PYTHONPATH=/mnt/data/tests python tests/g4_token_stream_end_to_end.py --output results/g4_token_stream_v1_1_rep2.json
```

## Prior-art controls
- vLLM paged KV cache management already uses page/block allocation and prefix sharing. Official documentation: https://docs.vllm.ai/en/latest/api/vllm/v1/core/kv_cache_manager/ and https://github.com/vllm-project/vllm/blob/main/docs/design/hybrid_kv_cache_manager.md
- Original vLLM PagedAttention description: https://vllm-project.github.io/2023/06/20/vllm.html
- FlashAttention-2 is an important optimized dense GPU competitor, not reproduced by this CPU reference: https://proceedings.iclr.cc/paper_files/paper/2024/hash/98ed250b203d1ac6b24bbcf263e3d4a7-Abstract-Conference.html

**Exit decision:** G3/G4 remain IN PROGRESS. Token-level coherency passed tested references; production-GPU concurrency, finite-precision formal safety, pretrained-model G5 validation, and relevant optimized GPU baseline remain unverified.
