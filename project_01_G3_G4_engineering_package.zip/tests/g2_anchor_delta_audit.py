#!/usr/bin/env python3
"""G2 hypothesis audit: reuse exact-arithmetic safe upper bounds across nearby queries.

This is a falsification experiment on SYNTHETIC static KV, not novel hardware,
not actual latency/energy, and not a guarantee of float32 numerical safety.

Run: OPENBLAS_NUM_THREADS=1 python tests/g2_anchor_delta_audit.py \
         --output results/g2_anchor_delta_audit.json
"""
import argparse
import json
import math
import platform
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from attention_screening_audit import build_example, exact_attention, screen as fresh_screen, upper_logsumexp

DATE = '2026-11-03'
B, L, D = 128, 32, 64
TOL = 0.02
Q = 8
SEEDS = [102, 316, 833, 1451, 2026]
REGIMES = ['clustered', 'unstructured', 'uniform', 'needle']
RHO = [1.0, 0.999, 0.99, 0.95, 0.9, 0.5, 0.0]


def metadata(k, anchor):
    # c/r are computed from the keys, with g>= max_j ||k_ij|| per page.
    centers = k.mean(axis=1)
    radii = np.linalg.norm(k - centers[:, None, :], axis=2).max(axis=1)
    g = np.linalg.norm(centers, axis=1) + radii
    u_anchor = (centers @ anchor + np.linalg.norm(anchor) * radii) / math.sqrt(k.shape[-1])
    return u_anchor, g


def delta_upper(u_anchor, g, q, anchor):
    # For every key k in page i:
    # q.k / sqrt(d) = anchor.k / sqrt(d) + (q-anchor).k / sqrt(d)
    # <= u_anchor[i] + norm(q-anchor) * g[i] / sqrt(d).
    return u_anchor + np.linalg.norm(q-anchor) * g / math.sqrt(len(q))


def approx_using_bounds(q, k, v, upper, tol=TOL):
    nblocks, page_len, dim = k.shape
    scores = np.einsum('bld,d->bl', k, q) / math.sqrt(dim)
    vals = np.linalg.norm(v, axis=2)
    vmax = float(vals.max())
    z = 0.0
    y = np.zeros(dim)
    shift = -np.inf
    chosen = []
    cert = 2.0
    for b in np.argsort(-upper):
        page_scores = scores[b]  # computed for reference; fetched only when selected
        shift_new = max(shift, float(page_scores.max()))
        coeff = 0.0 if shift == -np.inf else math.exp(shift-shift_new)
        weights = np.exp(page_scores-shift_new)
        y = coeff*y + weights@v[b]
        z = coeff*z + float(weights.sum())
        shift = shift_new
        chosen.append(int(b))
        missing = np.ones(nblocks, dtype=bool)
        missing[chosen] = False
        upper_unseen = upper[missing]
        log_u = upper_logsumexp(upper_unseen + math.log(page_len))
        log_z = shift + math.log(z)
        if log_u == -np.inf:
            cert = 0.0
        elif log_z >= log_u:
            t = math.exp(log_u-log_z)
            cert = 2*t/(1+t)
        else:
            t = math.exp(log_z-log_u)
            cert = 2/(1+t)
        if cert <= tol:
            break
    truth, _ = exact_attention(q, k, v)
    err = float(np.linalg.norm(y/z - truth) / vmax)
    return {'selected':len(chosen),'certificate':float(cert),'normalized_error':err,
            'score_bound_ok':bool(np.all(scores.max(axis=1) <= upper+1e-10)),
            'certificate_ok':bool(err <= cert+1e-10 and cert <= tol+1e-10)}


def correlated_queries(anchor, rho, seed):
    rng = np.random.default_rng(seed)
    mag = float(np.linalg.norm(anchor))
    axis = anchor / mag
    result = [anchor]
    for _ in range(Q-1):
        direction = rng.normal(size=len(anchor))
        direction -= np.dot(axis, direction)*axis
        direction /= np.linalg.norm(direction)
        result.append(mag*(rho*axis + math.sqrt(max(0.0,1-rho*rho))*direction))
    return result


def run():
    records = []
    failures = []
    for regime in REGIMES:
        for seed in SEEDS:
            anchor,k,v = build_example(seed, regime, B, L, D)
            anchor_upper, g = metadata(k, anchor)
            for rho in RHO:
                qs=correlated_queries(anchor, rho, seed+911)
                fresh_blocks, reused_blocks = [], []
                for t, q in enumerate(qs):
                    # The fair reference recomputes page bounds on every query.
                    ref = fresh_screen(q,k,v,bound='sphere',tol=TOL)
                    bound = anchor_upper if t==0 else delta_upper(anchor_upper,g,q,anchor)
                    alt = approx_using_bounds(q,k,v,bound)
                    if not alt['score_bound_ok'] or not alt['certificate_ok']:
                        failures.append({'regime':regime,'seed':seed,'rho':rho,'q_index':t,'alternative':alt})
                    if ref['normalized_error'] is not None:
                        raise RuntimeError('unexpected incompatible reference')
                    fresh_blocks.append(int(ref['selected_blocks']))
                    reused_blocks.append(alt['selected'])
                # Float32-equivalent memory traffic, not bandwidth or latency.
                kv_bytes_page = L*D*2*4
                dense_bytes = B*kv_bytes_page
                meta_full = B*(D+2)*4
                # Baseline reads all c/r per query. Candidate reads c/r on
                # anchor and 2 per-block scalars on each subsequent query.
                ref_bytes = sum(fresh_blocks)*kv_bytes_page + Q*meta_full
                candidate_bytes = sum(reused_blocks)*kv_bytes_page + meta_full + (Q-1)*B*2*4
                # Alternate idealized baseline: full c/r metadata all on-chip,
                # so eliminate the putative savings for repeated queries.
                ref_hot_bytes = sum(fresh_blocks)*kv_bytes_page
                cand_hot_bytes = sum(reused_blocks)*kv_bytes_page
                records.append({
                    'regime':regime,'seed':seed,'rho':rho,'queries':Q,
                    'fresh_blocks':fresh_blocks,'delta_blocks':reused_blocks,
                    'extra_selected_blocks':sum(reused_blocks)-sum(fresh_blocks),
                    'baseline_fraction_dense':ref_bytes/(Q*dense_bytes),
                    'candidate_fraction_dense':candidate_bytes/(Q*dense_bytes),
                    'candidate_vs_fresh_traffic_ratio':candidate_bytes/ref_bytes,
                    'candidate_vs_fresh_with_hot_metadata_ratio':cand_hot_bytes/max(ref_hot_bytes,1),
                    'candidate_wins_traffic':candidate_bytes < ref_bytes,
                })
    summary=[]
    for regime in REGIMES:
        for rho in RHO:
            rs=[r for r in records if r['regime']==regime and r['rho']==rho]
            summary.append({
                'regime':regime,'rho':rho,'n_seeds':len(rs),
                'median_extra_blocks_per_8_queries':float(np.median([r['extra_selected_blocks'] for r in rs])),
                'median_ref_fraction_dense':float(np.median([r['baseline_fraction_dense'] for r in rs])),
                'median_candidate_fraction_dense':float(np.median([r['candidate_fraction_dense'] for r in rs])),
                'median_candidate_vs_fresh_ratio':float(np.median([r['candidate_vs_fresh_traffic_ratio'] for r in rs])),
                'wins_seeds':sum(r['candidate_wins_traffic'] for r in rs),
            })
    return {'meta':{
        'date':DATE,'gate':'G2 preliminary','hypothesis':'anchor-delta certified page upper-bound reuse',
        'status':'research hypothesis, no novelty or hardware claim',
        'models':'float64 exact-ish math simulation, float32-equivalent modeled bytes',
        'B':B,'L':L,'D':D,'TOL':TOL,'Q':Q,'SEEDS':SEEDS,'REGIMES':REGIMES,'RHO':RHO,
        'python':platform.python_version(),'numpy':np.__version__,
        'limitations':['frozen KV cache; autoregressive append not modeled',
                       'synthetic queries with prescribed cosine correlation, not real LLM traces',
                       'metadata build, storage hierarchy, latency, power, scheduling and cache misses excluded',
                       'score and output certificate verified within float64 tolerance, not verified robust float32 bounds',
                       'no hardware/RTL, no end-to-end token latency or language quality'],
    }, 'tests':{'cases':len(records)*Q,'score_or_certificate_failures':failures,
               'pass':not failures},'summary':summary,'records':records}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',default='results/g2_anchor_delta_audit.json')
    args=p.parse_args()
    ans=run()
    outfile=Path(args.output)
    outfile.parent.mkdir(exist_ok=True,parents=True)
    outfile.write_text(json.dumps(ans,indent=2)+'\n')
    print('Stored:',outfile.resolve())
    print('Tests:',ans['tests']['cases'],'violations:',len(ans['tests']['score_or_certificate_failures']))
    print('regime       rho      median additional pages/8q   cand/ref traffic  wins (of 5)')
    for r in ans['summary']:
        print(f"{r['regime']:12s} {r['rho']:5.3f}    {r['median_extra_blocks_per_8_queries']:8.1f}           {r['median_candidate_vs_fresh_ratio']:10.4f}      {r['wins_seeds']}/5")
    if not ans['tests']['pass']:
        sys.exit(2)

if __name__=='__main__':
    main()
