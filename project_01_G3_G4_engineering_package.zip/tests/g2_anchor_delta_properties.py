#!/usr/bin/env python3
"""Independent adversarial mathematical checks for G2 Anchor-Delta proposal."""
import json
import math
from pathlib import Path
import sys
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from g2_anchor_delta_audit import delta_upper, metadata

rng=np.random.default_rng(20261103)
checks=0
max_excess=0.0
for d in (1, 3, 16, 64, 128):
    for pages in (1, 7):
        for page_len in (1, 5, 32):
            for t in range(30):
                k = rng.normal(size=(pages,page_len,d))
                a = rng.normal(size=d)
                q = rng.normal(size=d)
                if t%5==0: q = a.copy()
                if t%5==1: q = -a.copy()
                if t%5==2: q = 0*a
                if t%5==3: k *= 1e6
                anchor_upper, g=metadata(k,a)
                hi=delta_upper(anchor_upper,g,q,a)
                s = (k@q)/math.sqrt(d)
                excess=float(np.max(s.max(axis=1)-hi))
                max_excess=max(max_excess,excess)
                assert excess <= 1e-9*max(1.0,float(np.max(np.abs(s)))), (d,pages,page_len,t,excess)
                checks+=1

# Model a real failure of incorrectly reusing an anchor when KV cache grows.
a=np.array([1.0,0.0])
old_k=np.zeros((1,1,2))
old_u,old_g=metadata(old_k,a)
new_k=np.array([[[0.0,0.0],[100.0,0.0]]])
unsafe_upper=delta_upper(old_u,old_g,a,a)
new_true_max=float(np.max(new_k@a/math.sqrt(2)))
stale_detected = new_true_max > float(unsafe_upper[0])
assert stale_detected

result={
  'date':'2026-11-03','test':'G2 exact-arithmetic-style upper bound property checks',
  'random_or_boundary_property_checks':checks,
  'max_excess_over_analytic_bound_absolute':max_excess,
  'stale_metadata_counterexample_detected':bool(stale_detected),
  'stale_metadata_example':{'old_upper':float(unsafe_upper[0]),'appended_max_score':new_true_max},
  'pass':True,
  'limitations':'Finite float64 numerical tests only, not formal proof or floating-point safe certification.'
}
p=Path('results/g2_anchor_delta_properties.json');p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
