#!/usr/bin/env python3
"""Incremental KV bound property tests and a deliberate stale metadata counterexample.

These tests use float64; passing does not constitute a float32/BF16 hardware proof.
Run: OPENBLAS_NUM_THREADS=1 python tests/g3_dynamic_kv_properties.py
"""
import json
import math
import sys
from pathlib import Path
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from g3_g4_autoregressive_trace_audit import OnlinePages, screen


def check_update(seed, case):
    rng = np.random.default_rng(seed)
    d=16
    cache=OnlinePages(d)
    tests=0
    errors=0
    errors_out=0
    selected=0
    for t in range(96):
        q=rng.standard_normal(d)
        if case == 'clustered':
            k = (1.5 * q if t == 32 else 0.04*rng.standard_normal(d))
        elif case == 'unstructured':
            k = rng.standard_normal(d)
        else:
            k = np.zeros(d) if t < 80 else (3*q)
        v=rng.standard_normal(d)
        cache.append(k,v)
        if t < 16:
            continue
        if t % 7 == 0 or cache.anchor is None:
            cache.reanchor(q)
        b1=cache.fresh_upper(q)
        b2=cache.reused_upper(q)
        truth,scores=cache.dense(q)
        boundmax = np.array([scores[i*32:i*32+len(a)].max() for i,a in enumerate(cache.keys)])
        a=screen(q,cache,b1)
        b=screen(q,cache,b2)
        for arr,res in [(b1,a),(b2,b)]:
            errors += int(np.any(boundmax > arr+1e-10))
            actual = float(np.linalg.norm(res['result'] - truth)/cache.vmax)
            errors_out += int(actual > res['certificate'] + 1e-10 or res['certificate'] > .020000001)
            selected += res['selected_pages']
            tests += 1
    return tests, errors, errors_out, selected


def stale_counterexample():
    # Two pages. The second is initially irrelevant but gets a new critical
    # token before its page is full. Deliberately reuse its old bound.
    d=16
    q=np.ones(d, dtype=np.float64)
    cache=OnlinePages(d)
    for _ in range(32):
        cache.append(2.0*q, np.zeros(d))
    for _ in range(31):
        cache.append(np.zeros(d), np.zeros(d))
    cache.reanchor(q)
    bound_old=cache.reused_upper(q).copy()
    cache.append(12.0*q, np.ones(d))
    good=cache.reused_upper(q)
    bad=screen(q,cache,bound_old)
    okay=screen(q,cache,good)
    truth,_=cache.dense(q)
    baderror=float(np.linalg.norm(bad['result']-truth)/cache.vmax)
    gooderror=float(np.linalg.norm(okay['result']-truth)/cache.vmax)
    assert good[1] > bound_old[1], (good,bound_old)
    assert baderror > bad['certificate'] + .01, (baderror,bad)
    assert gooderror <= okay['certificate'] + 1e-10
    return {'stale_bound_invalid':True, 'bad_reported_certificate':bad['certificate'],
            'bad_actual_normalized_error':baderror,
            'updated_reported_certificate':okay['certificate'],
            'updated_actual_normalized_error':gooderror,
            'stale_selected_pages':bad['selected_pages'],
            'updated_selected_pages':okay['selected_pages']}


def main():
    total=fail_b=fail_e=selected=0
    for seed in (11,19,37,59):
        for case in ('clustered','unstructured','needle'):
            a,b,c,s=check_update(seed,case)
            total+=a;fail_b+=b;fail_e+=c;selected+=s
    negative=stale_counterexample()
    report={'date':'2026-11-03','test':'G3 incremental cache property audit',
            'conditions':'float64 NumPy, d=16, page_length=32, growing KV, 4 seeds x 3 workloads x 80 queries x 2 methods',
            'certified_query_checks':total,'score_bound_violations':fail_b,
            'certificate_violations':fail_e,'negative_control':negative,
            'pass':fail_b==0 and fail_e==0}
    path=Path(__file__).resolve().parents[1]/'results/g3_dynamic_kv_properties.json'
    path.write_text(json.dumps(report,indent=2)+'\n')
    print(path, 'written')
    print(json.dumps(report,indent=2))
    if not report['pass']:
        raise SystemExit(2)


if __name__=='__main__':
    main()
