#!/usr/bin/env python3
"""G2: conditional shared-weight decode byte model + controlled CPU GEMV/GEMM.

NOT an LLM benchmark, accelerator measurement, or a novel architecture.
The byte model assumes B independent requests with identical nominal context lengths.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import platform
import random
import statistics
import time
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits, threadpool_info


@dataclass(frozen=True)
class Basis:
    params: int = 8_000_000_000
    weight_bytes: float = 2.0
    layers: int = 32
    kv_heads: int = 8
    head_dim: int = 128
    kv_element_bytes: float = 2.0
    bandwidth_bytes_per_s: float = 4.8e12

    def validate(self):
        for n in (self.params, self.layers, self.kv_heads, self.head_dim):
            if not isinstance(n, int) or n <= 0:
                raise ValueError('positive integer dimensions required')
        for f in (self.weight_bytes, self.kv_element_bytes, self.bandwidth_bytes_per_s):
            if not math.isfinite(f) or f <= 0:
                raise ValueError('positive finite byte sizes/bandwidth required')

    def weights(self) -> float:
        self.validate()
        return self.params * self.weight_bytes

    def kv_one(self, context: int) -> float:
        self.validate()
        if not isinstance(context, int) or context < 0:
            raise ValueError('context must be nonnegative integer')
        return 2*self.layers*self.kv_heads*self.head_dim*context*self.kv_element_bytes


def estimate(batch: int, context: int, basis: Basis = Basis(), reuse: float = 1.0):
    """0 reuse = weight read B times; 1 reuse = weight read once.

    This is an illustrative traffic interpolation, not a physical cache model.
    """
    if not isinstance(batch, int) or batch < 1:
        raise ValueError('batch must be positive integer')
    if not math.isfinite(reuse) or not 0 <= reuse <= 1:
        raise ValueError('reuse in [0,1]')
    w, k = basis.weights(), basis.kv_one(context)
    independent_bytes = batch*(w+k)
    shared_weight_loads = 1+(batch-1)*(1-reuse)
    combined_weight_bytes = shared_weight_loads*w
    combined_kv_bytes = batch*k
    combined_bytes = combined_weight_bytes + combined_kv_bytes
    shared_per_token_bytes = combined_bytes/batch
    # Optimistic, shared peak bandwidth, no compute and no overlap.
    return dict(batch=batch, context=context, reuse_fraction_parameter=reuse,
                independent_bytes=independent_bytes,
                batched_bytes=combined_bytes,
                batched_weight_bytes=combined_weight_bytes,
                batched_kv_bytes=combined_kv_bytes,
                weight_bytes_per_request=w,
                kv_bytes_per_request=k,
                traffic_reduction_factor=independent_bytes/combined_bytes,
                batched_bytes_per_token=shared_per_token_bytes,
                batched_traffic_lower_bound_ms=combined_bytes/basis.bandwidth_bytes_per_s*1e3,
                single_request_traffic_lower_bound_ms=(w+k)/basis.bandwidth_bytes_per_s*1e3,
                byte_floor_token_throughput=batch*basis.bandwidth_bytes_per_s/combined_bytes,
                compute_fma_flops_lower_bound=2*basis.params*batch,
                # this cannot be called a measured latency or bandwidth
                note='peak-bandwidth traffic floor only; ignore launch, compute, KV writes and cache reuse')


def cpu_benchmark(n: int, batches: list[int], repeats: int, seed: int):
    if n <= 0 or repeats <= 0 or not batches or any(b < 1 for b in batches):
        raise ValueError('invalid benchmark dimensions')
    rng = np.random.default_rng(seed)
    w = np.asfortranarray(rng.standard_normal((n,n), dtype=np.float32))
    data = []
    # pin 1 CPU BLAS thread to separate batching gains from threadcount effects
    with threadpool_limits(limits=1, user_api='blas'):
        pool = threadpool_info()
        for b in batches:
            x = np.asfortranarray(rng.standard_normal((n,b),dtype=np.float32))
            seq = np.empty((n,b),dtype=np.float32,order='F')
            bat = np.empty((n,b),dtype=np.float32,order='F')
            def repeated_gemv():
                for j in range(b):
                    np.dot(w,x[:,j],out=seq[:,j])
            def fused_gemm():
                np.matmul(w,x,out=bat)
            for _ in range(2):
                repeated_gemv(); fused_gemm()
            max_error = float(np.max(np.abs(seq-bat)))
            np.testing.assert_allclose(seq,bat,rtol=6e-4,atol=2e-3)
            measures = {'gemv_separate': [], 'gemm_fused': []}
            fn = {'gemv_separate': repeated_gemv, 'gemm_fused': fused_gemm}
            # Paired runs, alternating order in deterministic randomized blocks.
            order_rng = random.Random(seed*1000+n*47+b)
            for _ in range(repeats):
                arms = list(fn)
                order_rng.shuffle(arms)
                for name in arms:
                    start = time.perf_counter_ns()
                    fn[name]()
                    measures[name].append((time.perf_counter_ns()-start)/1e6)
            m_seq = statistics.median(measures['gemv_separate'])
            m_bat = statistics.median(measures['gemm_fused'])
            data.append(dict(dimension=n,batch=b,seed=seed,repeats=repeats,
                             seq_median_ms=m_seq,batch_median_ms=m_bat,
                             speedup_sequential_over_batch=m_seq/m_bat,
                             batch_per_token_ms=m_bat/b,
                             batch_vs_one_seq_latency_ratio=None,
                             max_abs_error=max_error,
                             raw_ms=measures))
    return pool, data


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,default=Path('results/g2_weight_reuse_batch.json'))
    p.add_argument('--size',type=int,nargs='+',default=[2048,4096])
    p.add_argument('--batch',type=int,nargs='+',default=[1,2,4,8,16,32])
    p.add_argument('--repeats',type=int,default=7)
    p.add_argument('--seeds',type=int,nargs='+',default=[7,19])
    a=p.parse_args()
    basis=Basis()
    cases={str(t):{str(b): estimate(b,t,basis) for b in a.batch} for t in (4096,8192,32768,131072)}
    sims={str(r):estimate(32,8192,basis,r) for r in (0.0,0.5,0.9,1.0)}
    trials=[]
    pool=None
    for n in a.size:
        for seed in a.seeds:
            pool, observed=cpu_benchmark(n,a.batch,a.repeats,seed)
            trials += observed
    baseline_times = {(x['dimension'],x['seed']):x['seq_median_ms'] for x in trials if x['batch']==1}
    for row in trials:
        row['batch_vs_one_seq_latency_ratio'] = row['batch_median_ms']/baseline_times[(row['dimension'],row['seed'])]
    out=dict(title='G2 shared-weight amortization: conditional byte model and CPU BLAS microbenchmark',
             date='2026-11-03',gate='G2/G4 partial only; G5 blocked',
             basis=asdict(basis),
             analytic_cases=cases,reuse_sensitivity=sims,
             cpu_blas_benchmarks=trials,
             environment=dict(python=platform.python_version(),numpy=np.__version__,
                              processor=platform.processor(),os=platform.platform(),
                              blas_after_limiting=pool,thread_mode='threadpoolctl, one OpenBLAS thread'),
             limitations=[
                'Conditional ideal stream model, not HBM bus measurements or GPU timing',
                'Model weight reuse is already standard in batched matrix multiplication',
                'Assumes batch shares weight scan and each sequence reads all K/V once',
                'Ignores kernel launch, synchronization, scheduler, paging, compute time, energy, quality and latency SLA',
                'Peak published bandwidth is not effective achieved bandwidth',
                'CPU microbenchmark times only matrix projections, not full-model or GPU decode',
                'CPU matrix sizes fit into host memory/cache; cache and memory hierarchy differ drastically from 8B GPU model',
                'Same matrix shared across b queries; control is repeated GEMV with identical BLAS thread count',
                'Paired order randomized; jitter and CPU frequency/load may affect results',
                'Batch latency measured from synchronous start, not queuing delay and tail latency',
             ],
             prior_art=[
                'https://vllm.ai/blog/2025-09-05-anatomy-of-vllm',
                'https://www.usenix.org/system/files/osdi24_full_proceedings.pdf',
                'https://arxiv.org/abs/2501.01005',
             ])
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print('Saved',a.output)
    for t in (4096,8192,32768):
        for b in (1,8,32):
            if b in a.batch:
                z=cases[str(t)][str(b)]
                print(f'Analytic T={t} B={b}: {z["traffic_reduction_factor"]:.3f}x bytes, batch floor {z["batched_traffic_lower_bound_ms"]:.3f} ms')
    for n in a.size:
        for b in a.batch:
            q=[x for x in trials if x['dimension']==n and x['batch']==b]
            print(f'CPU N={n}, B={b}: speedup median={statistics.median(v["speedup_sequential_over_batch"] for v in q):.3f}x; '+
                  f'latency ratio vs B1={statistics.median(v["batch_vs_one_seq_latency_ratio"] for v in q):.2f}x; max err {max(v["max_abs_error"] for v in q):.3g}')

if __name__=='__main__':
    main()
