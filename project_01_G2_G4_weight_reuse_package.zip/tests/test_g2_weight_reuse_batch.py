import math
import unittest
from g2_weight_reuse_batch import Basis, estimate, cpu_benchmark

class WeightReuseTest(unittest.TestCase):
    def test_batch_one_neutral(self):
        a=estimate(1,8192)
        self.assertAlmostEqual(a['traffic_reduction_factor'],1)
    def test_reuse_zero_neutral(self):
        for b in [1,2,16,64]:
            self.assertAlmostEqual(estimate(b,8192,reuse=0)['traffic_reduction_factor'],1)
    def test_reuse_one_is_optimal_in_given_model(self):
        x=estimate(32,8192,reuse=1)
        y=estimate(32,8192,reuse=0.5)
        self.assertGreater(x['traffic_reduction_factor'],y['traffic_reduction_factor'])
    def test_weight_bytes_amortized(self):
        a=estimate(32,8192)
        self.assertEqual(a['batched_weight_bytes'], Basis().weights())
    def test_kv_not_amortized(self):
        a=estimate(32,8192)
        self.assertEqual(a['batched_kv_bytes'],32*Basis().kv_one(8192))
    def test_monotonic_batch_throughput_byte_only(self):
        r=[estimate(b,8192)['byte_floor_token_throughput'] for b in [1,2,8,32]]
        self.assertEqual(r, sorted(r))
    def test_more_context_reduces_weight_amortization_ratio(self):
        self.assertGreater(estimate(32,4096)['traffic_reduction_factor'], estimate(32,131072)['traffic_reduction_factor'])
    def test_independent_traffic_exact(self):
        a=estimate(8,8192)
        self.assertEqual(a['independent_bytes'],8*(Basis().weights()+Basis().kv_one(8192)))
    def test_batch_cost_never_below_kv(self):
        a=estimate(32,8192)
        self.assertGreater(a['batched_bytes'],a['batched_kv_bytes'])
    def test_invalid_batch(self):
        for b in (0,-1,1.2):
            with self.assertRaises(ValueError):estimate(b,8192)
    def test_invalid_context(self):
        for x in (-1,4.2):
            with self.assertRaises(ValueError):estimate(2,x)
    def test_invalid_reuse(self):
        for r in (-0.01,1.01, math.nan):
            with self.assertRaises(ValueError):estimate(2,8192,reuse=r)
    def test_invalid_params(self):
        with self.assertRaises(ValueError): estimate(2,8192,Basis(params=0))
    def test_zero_context_baseline(self):
        self.assertAlmostEqual(estimate(32,0)['traffic_reduction_factor'],32)
    def test_microbenchmark_numerical(self):
        _,res=cpu_benchmark(32,[1,4],2,7)
        self.assertEqual(len(res),2)
        for row in res:
            self.assertLess(row['max_abs_error'],1e-3)

if __name__ == '__main__':unittest.main()
