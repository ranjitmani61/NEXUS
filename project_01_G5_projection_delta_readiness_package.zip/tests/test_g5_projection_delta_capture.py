"""G5 instrumentation tests: ALL models below are randomly initialized MOCKS.

No pretrained weights; these verify capture semantics and numerical recurrence only.
"""
from types import SimpleNamespace
import numpy as np
import math
import pytest
import torch
from torch import nn

from g5_projection_delta_capture import (
    capture_inputs,evaluate_projection_deltas,projection_modules,summarize)

class MockAttention(nn.Module):
    def __init__(self,d):
        super().__init__()
        self.query_key_value=nn.Linear(d,3*d)
        self.dense=nn.Linear(d,d)
    def forward(self,x):
        d=x.shape[-1]
        q,k,v=self.query_key_value(x).split(d,dim=-1)
        logits=q@k.transpose(-1,-2)/math.sqrt(d)
        causal=torch.triu(torch.ones(x.shape[1],x.shape[1],device=x.device,dtype=torch.bool),diagonal=1)
        a=logits.masked_fill(causal,torch.finfo(logits.dtype).min).softmax(dim=-1)
        return self.dense(a@v)
class MockMlp(nn.Module):
    def __init__(self,d,activation='gelu'):
        super().__init__()
        self.dense_h_to_4h=nn.Linear(d,4*d)
        self.dense_4h_to_h=nn.Linear(4*d,d)
        self.activation=nn.GELU() if activation=='gelu' else nn.ReLU()
    def forward(self,x):
        return self.dense_4h_to_h(self.activation(self.dense_h_to_4h(x)))
class MockLayer(nn.Module):
    def __init__(self,d,activation='gelu'):
        super().__init__()
        self.attention=MockAttention(d)
        self.mlp=MockMlp(d,activation)
    def forward(self,x):
        return x+0.1*self.attention(x)+0.1*self.mlp(x)
class FakeNeoX(nn.Module):
    def __init__(self,d,layers,activation='gelu'):
        super().__init__()
        self.layers=nn.ModuleList([MockLayer(d,activation) for _ in range(layers)])
    def forward(self,x):
        for layer in self.layers:x=layer(x)
        return x
class MockNeoXModel(nn.Module):
    def __init__(self,seed=7,d=8,layers=2,noncausal=False,activation='gelu'):
        super().__init__()
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed)
            self.embedding=nn.Embedding(127,d)
            self.gpt_neox=FakeNeoX(d,layers,activation)
            self.embed_out=nn.Linear(d,31)
        self.config=SimpleNamespace(model_type='gpt_neox')
        self.noncausal=noncausal
    def forward(self,ids,*,use_cache=False,return_dict=True):
        x=self.embedding(ids)
        if self.noncausal:
            x=x+x.mean(dim=1,keepdim=True) # deliberately INVALID causal transformer
        return {'logits':self.embed_out(self.gpt_neox(x))}

@pytest.mark.parametrize('seed',[7,19])
def test_capture_complete_prefix_consistency(seed):
    model=MockNeoXModel(seed=seed)
    ids=torch.arange(24,dtype=torch.long).reshape(1,-1)
    caps,integ=capture_inputs(model,ids,last_pairs=5)
    assert integ['checked_projection_count']==9
    assert integ['prefix_consistency_max_abs_error']<1e-7
    assert len(caps)==9
    assert caps['layer0.attention.query_key_value'].shape==(6,8)
    assert caps['layer0.mlp.dense_4h_to_h'].shape==(6,32)
    assert not any(m._forward_pre_hooks for m in projection_modules(model).values())
    r=evaluate_projection_deltas(caps,projection_modules(model),tolerance=.02)
    s=summarize(r)
    assert len(r['rows'])==9*5
    assert s['0.0']['maximum_relative_projection_l2_error']<1e-12
    assert s['0.0']['all_tested_projections_meet_error']
    # GELU is the Pythia-like default; changed coordinates should be dense in this toy.
    assert 0.99<=s['0.0']['weighted_input_delta_fraction_selected']<=1.0
    row=next(r for r in r['rows'] if r['projection']=='lm_head' and r['threshold']==0.0)
    assert row['exact_change_fraction']==1.0


def test_mock_relu_vs_gelu_negative_control():
    ids=torch.arange(24,dtype=torch.long).reshape(1,-1)
    gelu=MockNeoXModel(seed=7,activation='gelu')
    relu=MockNeoXModel(seed=7,activation='relu')
    a,_=capture_inputs(gelu,ids,last_pairs=5)
    b,_=capture_inputs(relu,ids,last_pairs=5)
    ga=evaluate_projection_deltas(a,projection_modules(gelu))
    rb=evaluate_projection_deltas(b,projection_modules(relu))
    # The shape-level harness must not call ReLU-induced zeros Pythia behavior.
    gg=next(x for x in ga['rows'] if x['projection']=='layer0.mlp.dense_4h_to_h' and x['threshold']==0)
    rr=next(x for x in rb['rows'] if x['projection']=='layer0.mlp.dense_4h_to_h' and x['threshold']==0)
    assert rr['exact_change_fraction']<gg['exact_change_fraction']
    assert gg['exact_change_fraction']>=.99

def test_detect_noncausal_prefix_leakage():
    model=MockNeoXModel(noncausal=True)
    ids=torch.arange(20).reshape(1,-1)
    with pytest.raises(AssertionError,match='causal prefix mismatch'):
        capture_inputs(model,ids,last_pairs=4)
    assert not any(m._forward_pre_hooks for m in projection_modules(model).values())


def test_extremely_sparse_fixture_recurrence():
    m=nn.Linear(4,4,bias=True)
    with torch.no_grad():
        m.weight.copy_(torch.eye(4)); m.bias.zero_()
    x=torch.tensor([[2.,2.,2.,2.],[2.,2.,3.,2.],[2.,2.,4.,2.],[2.,2.,5.,2.]])
    r=evaluate_projection_deltas({'sparse':x},{'sparse':m},thresholds=[0.,.1,1.5],tolerance=.02)
    a,b,c=r['rows']
    assert a['selected_fraction']==pytest.approx(.25)
    assert a['max_relative_projection_l2_error']<1e-12
    assert b['selected_fraction']==pytest.approx(.25)
    assert c['selected_fraction']==0
    assert c['max_relative_projection_l2_error']>.02


def test_full_zero_changes():
    m=nn.Linear(8,7)
    x=torch.ones(5,8)
    r=evaluate_projection_deltas({'zero':x},{'zero':m},thresholds=(0.,.01))
    assert all(row['selected_fraction']==0 for row in r['rows'])
    assert all(row['max_relative_projection_l2_error']<1e-12 for row in r['rows'])


def test_reject_different_architecture():
    model=MockNeoXModel()
    model.config.model_type='bert'
    with pytest.raises(TypeError,match='Unsupported architecture'):projection_modules(model)


def test_reject_missing_linear_projection():
    model=MockNeoXModel()
    model.gpt_neox.layers[0].mlp.dense_h_to_4h=nn.ReLU()
    with pytest.raises(TypeError,match='Expected nn.Linear'):projection_modules(model)

@pytest.mark.parametrize('ids,lp',[
    (torch.ones((2,20),dtype=torch.int64),4),
    (torch.ones((1,20),dtype=torch.float32),4),
    (torch.ones((1,20),dtype=torch.int64),20),
    (torch.ones((1,20),dtype=torch.int64),0),
])
def test_reject_invalid_capture_inputs(ids,lp):
    with pytest.raises(ValueError):capture_inputs(MockNeoXModel(),ids,last_pairs=lp)


def test_reject_nonfinite_projection_input():
    m=nn.Linear(3,5)
    x=torch.randn(4,3);x[0,0]=float('nan')
    with pytest.raises(ValueError,match='malformed'):evaluate_projection_deltas({'m':x},{'m':m})


def test_reject_nonfinite_weights():
    m=nn.Linear(3,5)
    with torch.no_grad():m.weight[0,0]=float('inf')
    with pytest.raises(ValueError,match='Non-finite'):evaluate_projection_deltas({'m':torch.randn(4,3)},{'m':m})

@pytest.mark.parametrize('thresholds',[(.1,.01),(-.01,.1),(.1,.1),(0.,float('nan'))])
def test_reject_invalid_thresholds(thresholds):
    m=nn.Linear(3,5)
    with pytest.raises(ValueError):evaluate_projection_deltas({'m':torch.randn(4,3)},{'m':m},thresholds=thresholds)


def test_reject_missing_module():
    with pytest.raises(ValueError,match='exactly match'):
        evaluate_projection_deltas({'a':torch.randn(4,3)},{'b':nn.Linear(3,5)})


def test_repeated_capture_no_hooks_leaked():
    model=MockNeoXModel()
    ids=torch.arange(20).reshape(1,-1)
    c1,_=capture_inputs(model,ids,last_pairs=3)
    c2,_=capture_inputs(model,ids,last_pairs=3)
    for key in c1:
        assert torch.equal(c1[key],c2[key])
    assert not any(m._forward_pre_hooks for m in projection_modules(model).values())
