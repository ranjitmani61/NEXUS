#!/usr/bin/env python3
"""G5 *readiness* instrumentation: probe token-to-token linear projection inputs.

No model weights or pretrained claims are provided by this module. If a real
checkpoint is available, the CLI can collect its input-delta distributions.
All diagnostics are FULL-DENSE, offline *hypothetical* sparse-output estimates;
they are not achievable accelerator runtimes or end-to-end model-error proofs.

Version 1.0, 2026-11-03. Project operating rules: AGENTS.md.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import platform
from pathlib import Path
from typing import Mapping

import numpy as np
import torch
from torch import nn

DEFAULT_MODEL = 'EleutherAI/pythia-14m'
DEFAULT_REV = 'cf967c0a9a04383db6f7b1108d86b2962634b4ac'
# PRE-REGISTERED absolute input-delta thresholds (in actual activation units).
DEFAULT_THRESHOLDS = (0.0, 0.001, 0.01, 0.05, 0.1)
DATE = '2026-11-03'
VERSION = '1.0'


def projection_modules(model: nn.Module) -> dict[str, nn.Linear]:
    """Only GPT-NeoX/Pythia named torch.nn.Linear projections, no silent substitutions."""
    if getattr(getattr(model, 'config', None), 'model_type', None) != 'gpt_neox':
        raise TypeError('Unsupported architecture (GPT-NeoX only); abort instead of mislabeling')
    if not hasattr(model, 'gpt_neox') or not hasattr(model.gpt_neox, 'layers'):
        raise TypeError('Missing GPT-NeoX transformer layers')
    layers = model.gpt_neox.layers
    if not len(layers):
        raise ValueError('Zero layers')
    result = {}
    for i, layer in enumerate(layers):
        for path in ('attention.query_key_value','attention.dense',
                     'mlp.dense_h_to_4h','mlp.dense_4h_to_h'):
            module = layer
            for part in path.split('.'):
                module = getattr(module,part,None)
                if module is None:
                    raise TypeError(f'Missing required layer {i} projection {path}')
            if not isinstance(module,nn.Linear):
                raise TypeError(f'Expected nn.Linear: {i}.{path}, got {type(module)}')
            result[f'layer{i}.{path}']=module
    # Head is useful but distinct from a transformer layer.
    head=getattr(model, 'embed_out', None)
    if head is not None:
        if not isinstance(head,nn.Linear):
            raise TypeError('embed_out must be nn.Linear when present')
        result['lm_head']=head
    return result


def capture_inputs(model: nn.Module, ids: torch.Tensor, *, last_pairs: int=8,
                   verify_prefix: bool=True, check_atol: float=3e-5) -> tuple[dict[str,torch.Tensor],dict]:
    """Collect last last_pairs+1 positions of *inputs* to each linear module.

    Prefix consistency: rerun one shorter causal prefix and verify activations
    for the final token of the shorter prefix. Detects unsupported noncausal
    layers, dropout or misaligned positional handling in tested range.
    Does not validate true incremental KV-cache decoding semantics.
    """
    modules=projection_modules(model)
    if not isinstance(ids,torch.Tensor) or ids.ndim!=2 or ids.shape[0]!=1 or ids.dtype!=torch.int64:
        raise ValueError('ids must be int64 tensor [1,T]')
    t=int(ids.shape[1])
    if not (1<=last_pairs<t):
        raise ValueError('last_pairs must be 1..T-1')
    if not (np.isfinite(check_atol) and check_atol>0):
        raise ValueError('check_atol must be finite and positive')
    model.eval()
    device=next(model.parameters()).device
    inputs={}
    handles=[]
    def make_hook(name, sink, include):
        def hook(_module, args):
            if not args or not isinstance(args[0],torch.Tensor) or args[0].ndim!=3:
                raise RuntimeError(f'{name} received non-[batch,seq,hidden] input')
            v=args[0]
            if v.shape[0]!=1 or v.shape[1]<include:
                raise RuntimeError(f'{name} had unexpected batch/token shape')
            sink[name]=v[0,-include:,:].detach().to('cpu',torch.float32).clone()
        return hook
    try:
        for name, module in modules.items():
            handles.append(module.register_forward_pre_hook(make_hook(name,inputs,last_pairs+1)))
        with torch.inference_mode():
            model(ids.to(device),use_cache=False,return_dict=True)
    finally:
        for h in handles:h.remove()
    if set(inputs)!=set(modules):
        raise RuntimeError(f'Missing hook activations: {sorted(set(modules)-set(inputs))}')
    for name,v in inputs.items():
        if not torch.isfinite(v).all():
            raise ValueError(f'Non-finite captured activation for {name}')
        if v.shape!=(last_pairs+1,modules[name].in_features):
            raise RuntimeError(f'{name}: captured shape does not match weight')
    prefix_checks={}
    if verify_prefix:
        older={};h=[]
        try:
            for name,module in modules.items():
                h.append(module.register_forward_pre_hook(make_hook(name,older,1)))
            with torch.inference_mode():
                model(ids[:,:-1].to(device),use_cache=False,return_dict=True)
        finally:
            for hook in h: hook.remove()
        if set(older)!=set(modules):
            raise RuntimeError('Prefix rerun missed projection hooks')
        for name in modules:
            a=inputs[name][-2];b=older[name][-1]
            e=float(torch.max(torch.abs(a-b)).item())
            prefix_checks[name]=e
            if not np.isfinite(e) or e>check_atol:
                raise AssertionError(f'{name}: causal prefix mismatch {e:.6g} > {check_atol}')
    return inputs,{'prefix_consistency_max_abs_error':max(prefix_checks.values(),default=None),
                   'checked_projection_count':len(prefix_checks),'tokens':t,'last_pairs':last_pairs}


def evaluate_projection_deltas(inputs: Mapping[str,torch.Tensor], modules: Mapping[str,nn.Linear],
                               *, thresholds=DEFAULT_THRESHOLDS, tolerance:float=0.02)->dict:
    """Offline local linear-projection diagnostic (not measured sparse compute).

    Exact algebra (real arithmetic): y_t = y_{t-1} + W(x_t - x_{t-1}).
    Approx candidate: y^*_t = y_{t-1} + W(delta * (abs(delta) > tau)).
    Error divided by ||y_t||_2 (floor 1e-12), computed in FP64 here.
    Entire model propagation/error and discovery overhead are EXCLUDED.
    """
    if not(np.isfinite(tolerance) and 0<tolerance<1):
        raise ValueError('tolerance must be in (0,1)')
    ts=tuple(float(x) for x in thresholds)
    if not ts or any(not np.isfinite(x) or x<0 for x in ts) or sorted(set(ts))!=list(ts):
        raise ValueError('thresholds must be strictly increasing, finite, nonnegative')
    if set(inputs)!=set(modules) or not inputs:
        raise ValueError('Projection input/module names must exactly match')
    rows=[]
    for name,module in modules.items():
        x=inputs[name]
        if x.ndim!=2 or x.shape[0]<2 or x.shape[1]!=module.in_features or not torch.isfinite(x).all():
            raise ValueError('Input capture malformed')
        x=x.to(dtype=torch.float64,device='cpu')
        weight=module.weight.detach().to(dtype=torch.float64,device='cpu')
        bias=None if module.bias is None else module.bias.detach().to(dtype=torch.float64,device='cpu')
        if not torch.isfinite(weight).all() or (bias is not None and not torch.isfinite(bias).all()):
            raise ValueError('Non-finite projection parameters')
        # FP64 dense oracle is deliberately used for BOTH cases; no timing claims.
        exact=x @ weight.T
        if bias is not None:exact=exact+bias
        dx=x[1:]-x[:-1]
        baseline=exact[:-1]
        target=exact[1:]
        den=torch.linalg.vector_norm(target,dim=1).clamp_min(1e-12)
        abs_dx=dx.abs()
        exact_change_fraction=float((abs_dx>0).double().mean().item())
        for threshold in ts:
            mask=abs_dx>threshold
            reconstructed=baseline+(dx*mask)@weight.T
            errors=(torch.linalg.vector_norm(reconstructed-target,dim=1)/den)
            max_err=float(errors.max().item())
            p95_err=float(np.percentile(errors.numpy(),95))
            rows.append({'projection':name,'input_dim':module.in_features,'output_dim':module.out_features,
                         'pairs':x.shape[0]-1,'threshold':threshold,
                         'exact_change_fraction':exact_change_fraction,
                         'selected_fraction':float(mask.double().mean().item()),
                         'max_relative_projection_l2_error':max_err,
                         'p95_relative_projection_l2_error':p95_err,
                         'all_pairs_meet_tolerance':bool(max_err<=tolerance+1e-12)})
    return {'rows':rows,'thresholds':ts,'projection_count':len(modules),
            'tolerance':tolerance,'oracle_type':'offline FP64 local-linear projection diagnostic',
            'disclaimer':'Full dense activations/weights used; no end-to-end or hardware speedup claims'}


def summarize(result:dict)->dict:
    rows=result['rows']; ts=result['thresholds']
    summary={}
    for threshold in ts:
        subset=[r for r in rows if r['threshold']==threshold]
        total=sum(r['pairs']*r['input_dim'] for r in subset)
        selected=sum(r['selected_fraction']*r['pairs']*r['input_dim'] for r in subset)
        summary[str(threshold)]={
            'weighted_input_delta_fraction_selected': float(selected/total),
            'maximum_relative_projection_l2_error':max(r['max_relative_projection_l2_error'] for r in subset),
            'all_tested_projections_meet_error':all(r['all_pairs_meet_tolerance'] for r in subset),
            'minimum_projection_selected_fraction':min(r['selected_fraction'] for r in subset),
            'maximum_projection_selected_fraction':max(r['selected_fraction'] for r in subset)}
    return summary


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--text-file',type=Path,required=True)
    p.add_argument('--model',default=DEFAULT_MODEL)
    p.add_argument('--revision',default=DEFAULT_REV)
    p.add_argument('--max-tokens',type=int,default=256)
    p.add_argument('--last-pairs',type=int,default=8)
    p.add_argument('--tolerance',type=float,default=0.02)
    p.add_argument('--local-files-only',action='store_true')
    p.add_argument('--output',type=Path,default=Path('results/g5_real_pretrained_delta.json'))
    args=p.parse_args()
    if args.model!=DEFAULT_MODEL:
        p.error('Only Pythia-14M supported; other models require adapter review')
    if not args.text_file.exists():
        p.error('Text file not found')
    if not(2<=args.max_tokens<=2048 and 1<=args.last_pairs<args.max_tokens):
        p.error('Invalid max tokens / last pairs')
    # Delay import so tests can run without Transformers.
    try:
        import transformers
        from transformers import AutoModelForCausalLM,AutoTokenizer
    except ImportError as exc:
        raise SystemExit(f'Pretrained run BLOCKED: missing transformers package: {exc}')
    txt=args.text_file.read_text(encoding='utf8')
    digest=hashlib.sha256(txt.encode()).hexdigest()
    model=AutoModelForCausalLM.from_pretrained(args.model,revision=args.revision,
            torch_dtype=torch.float32,local_files_only=args.local_files_only,trust_remote_code=False)
    tokenizer=AutoTokenizer.from_pretrained(args.model,revision=args.revision,
            local_files_only=args.local_files_only,trust_remote_code=False)
    ids=tokenizer(txt,return_tensors='pt',add_special_tokens=False)['input_ids'][:, :args.max_tokens]
    if ids.shape[1]<args.last_pairs+1:
        p.error('Sample text token count is too short')
    captured,integrity=capture_inputs(model,ids,last_pairs=args.last_pairs)
    measured=evaluate_projection_deltas(captured,projection_modules(model),tolerance=args.tolerance)
    result={
      'metadata':{'version':VERSION,'date':DATE,'status':'PRETRAINED MODEL DIAGNOSTIC; NOT G5 PASS',
       'model':args.model,'revision_requested':args.revision,
       'revision_resolved':getattr(model.config,'_commit_hash',None),
       'text_sha256':digest,'tokens':int(ids.shape[1]),'last_pairs':args.last_pairs,
       'torch':torch.__version__,'transformers':transformers.__version__,
       'python':platform.python_version(),'precision_capture':'float32',
       'oracle_math':'float64','device':str(next(model.parameters()).device)},
      'integrity':integrity,'summary':summarize(measured),'projection_rows':measured['rows'],
      'limitations':measured['disclaimer']+'; causal prefill (NOT actual KV decode)'}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['summary'],indent=2));print('saved',args.output)

if __name__=='__main__': main()
