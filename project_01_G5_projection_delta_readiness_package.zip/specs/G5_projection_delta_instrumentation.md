# G5 projection-delta capture — instrumentation specification (v1.0)
**Date:** 2026-11-03. **Status:** Readiness artifact only. **Operating protocol:** `AGENTS.md`.

## Target and hypothesis

Measure whether successive token positions in a **genuinely pretrained**, pinned GPT-NeoX checkpoint exhibit exact or small activation changes at each of the four named linear projections per transformer layer, and the final LM head. The hypothesis that these changes are sparse is **not assumed true**. The falsifier is density near 100% at accuracy-preserving thresholds, or any corrected end-to-end slower runtime. The method itself is prior art (Delta Networks/Chipmunk) and cannot be claimed as a new processor mechanism.

## Engineering methods

A1 architecture: GPT-NeoX-specific projection discovery; A2 numerical: evaluate recurrence in FP64; A3 AI/ML: prefill activation capture, model pinning; A4 runtime: forward pre-hooks; A8 verification: negative controls/prefix causality; A10 systems: explicitly separate oracle diagnostics from runtime. A5–A7/A9/A12 require external/hardware review and have not reviewed this design.

For `nn.Linear`, `y_t = W x_t + b`; therefore `y_t = y_(t-1) + W (x_t-x_(t-1))` in real arithmetic. For a threshold `tau`, set `Δ_j'=Δ_j` when `|Δ_j| > tau`, else 0. The approximate local output is `y*_t = y_(t-1) + W Δ'`. Compute FP64 `||y*_t-y_t||_2 / max(||y_t||_2,1e-12)`; max <= 0.02 is only a *local projection* diagnostic, **not** a bound on model token output, prediction quality or accumulation through multiple layers.

Pre-register absolute thresholds `[0,0.001,0.01,0.05,0.1]`; include *all* four projections per layer (`attention.query_key_value`, `attention.dense`, `mlp.dense_h_to_4h`, `mlp.dense_4h_to_h`), plus `embed_out` if present. All counts are selected **input components**, not measured weight bytes, hardware operations, or speedups. Dense projections and weights are read for these oracle diagnostics; selection/runtime costs are omitted. Reconstructing a previous linear output is assumed available at no cost only for the diagnostic; true runtime cannot assume this without charged costs.

For each text example, retain only the most recent N+1 token positions for a window of N deltas; run model in eval + inference mode. Re-run the shortened prefix and compare each module input for its final token to the corresponding full-prompt activation. Abort if max absolute difference >3e-5. This verifies *prefill causal-prefix consistency in the tested model/precision*, **not** decode KV-cache correctness. Memory use is bounded by `(N+1) × sum(projection input dimensions)` captured float32 elements (ignoring temporary model execution buffers and parameters). The test does **not** presently capture QKV heads individually or propagate local perturbations through later layers.

## Source and model integrity

Model target `EleutherAI/pythia-14m`, revision `cf967c0a9a04383db6f7b1108d86b2962634b4ac`; model config at that revision says `hidden_act: gelu`, 6 layers, 4 heads, 128 hidden dimensions, 2048 max positions. The module names are present in Transformers GPT-NeoX source as viewed 2026-11-03. The repo changed its default dataset variant in February 2026; pinning the exact revision is needed for comparability.

- Pinned model config: https://huggingface.co/EleutherAI/pythia-14m/blob/cf967c0a9a04383db6f7b1108d86b2962634b4ac/config.json
- Model card: https://huggingface.co/EleutherAI/pythia-14m
- Upstream implementation: https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt_neox/modeling_gpt_neox.py
- Prior art: https://proceedings.mlr.press/v70/neil17a.html ; https://arxiv.org/abs/2506.03275

## Reproducibility and environment

Local checks (all intentionally using randomly initialized mocks, NOT Pythia weights):

```bash
cd /mnt/data
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -m pytest -q \
 tests/test_g5_projection_delta_capture.py tests/test_g5_capture_shapes.py \
 tests/test_g5_trace_oracle.py tests/test_g2_temporal_delta_gemv.py \
 tests/test_g2_delta_transformer_activation.py
```

Unexecuted pretrained capture, once the official pinned checkpoint and Transformers are available:

```bash
python tests/g5_projection_delta_capture.py --text-file /path/to/public_language_sample.txt \
  --max-tokens 256 --last-pairs 8 --local-files-only \
  --output results/g5_real_pretrained_delta.json
```

The completed local resource probe found no checkpoint and no installed Transformers, and the workspace could not resolve huggingface.co. No pretrained model test ran; no billed remote job was launched. Real-data collection requires fixed public datasets across tasks, multiple models, KV-decode checks, strong sparse/dense baselines, quality, bytes and energy before G5 can pass.

**Gate decision:** G5 BLOCKED. G1 novelty FAILED for ordinary temporal-delta execution. G6 hardware NOT AUTHORIZED.
