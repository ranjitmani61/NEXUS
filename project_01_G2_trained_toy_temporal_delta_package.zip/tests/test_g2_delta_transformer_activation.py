"""Invariant and negative-control checks for G2 toy transformer experiment."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import numpy as np
import torch
import pytest
from g2_delta_transformer_activation_audit import MiniCausal, make_tokens, evaluate_delta, VOCAB, SEQLEN

@pytest.mark.parametrize('kind',('repeat','cycle','alternate','random','mix'))
def test_generator_range_and_shape(kind):
    rng=np.random.default_rng(9)
    a=make_tokens(kind,9,SEQLEN,rng)
    assert a.shape==(9,SEQLEN)
    assert np.issubdtype(a.dtype,np.integer)
    assert np.all((a>=0)&(a<VOCAB))

def test_repeated_sequences_exact():
    seq=make_tokens('repeat',32,SEQLEN,np.random.default_rng(33))
    assert np.all(seq==seq[:,0:1])

def test_cycle_sequences_exact():
    seq=make_tokens('cycle',32,SEQLEN,np.random.default_rng(33))
    assert np.all(seq[:,1:]==((seq[:,:-1]+1)%VOCAB))

def test_alternate_sequences_exact():
    seq=make_tokens('alternate',32,SEQLEN,np.random.default_rng(33))
    assert np.all(seq[:,2:]==seq[:,:-2])

def test_delta_zero_exact_reconstruction():
    torch.manual_seed(2)
    m=MiniCausal().eval()
    x=torch.randn(3,7,48)
    r=evaluate_delta(x,m.head,thresholds=(0.,))
    assert r['exact_delta_fraction_nonzero']==1
    assert r['thresholds'][0]['max_relative_logit_l2_error']<1e-12
    assert r['thresholds'][0]['dense_top1_agreement']==1.0

def test_constant_hidden_requires_no_update():
    torch.manual_seed(2)
    m=MiniCausal().eval()
    x=torch.ones(3,7,48)
    r=evaluate_delta(x,m.head,thresholds=(0.,0.05,0.5))
    assert r['exact_delta_fraction_nonzero']==0
    assert all(e['mean_fraction_updated_coordinates']==0 for e in r['thresholds'])
    assert all(e['dense_top1_agreement']==1 for e in r['thresholds'])

def test_bigger_threshold_can_only_reduce_work():
    torch.manual_seed(2)
    m=MiniCausal().eval()
    r=evaluate_delta(torch.randn(4,9,48),m.head)
    fractions=[e['mean_fraction_updated_coordinates'] for e in r['thresholds']]
    assert all(a>=b for a,b in zip(fractions,fractions[1:]))

def test_teacher_forced_prefix_causality():
    torch.manual_seed(99)
    m=MiniCausal().eval()
    s=torch.tensor(make_tokens('random',2,12,np.random.default_rng(1)))
    with torch.no_grad():
        original=m(s)
        s2=s.clone(); s2[:,7:]=(s2[:,7:]+9)%VOCAB
        changed=m(s2)
    assert torch.allclose(original[:,:7],changed[:,:7],atol=1e-5,rtol=1e-5)

def test_untrained_is_not_fake_trained():
    # Baseline model has finite logits but no pretrained weights or checkpoint.
    m=MiniCausal().eval()
    with torch.no_grad():
        x=m(torch.zeros(1,SEQLEN,dtype=torch.long))
    assert x.shape==(1,SEQLEN,VOCAB)
