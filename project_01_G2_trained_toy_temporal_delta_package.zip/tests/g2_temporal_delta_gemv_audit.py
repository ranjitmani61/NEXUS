"""G2 exploratory delta-MVM falsification: public-domain reproducible CPU audit.
This is an existing approach; never use it as evidence of novelty or of LLM efficiency.
Run: OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python tests/g2_temporal_delta_gemv_audit.py
"""
from __future__ import annotations
import json
import os
import platform
import sys
import time
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits, threadpool_info

DENSITIES = [0.0, 0.01, 0.05, 0.20, 0.50, 1.0]
SHAPES = [(2048, 1024), (2048, 2048)]
SEEDS = [13, 37, 71]
STEPS = 24
REPEATS = 3
MAX_REL_ERROR = 5e-5  # Numerical consistency threshold, not model-quality guarantee.
OUTPUT = Path('/mnt/data/results/g2_temporal_delta_gemv_audit.json')


def benchmark_case(W, seed, density, steps=STEPS):
    rng = np.random.default_rng(seed)
    n = W.shape[1]
    k = int(round(n * density))
    x_prev = rng.normal(size=n).astype(np.float32)
    y_prev = W @ x_prev
    bootstrap_ns = 0  # separately timed below for transparency
    dense_ns, delta_ns = [], []
    max_error = 0.0
    nonzero_count = []
    for step in range(steps):
        x_next = x_prev.copy()
        if k:
            pos = rng.choice(n, size=k, replace=False)
            x_next[pos] += (rng.normal(0, 0.06, size=k)).astype(np.float32)
        # Equal input generation, no timing counted for either method.
        # Alternate to minimize ordering confounder; neither is a caching guarantee.
        start = time.perf_counter_ns()
        if step % 2 == 0:
            y_dense = W @ x_next
            mid = time.perf_counter_ns()
            delta = x_next - x_prev
            idx = np.flatnonzero(delta)
            if idx.size:
                y_delta = y_prev + W[:, idx] @ delta[idx]
            else:
                y_delta = y_prev.copy()
            stop = time.perf_counter_ns()
            dense_ns.append(mid-start); delta_ns.append(stop-mid)
        else:
            delta = x_next - x_prev
            idx = np.flatnonzero(delta)
            if idx.size:
                y_delta = y_prev + W[:, idx] @ delta[idx]
            else:
                y_delta = y_prev.copy()
            mid = time.perf_counter_ns()
            y_dense = W @ x_next
            stop = time.perf_counter_ns()
            delta_ns.append(mid-start); dense_ns.append(stop-mid)
        # Note: candidate's output becomes its state (roundoff accumulates).
        rel = np.linalg.norm((y_delta.astype(np.float64)-y_dense.astype(np.float64))) / max(1e-12, np.linalg.norm(y_dense.astype(np.float64)))
        max_error = max(max_error, float(rel))
        assert np.isfinite(rel) and rel <= MAX_REL_ERROR, (rel, density, step)
        nonzero_count.append(int(idx.size))
        y_prev = y_delta
        x_prev = x_next
    return {
        'dense_ns': int(sum(dense_ns)), 'delta_ns': int(sum(delta_ns)),
        'median_dense_ms': float(np.median(dense_ns)/1e6),
        'median_delta_ms': float(np.median(delta_ns)/1e6),
        'ratio_delta_dense': float(sum(delta_ns)/sum(dense_ns)),
        'max_relative_l2_error': max_error,
        'mean_changed_columns': float(np.mean(nonzero_count)),
        'steps': steps,
    }


def main():
    data = {'program': 'g2_temporal_delta_gemv_audit.py', 'date': '2026-11-03',
            'environment': {'python':sys.version.split()[0], 'numpy': np.__version__,
                            'machine':platform.machine(), 'processor': platform.processor(),
                            'threadpool': None},
            'parameters': {'shapes':SHAPES,'densities':DENSITIES,'seeds':SEEDS,
                           'steps':STEPS, 'repeats':REPEATS,'max_error':MAX_REL_ERROR},
            'measurements': [], 'classification':'synthetic CPU BLAS experiment, not pretrained-model or novel processor evidence'}
    with threadpool_limits(limits=1, user_api='blas'):
        data['environment']['threadpool'] = threadpool_info()
        for m, n in SHAPES:
            for seed in SEEDS:
                rng = np.random.default_rng(seed*1337+m+n)
                # Same matrix for all densities to avoid different baseline difficulty.
                W = np.asfortranarray(rng.normal(0, 1/np.sqrt(n), size=(m,n)).astype(np.float32))
                for density in DENSITIES:
                    for repeat in range(REPEATS):
                        # benchmark only per-step operation, initialization measured separately below
                        measurement = benchmark_case(W, seed*1000 + repeat, density)
                        measurement.update({'m':m, 'n':n, 'seed':seed, 'density':density, 'repeat':repeat})
                        data['measurements'].append(measurement)
        # Benchmark bootstrap cost of cached output separately; one per stream.
        measurements = {}
        for m,n in SHAPES:
            r = np.random.default_rng(9001+m+n)
            W = np.asfortranarray(r.normal(size=(m,n)).astype(np.float32))
            x = r.normal(size=n).astype(np.float32)
            times=[]
            for _ in range(40):
                start=time.perf_counter_ns(); _=W@x; times.append(time.perf_counter_ns()-start)
            measurements[f'{m}x{n}']={'bootstrap_median_ms':float(np.median(times)/1e6)}
        data['bootstrap'] = measurements
    summary = []
    for m,n in SHAPES:
        for density in DENSITIES:
            rs=[q for q in data['measurements'] if q['m']==m and q['n']==n and q['density']==density]
            vals=np.array([q['ratio_delta_dense'] for q in rs]); err=max(q['max_relative_l2_error'] for q in rs)
            summary.append({'shape':[m,n], 'density':density, 'ratio_median':float(np.median(vals)),
                            'ratio_min':float(vals.min()), 'ratio_max':float(vals.max()),
                            'max_error':float(err), 'trials':len(rs)})
    data['summary'] = summary
    OUTPUT.parent.mkdir(parents=True,exist_ok=True)
    OUTPUT.write_text(json.dumps(data, indent=2))
    print('completed',len(data['measurements']),'streams,',len(data['measurements'])*STEPS,'steps')
    print('shape,density,ratio_median,ratio_min,ratio_max,max_rel_error')
    for s in summary:
        print(f"{s['shape'][0]}x{s['shape'][1]},{s['density']:.2f},{s['ratio_median']:.3f},{s['ratio_min']:.3f},{s['ratio_max']:.3f},{s['max_error']:.2g}")
    print('saved:',OUTPUT)

if __name__ == '__main__':
    main()
