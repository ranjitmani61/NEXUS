"""Algebraic and numerical negative-control tests for temporal delta GEMV."""
import sys
from pathlib import Path
import numpy as np
import pytest
sys.path.insert(0, str(Path(__file__).parent))
from g2_temporal_delta_gemv_audit import benchmark_case

@pytest.mark.parametrize('m,n',[ (13,9), (64,32)])
@pytest.mark.parametrize('density',[0.0, 0.01, 0.20, 0.5, 1.0])
def test_actual_stream(m, n, density):
    rng=np.random.default_rng(8)
    W=np.asfortranarray(rng.normal(size=(m,n)).astype(np.float32))
    r=benchmark_case(W,seed=7,density=density,steps=30)
    assert r['max_relative_l2_error'] < 5e-5
    assert r['dense_ns'] > 0 and r['delta_ns'] > 0
    assert 0 <= r['mean_changed_columns'] <= n

def test_sparse_identity():
    W=np.array([[2.,3.,4.],[-1.,8.,0.]], dtype=np.float64)
    x0=np.array([7.,9.,-1.])
    x1=np.array([7.,6.,-1.])
    y0=W@x0
    dx=x1-x0
    idx=np.flatnonzero(dx)
    np.testing.assert_array_equal(y0+W[:,idx]@dx[idx], W@x1)


def test_all_zero_identity():
    W=np.eye(7)
    x0=np.arange(7.)
    x1=x0.copy()
    dx=x1-x0
    assert len(np.flatnonzero(dx))==0
    np.testing.assert_array_equal(W@x0,W@x1)
