"""Synthetic *trained* mini-causal-transformer audit of cross-token delta density.

Not a pretrained LLM, not a GPU test, not a new algorithm or processor.
Reproduce:
 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python tests/g2_delta_transformer_activation_audit.py
"""
from __future__ import annotations
import json, time, platform, os
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parents[1]
SEED = int(os.environ.get('G2_SEED', '20261103'))
OUT = ROOT / f'results/g2_trained_toy_delta_activation_seed{SEED}.json'
VOCAB=32; D=48; HEADS=4; BLOCKS=2; SEQLEN=24; TRAIN_STEPS=320; TRAIN_B=64
THRESHOLDS=(0.0, 0.01, 0.05, 0.1, 0.2, 0.4, 0.8)

class Block(nn.Module):
    def __init__(self):
        super().__init__()
        self.ln1=nn.LayerNorm(D)
        self.qkv=nn.Linear(D,D*3, bias=False)
        self.o=nn.Linear(D,D, bias=False)
        self.ln2=nn.LayerNorm(D)
        self.ff=nn.Sequential(nn.Linear(D,D*3),nn.GELU(),nn.Linear(D*3,D))
    def forward(self, x):
        b,t,d=x.shape
        q,k,v=self.qkv(self.ln1(x)).chunk(3,dim=-1)
        def heads(z): return z.view(b,t,HEADS,d//HEADS).transpose(1,2)
        a=F.scaled_dot_product_attention(heads(q), heads(k), heads(v), is_causal=True, dropout_p=0.0)
        x=x+self.o(a.transpose(1,2).reshape(b,t,d))
        return x+self.ff(self.ln2(x))

class MiniCausal(nn.Module):
    def __init__(self):
        super().__init__()
        self.tok=nn.Embedding(VOCAB,D)
        self.pos=nn.Embedding(SEQLEN,D)
        self.blocks=nn.ModuleList([Block() for _ in range(BLOCKS)])
        self.last=nn.LayerNorm(D)
        self.head=nn.Linear(D,VOCAB, bias=True)
    def forward(self, tokens, return_hidden=False):
        x=self.tok(tokens)+self.pos(torch.arange(tokens.shape[1],device=tokens.device))
        for block in self.blocks: x=block(x)
        h=self.last(x)
        z=self.head(h)
        return (z,h) if return_hidden else z

def make_tokens(kind, b, t, rng):
    starts=rng.integers(0,VOCAB,size=(b,1))
    times=np.arange(t)[None,:]
    if kind=='repeat': a=np.broadcast_to(starts,(b,t)).copy()
    elif kind=='cycle': a=(starts+times)%VOCAB
    elif kind=='alternate': a=(starts+(times%2))%VOCAB
    elif kind=='random': a=rng.integers(0,VOCAB,size=(b,t))
    elif kind=='mix':
        a=np.concatenate([make_tokens(k,b//3,t,rng) for k in ('repeat','cycle','alternate')],axis=0)
        if len(a)<b: a=np.concatenate([a,make_tokens('cycle',b-len(a),t,rng)])
        rng.shuffle(a,axis=0)
    else: raise ValueError(kind)
    return a.astype(np.int64)

def evaluate_delta(hidden, head, thresholds=THRESHOLDS):
    """For each sequence, apply updates to cached logit y=W*x+b, then compare to dense.
    Relative output error and argmax disagreement include cumulative error.
    """
    x=hidden.detach().to(torch.float64).numpy()
    W=head.weight.detach().to(torch.float64).numpy()
    b=head.bias.detach().to(torch.float64).numpy()
    logits=x@W.T+b
    B,T,d=x.shape
    delta=x[:,1:,:]-x[:,:-1,:]
    results=[]
    for tau in thresholds:
        cached=logits[:,0,:].copy()
        ratios=[]; errs=[]; arg_agrees=[]
        for t in range(1,T):
            dx=delta[:,t-1,:]
            scale=np.sqrt(np.mean(x[:,t,:]**2,axis=-1,keepdims=True))
            mask=np.abs(dx) > tau*scale
            # W*d where omitted deltas are set to zero (separate vector dense BLAS
            # for numerical checking; NOT a sparse speed-up benchmark).
            dx_selected=np.where(mask,dx,0)
            cached=cached+dx_selected@W.T
            exact=logits[:,t,:]
            err=np.linalg.norm(cached-exact,axis=-1)/np.maximum(1e-12,np.linalg.norm(exact,axis=-1))
            errs.extend(err.tolist())
            ratios.extend(np.mean(mask,axis=1).tolist())
            arg_agrees.extend((cached.argmax(axis=1)==exact.argmax(axis=1)).tolist())
        results.append({'tau_scaled_to_hidden_rms':tau,
            'mean_fraction_updated_coordinates':float(np.mean(ratios)),
            'p95_fraction_updated_coordinates':float(np.percentile(ratios,95)),
            'max_relative_logit_l2_error':float(np.max(errs)),
            'p95_relative_logit_l2_error':float(np.percentile(errs,95)),
            'dense_top1_agreement':float(np.mean(arg_agrees))})
    return {'exact_delta_fraction_nonzero':float(np.mean(delta!=0)),
            'mean_absolute_delta':float(np.mean(np.abs(delta))),
            'relative_delta_l2_median':float(np.median(
                 np.linalg.norm(delta,axis=-1)/np.maximum(1e-12,np.linalg.norm(x[:,1:,:],axis=-1)))),
            'thresholds':results}

def run():
    torch.set_num_threads(1)
    torch.manual_seed(SEED); np.random.seed(SEED)
    rng=np.random.default_rng(SEED)
    model=MiniCausal()
    untrained=MiniCausal()
    untrained.load_state_dict(model.state_dict())
    opt=torch.optim.AdamW(model.parameters(),lr=0.002,weight_decay=0)
    losses=[]; start=time.perf_counter()
    model.train()
    for step in range(TRAIN_STEPS):
        batch=torch.from_numpy(make_tokens('mix',TRAIN_B,SEQLEN+1,rng))
        logits=model(batch[:,:-1]); loss=F.cross_entropy(logits.reshape(-1,VOCAB),batch[:,1:].reshape(-1))
        opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
        if step in (0,39,79,159,239,319): losses.append({'step':step+1,'train_ce_nats':float(loss.detach())})
    train_wall=time.perf_counter()-start
    result={'artifact':'G2 synthetic trained toy transformer delta density audit',
        'limits':'Synthetic next-token task, model initialized and trained in this run, NOT pretrained LLM',
        'configuration':{'seed':SEED,'vocabulary':VOCAB,'hidden_dim':D,'heads':HEADS,'layers':BLOCKS,
            'sequence_length_input':SEQLEN,'train_steps':TRAIN_STEPS,'train_batch':TRAIN_B,
            'thresholds':THRESHOLDS,'framework':'torch '+torch.__version__,
            'cpu':platform.processor(),'torch_threads':torch.get_num_threads()},
        'training':{'duration_seconds':train_wall,'losses':losses},'evaluations':{}}
    for checkpoint,mdl in [('untrained',untrained),('trained_toy',model)]:
        mdl.eval()
        for kind in ('repeat','cycle','alternate','random'):
            generator=np.random.default_rng(SEED+{'repeat':41,'cycle':42,'alternate':43,'random':44}[kind])
            tokens=torch.from_numpy(make_tokens(kind,64,SEQLEN+1,generator))
            with torch.no_grad(): z,h=mdl(tokens[:,:-1],return_hidden=True)
            actual=tokens[:,1:]
            acc=float((z.argmax(-1)==actual).float().mean().item())
            ce=float(F.cross_entropy(z.reshape(-1,VOCAB),actual.reshape(-1)).item())
            audit=evaluate_delta(h,mdl.head)
            audit.update({'baseline_next_token_accuracy':acc,'baseline_ce_nats':ce,
                          'queries':int(h.shape[0]*(h.shape[1]-1))})
            result['evaluations'][checkpoint+'__'+kind]=audit
    # Validate teacher-forced full pass against incremental-prefix autoregressive evaluation.
    with torch.no_grad():
        seq=torch.tensor(make_tokens('cycle',1,SEQLEN,np.random.default_rng(SEED+81)))
        full,_=model(seq,return_hidden=True)
        maxerr=0
        for p in range(1,SEQLEN+1):
            step_out=model(seq[:,:p])[:,-1]
            maxerr=max(maxerr,float(torch.max(torch.abs(step_out-full[:,p-1]))))
    result['causal_prefix_invariant_max_abs_logit_error']=maxerr
    assert maxerr < 1e-4
    # Exact FP64 reconstruction for exact delta threshold, including initial head bias.
    assert all(e['thresholds'][0]['max_relative_logit_l2_error'] < 1e-12 for e in result['evaluations'].values())
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(json.dumps(result,indent=2))
    print('train seconds',round(train_wall,2),'ce',losses)
    for key,v in result['evaluations'].items():
        print(key,'acc',round(v['baseline_next_token_accuracy'],4),'nonzero delta',round(v['exact_delta_fraction_nonzero'],6),
            'median ||delta||/||x||',round(v['relative_delta_l2_median'],3))
        for row in v['thresholds']:
            print(' tau',row['tau_scaled_to_hidden_rms'],'updated',round(row['mean_fraction_updated_coordinates'],3),
                'top1',round(row['dense_top1_agreement'],4),'maxerr',round(row['max_relative_logit_l2_error'],3))
    print('causal prefix max abs error',maxerr,'saved',OUT)
    return result

if __name__=='__main__':run()
