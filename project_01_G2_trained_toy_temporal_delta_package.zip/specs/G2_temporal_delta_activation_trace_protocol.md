# G2 temporal-delta trace falsification protocol v1.0
Date: 2026-11-03. Review lenses: A1 architecture, A2 numerical analysis, A3 AI/ML, A4 software, A6 memory, A8 verification, A10 performance, A11 prior art. No independent human review.

## Objective and falsifiable claim
Earlier NumPy GEMV showed speedups only when roughly 1–20% of input coordinates change. Test the **unmeasured precondition** that consecutive token activations at a fixed projection of a causal language model have low exact or tolerably approximate change density. Fail the original assumption if delta density remains near 100% under small output-error budgets. This is an exploratory proxy experiment **not G5**.

## Model and data
Construct a 2-layer decoder-only transformer in PyTorch, hidden width 48, four attention heads, GELU FFN, LayerNorm, learned token/position embeddings, 32-token vocabulary, 24 input positions. Randomly initialize; train 320 optimizer steps on a mixture of 3 algorithmic patterns (repeat, modulo-32 increment, two-token alternating). Controls: untrained copy with same initial weights; unseen random tokens; evaluation sequences drawn from separate seeds with same simple pattern generators. No external pretrained weights are used; high accuracy on these tiny tasks cannot be extrapolated to pretrained LLMs.

For each condition, 64 sequences × 23 inter-token transitions; compare the 48-dimensional final hidden vectors in the **same linear output head** at consecutive positions. Full-sequence masked evaluation must agree numerically with prefix-by-prefix causal evaluation. The head only is tested, NOT every layer, and no claim is made about whole-system compute savings.

## Candidate and baselines
Dense: `z_t = W h_t + b` for every time step.
Delta recurrence: `z_t_hat = z_(t-1)_hat + W(Δh_t ⊙ mask_t)`, with `Δh_t=h_t-h_(t-1)` and `mask_{t,i} = 1[|Δh_{t,i}| > τ * RMS(h_t)]`.
Use tau={0, .01, .05, .1, .2, .4, .8}; start with exact previous dense output at t=0; carry candidate state across all token steps. FP64 evaluation of **stored FP32 activations and weights** isolates error from thresholding. Real-world preprocessing, delta detection, index gathering and memory-layout costs are not timed here.

Track: fraction of exactly nonzero coordinates, fraction selected, maximum and p95 normalized logit L2 error against recomputed dense head, top-1 agreement against recomputed dense head, full dense next-token accuracy, and prefix causality. **Top-1 agreement is NOT next-token accuracy; the latter requires ground-truth tokens.**

Diagnostic filter (not a G0 commercial acceptance threshold): require maximal normalized logit L2 error ≤2% AND dense-top-1 agreement ≥99.9%. Compute strongest optimistic **head-weight traffic only** upper bound 1/f for fraction f of columns touched, assuming free screening/gathering. It is not a latency or energy result; any skipped-index overhead reduces the achievable advantage.

## Verification and execution
```
cd /mnt/data
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 G2_SEED=20261103 python tests/g2_delta_transformer_activation_audit.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 G2_SEED=20261104 python tests/g2_delta_transformer_activation_audit.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python -m pytest -q tests/test_g2_delta_transformer_activation.py tests/test_g2_temporal_delta_gemv.py
```
Raw JSON and command stdout in `results/`. The current test uses a CPU machine with PyTorch but no reachable pretrained-model checkpoint. No billed compute or hardware test authorized.

## Prior-art and distinction
- Delta Networks (2017): https://proceedings.mlr.press/v70/neil17a.html
- Chipmunk temporal-delta reuse on diffusion models (2025): https://arxiv.org/abs/2506.03275
- On Emergence of Activation Sparsity in Trained Transformers (2023): https://research.google/pubs/on-emergence-of-activation-sparsity-in-trained-transformers/ . This paper studies nonzero FFN post-activation values, NOT necessarily sparse consecutive-token differences.

## Gates
- G1 novelty: FAIL for ordinary delta recurrence; established prior art.
- G2: evaluation of sufficient temporal sparsity under test.
- G3/G4: numerical property verification and synthetic trained model tests are local only.
- G5 pretrained-model evaluation: BLOCKED.
- G6 hardware: NOT AUTHORIZED.
