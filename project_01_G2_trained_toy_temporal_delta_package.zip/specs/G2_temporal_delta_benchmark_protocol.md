# G2 exploratory falsification — temporal-delta matrix-vector execution
**Version:** 1.0, 2026-11-03. **Engineering lenses:** A1/A2/A3/A4/A6/A8/A10/A11. Not independently reviewed.

## Hypothesis and exact mathematical semantics
For fixed `W ∈ R^(m×n)`, successive inputs `x_t`, output `y_t = W x_t`. If `k` coordinates of `Δx = x_t - x_(t-1)` are nonzero, `y_t = y_(t-1) + Σ_{j:Δx_j!=0} W[:,j] Δx_j`. Exact over real arithmetic, not bit-for-bit identical in FP32 after repeated updates.

A lower-traffic path can exist only when changed columns are sparse and the saved output is valid for exactly the same weights and prior input. Major failure cases: dense changes, unsuitable data layout, stale output states, floating-point drift, extra versioning/synchronization, and workloads without recurrently reused `W` in the relevant computation.

## Experiment design (exploratory, not G5)
- CPU-only NumPy 2.3.5, single OpenBLAS thread; `W` held Fortran-contiguous `float32` and 2048×1024 or 2048×2048.
- Synthetic random dense weights and inputs; input changes at precisely chosen coordinate fractions: 0, 1%, 5%, 20%, 50%, 100%; Gaussian perturbations on chosen coordinates. Fixed seeds 13,37,71, 24 steps, 3 repeats per case, two full independent process runs.
- Candidate: detect delta, gather changed weight columns, matrix-vector multiply, add cached output. Dense baseline: **same NumPy/OpenBLAS** `W @ x_t`, with no delta detection, on identical input.
- Per-step comparison includes candidate change detection/gathering and output update. Both exclude synthetic input generation. Candidate's initial `y_0 = W @ x_0` is measured separately as a bootstrap cost and should be charged once per stream; per-step ratio table excludes it. Matrices and outputs are CPU cache influenced, and no GPU comparison is claimed.
- Check normalized `float64` L2 difference between candidate and dense after each step against limit `5e-5` for verification only. This is NOT a model-task quality threshold.
- Metric: median across 9 streams of `Σ candidate_step_ns / Σ dense_step_ns` for each shape/density, across TWO complete runs. Original density set fixed before first execution; no post-hoc tuned density points.

## Running
```bash
cd /mnt/data
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python tests/g2_temporal_delta_gemv_audit.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 pytest -q tests/test_g2_temporal_delta_gemv.py
```
`tests/g2_temporal_delta_gemv_audit.py` emits JSON under `results/` and prints a summary. Two recorded runs and test stdout are archived. The script uses `/mnt/data` as workspace root; adjust OUTPUT constant for other machines.

## What this cannot establish
No representative trained LLM activations, no transformer correctness or task quality, no GPU/FPGA/silicon/power, no device timing/area, no novelty. The incumbent algorithm is explicitly established prior art; tests are an **exploratory CPU calibration**, not grounds for hardware authorization.
