# 2026-11-03 — G2 temporal-delta CPU falsification gate review
**Decision:** G2 algorithm/FP32 feasibility **PASS in tested synthetic setting**; G1 claim of novel mechanism **FAIL** (known delta-network prior art); G5 real pretrained-model data **BLOCKED**; G6 hardware **NOT AUTHORIZED**; G12 breakthrough **NOT DEMONSTRATED**.

**Governing:** `AGENTS.md` read; prior code, latest codec-pivot review and benchmark contract inspected. **Lenses:** A1/A2/A3/A4/A6/A8/A10/A11. No external specialist review.

## Objective
Test known temporal-delta execution as an alternative to rejected attention-screening and lossless-KV-compression invention hypotheses. Sparse update must beat optimized single-thread CPU BLAS on the same synthetic matrix and preserve numerical outputs within a fixed tolerance, including detection, weight-column gather and cached state update.

## Actual experimental evidence
Two process runs, each with **108 distinct streams × 24 successive updates = 2592 query-step comparisons**; total **5184** cross the two runs. Two Fortran-contiguous FP32 matrix shapes; 6 prescribed densities, 3 seeds, 3 repeats. Same dense OpenBLAS baseline, one BLAS thread. Synthetic Gaussian matrix and sparse-delta inputs—not LLM activations. Candidate's initial dense output is **not included** in the ratios; separately measured bootstrap median ~0.26 ms for 2048×1024 and ~0.56 ms for 2048×2048, approximately one additional dense step per stream. Exact reproducibility depends on CPU scheduling, cache state, and BLAS; no energy measurements.

| Matrix | Changed columns | Candidate / dense run 1 | Run 2 | Max normalized L2 mismatch |
|---|---:|---:|---:|---:|
| 2048×1024 | 0% | 0.028 | 0.033 | 0.00e+00 |
| 2048×1024 | 1% | 0.080 | 0.089 | 3.20e-07 |
| 2048×1024 | 5% | 0.169 | 0.164 | 3.38e-07 |
| 2048×1024 | 20% | 0.670 | 0.635 | 3.45e-07 |
| 2048×1024 | 50% | 1.664 | 1.697 | 3.38e-07 |
| 2048×1024 | 100% | 3.183 | 3.211 | 3.43e-07 |
| 2048×2048 | 0% | 0.018 | 0.017 | 0.00e+00 |
| 2048×2048 | 1% | 0.062 | 0.059 | 4.14e-07 |
| 2048×2048 | 5% | 0.163 | 0.164 | 4.62e-07 |
| 2048×2048 | 20% | 0.714 | 0.699 | 4.45e-07 |
| 2048×2048 | 50% | 1.688 | 1.647 | 4.49e-07 |
| 2048×2048 | 100% | 3.152 | 3.120 | 4.57e-07 |

**Verification:** Every measured step was checked against freshly recomputed dense result. Maximum observed normalized L2 mismatch across recorded runs < 4.7×10^-7 (FP32 roundoff, not a theorem). `pytest` **12/12 unit tests pass**. No sanitizers were run (Python/NumPy). Test integrity is limited to measured cases; no formal proof of bounded accumulated FP32 error for unbounded sequence length.

## Assessment of cost and applicability
- When input changes are ~1–5% of coordinates, measured sparse weight-column gathering and cached output updates can beat dense BLAS on these small synthetic CPU tests. At 50% or all coordinates, they lose materially.
- A 20%-to-50% density transition crosses break-even in this machine and implementation, **but it is not a universal sparsity threshold**. A different GPU, model, layout, batch size, and sparse implementation will change it.
- Sparse deltas **must exist in real activation traces** at the same linear layer between decode steps. That precondition was neither measured nor established. In typical full-precision dense vectors, exact zeros in successive differences cannot be assumed. Allowing approximate zeros requires separate task-quality analysis and stability verification.
- Cost excluded: generating model activations, output-state cache initialization in ratio table (see separate cost), model weight loading and memory tier variation, synchronization, cross-layer state coherency, GPU kernels, and integration overhead. Compared to one optimized CPU BLAS baseline, not strongest GPU/MLP/LLM system.
- Existing Delta Networks (ICML 2017), EdgeDRNN (IEEE 2020), and Chipmunk (2025) cover delta-state execution and hardware-aware sparse kernels. See `research/G1_temporal_delta_prior_art.md`; no patent search.

## Gate and next action
Do not pursue this as novel hardware. A possible distinct next technical task is **measure real pretrained transformer activation-change density** and test the exact-update end-to-end quality/performance trade-off. However, checkpoint data is not locally available (download DNS failure on 2026-11-03), so G5 remains blocked. An actual original physical/computational mechanism, not a relabeling, is needed before beginning G6. Prior attention-processor, codec, and delta branches remain research baselines, not inventions.

## Reproduction and artifacts
- `tests/g2_temporal_delta_gemv_audit.py`, `tests/test_g2_temporal_delta_gemv.py`
- `results/g2_temporal_delta_gemv_run{1,2}.json`, corresponding `.txt`, `results/g2_temporal_delta_pytest.txt`
- `specs/G2_temporal_delta_benchmark_protocol.md`, `research/G1_temporal_delta_prior_art.md`
- `AGENTS.md` and previous gate reviews preserved unchanged.
