# G1 prior art: temporal-delta matrix execution (2026-11-03)
**Owner/review lenses:** A1 computer architecture, A2 applied math, A3 AI/ML systems, A4 compiler, A6 memory, A8 verification, A10 performance, A11 prior-art analysis. **No independent specialist or patent review.**

## Mechanism being examined
Cache the previous output `y_(t-1) = W x_(t-1)` for fixed weights `W`. Evaluate only columns changed between successive inputs: `y_t = y_(t-1) + W(x_t - x_(t-1))`. If the input delta has only `k` nonzero coordinates, `k` columns are accessed instead of all `n` columns, subject to memory layout, fixed input/weight assumptions, and state-maintenance overhead. This algebra is well known.

## Verified examples of prior art
1. Daniel Neil, Jun Haeng Lee, Tobi Delbruck, Shih-Chii Liu, **Delta Networks for Optimized Recurrent Network Computation** (ICML 2017). Stateful delta updates in recurrent models; published primary source: https://proceedings.mlr.press/v70/neil17a.html
2. X. Chen et al., **Exploiting Symmetric Temporally Sparse BPTT for Efficient RNN Training** (AAAI 2024). Temporal-sparsity hardware and training analysis: https://ojs.aaai.org/index.php/AAAI/article/view/29020
3. Austin Silveria, Soham V. Govande, Daniel Y. Fu, **Chipmunk: Training-Free Acceleration of Diffusion Transformers with Dynamic Column-Sparse Deltas** (arXiv 2506.03275; 2025), cached activation delta and column-sparse kernels for diffusion transformers: https://arxiv.org/abs/2506.03275
4. EdgeDRNN, **Recurrent Neural Network Accelerator for Edge Inference** (IEEE JETCAS 2020). Hardware acceleration of delta networks: https://ieeexplore.ieee.org/document/9268992

## Novelty decision
These works anticipate the defining delta-computation mechanism. **Do not label it a new architecture or patentably novel.** The present experiment calibrates its viability only, under synthetic inputs and a CPU BLAS baseline. Novelty would require a genuinely distinct, specified mechanism absent from the cited work and other prior art. A complete patents/product survey has NOT been done.
