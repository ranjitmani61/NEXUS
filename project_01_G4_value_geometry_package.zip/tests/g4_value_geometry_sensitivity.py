#!/usr/bin/env python3
"""Synthetic value-concentration sensitivity, NOT pretrained LLM evidence.
Run from /mnt/data: OPENBLAS_NUM_THREADS=1 python tests/g4_value_geometry_sensitivity.py
"""
import json
from pathlib import Path
import numpy as np
from g4_value_geometry_certificate import compare
out=[]
for seed in (7,41,97):
    rng=np.random.default_rng(seed)
    n,d=2048,16
    q=rng.normal(size=d)
    k=rng.normal(size=(n,d))
    base=rng.normal(size=(d,))
    noise=rng.normal(size=(n,d))
    for sigma in (0,0.001,0.003,0.01,0.03,0.1,0.3,1):
        v=np.tile(base,(n,1))+sigma*noise
        r=compare(q,k,v)
        out.append({'seed':seed,'sigma':sigma,'mass_pages':r['mass_pages'],
          'value_pages':r['value_pages'],'ideal_score_value_pages':r['ideal_score_value_pages'],
          'n_pages':r['pages'],'value_traffic_fraction':r['value_bytes']/r['dense_bytes'],
          'output_error':r['value_error'],'certificate':r['value_certificate']})
summary=[]
for sigma in (0,0.001,0.003,0.01,0.03,0.1,0.3,1):
    group=[r for r in out if r['sigma']==sigma]
    summary.append({'sigma':sigma,'median_value_pages':float(np.median([x['value_pages'] for x in group])),
       'min_value_pages':int(min(x['value_pages'] for x in group)),
       'max_value_pages':int(max(x['value_pages'] for x in group)),
       'median_value_traffic_fraction':float(np.median([x['value_traffic_fraction'] for x in group]))})
p=Path('results/g4_value_geometry_sensitivity.json')
p.write_text(json.dumps({'type':'synthetic controlled sensitivity; untrained; modeled bytes',
 'seeds':[7,41,97],'tolerance':0.02,'page_size':32,'n_tokens':2048,'dim':16,
 'rows':out,'summary':summary},indent=2)+'\n')
print(json.dumps(summary,indent=2))
