#!/usr/bin/env python3
"""G4 value-aware error certificate audit. Prototype algorithm, NOT hardware.

Reproduce: cd /mnt/data && OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
 python tests/g4_value_geometry_certificate.py --output results/g4_value_geometry_certificate.json

Value metadata (page mean/radius) is calculated offline from available values in
this mathematical audit; read and build costs are separately modeled. Actual
throughput, memory tier, and end-to-end latency are NOT measured.
"""
from __future__ import annotations
import argparse
import json
import math
import platform
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import g3_g4_autoregressive_trace_audit as old

VERSION='1.1'
DATE='2026-11-03'
PAGE=32
TOL=0.02
DTYPE_BYTES=4


def max_ratio(U, d, Z):
    """max_{0<=u_j<=U_j} sum u_j*d_j / (Z + sum u_j).

    Root of f(t)=sum U_j*max(d_j-t,0)-t*Z. This solves the
    box-relaxation worst-case exactly in real arithmetic.
    """
    if Z <= 0 or not np.isfinite(Z): raise ValueError('Z must be finite positive')
    U=np.asarray(U,dtype=np.float64)
    d=np.asarray(d,dtype=np.float64)
    if len(U)==0: return 0.
    if np.any(U<0) or np.any(d<0) or np.any(~np.isfinite(U)):
        raise ValueError('invalid upper bounds')
    high=float(np.max(d))
    low=0.
    for _ in range(55):
        mid=(high+low)*.5
        if float(np.dot(U,np.maximum(d-mid,0))) > mid*Z:
            low=mid
        else: high=mid
    return float(high)


def values_summaries(pages):
    centers=[]
    radius=[]
    for vals in pages.values:
        a=np.asarray(vals)
        c=a.mean(axis=0)
        centers.append(c)
        radius.append(float(np.linalg.norm(a-c,axis=1).max()))
    return np.asarray(centers), np.asarray(radius)


def value_screen(q,pages,upper,centers,radii,tol=TOL):
    """Output error guaranteed by score-upper and value-ball summaries,
    in exact real arithmetic. float64 implementation audited numerically.
    """
    order=np.argsort(-upper,kind='stable')
    smax=-np.inf
    Z=0.
    N=np.zeros(pages.d)
    remaining=np.array([len(p) for p in pages.keys])
    selected=[]
    vmax=pages.vmax
    for i in order:
        i=int(i)
        key=np.asarray(pages.keys[i])
        val=np.asarray(pages.values[i])
        scores=key@q/math.sqrt(pages.d)
        newmax=max(smax,float(scores.max()))
        factor=0. if smax==-np.inf else math.exp(smax-newmax)
        exps=np.exp(scores-newmax)
        Z=factor*Z+float(exps.sum())
        N=factor*N+exps@val
        smax=newmax
        selected.append(i)
        remaining[i]=0
        if not np.any(remaining):
            cert=0.
        else:
            ids=np.flatnonzero(remaining>0)
            log_u=np.log(remaining[ids])+upper[ids]-smax
            # Non-overflowing in our experimental parameter ranges; explicit guard.
            if float(log_u.max())>700: raise OverflowError('Unstable exp: scale must be redesigned')
            U=np.exp(log_u)
            out=N/Z
            distances=np.linalg.norm(centers[ids]-out,axis=1)+radii[ids]
            cert=max_ratio(U,distances,Z)/vmax
        if cert<=tol: break
    return {'pages':len(selected),'tokens':int(sum(len(pages.keys[j]) for j in selected)),
            'cert':float(cert),'output':N/Z}


def compare(q,k,v,counts=None):
    pages=old.OnlinePages(k.shape[1])
    for a,b in zip(k,v): pages.append(a,b)
    center, radius=values_summaries(pages)
    upper=pages.fresh_upper(q)
    old_result=old.screen(q,pages,upper,tol=TOL)
    new_result=value_screen(q,pages,upper,center,radius)
    dense,scores=pages.dense(q)
    exact_page_max=np.array([float(scores[i*PAGE:i*PAGE+len(p)].max()) for i,p in enumerate(pages.keys)])
    oracle_result=value_screen(q,pages,exact_page_max,center,radius)
    oracle_err=float(np.linalg.norm(oracle_result['output']-dense)/pages.vmax)
    if oracle_err>oracle_result['cert']+1e-10:
        raise AssertionError('Ideal-score value certificate violated')
    new_err=float(np.linalg.norm(new_result['output']-dense)/pages.vmax)
    old_err=float(np.linalg.norm(old_result['result']-dense)/pages.vmax)
    if new_err > new_result['cert']+1e-10:
        raise AssertionError(f'Value certificate violated: error={new_err} cert={new_result["cert"]}')
    if old_err > old_result['certificate']+1e-10:
        raise AssertionError('Existing mass certificate violated')
    if new_err>TOL+1e-10 or old_err>TOL+1e-10:
        raise AssertionError('tolerance exceeded')
    dim=k.shape[1]
    pages_n=pages.num_pages
    dense_bytes=len(k)*2*dim*DTYPE_BYTES
    key_meta=pages_n*(dim+1)*DTYPE_BYTES
    value_meta=pages_n*(dim+1)*DTYPE_BYTES
    # Keys and values fetched together. Metadata is read in entirety per query.
    return {
       'tokens':len(k),'dim':dim,'pages':pages_n,
       'dense_bytes':dense_bytes,
       'mass_pages':int(old_result['selected_pages']),
       'value_pages':int(new_result['pages']),
       'ideal_score_value_pages':int(oracle_result['pages']),
       'mass_bytes':int(old_result['selected_tokens']*2*dim*DTYPE_BYTES+key_meta),
       'value_bytes':int(new_result['tokens']*2*dim*DTYPE_BYTES+key_meta+value_meta),
       'mass_error':old_err,'value_error':new_err,
       'mass_certificate':float(old_result['certificate']),
       'value_certificate':new_result['cert']
    }


def property_checks():
    """Independent small random cases + brute-force objective tests."""
    rng=np.random.default_rng(92174)
    bound_tests=0
    cert_tests=0
    for t in range(1600):
        n=int(rng.integers(1,7))
        U=rng.uniform(0.001,3,size=n)
        d=rng.uniform(0,4,size=n)
        Z=float(rng.uniform(.01,5))
        opt=max_ratio(U,d,Z)
        # Exact extreme-point enumeration: linear-fractional function maximum at a corner.
        brute=0.
        for bits in range(2**n):
            x=np.array([U[i] if (bits>>i)&1 else 0 for i in range(n)])
            brute=max(brute,float(x@d/(Z+x.sum())))
        if abs(opt-brute)>1e-10: raise AssertionError((t,opt,brute))
        bound_tests+=1
    for t in range(480):
        tokens=int(rng.integers(40,131))
        dim=8
        q=rng.normal(size=dim)
        k=rng.normal(size=(tokens,dim))
        v=rng.normal(size=(tokens,dim))
        if t%3==0: v[:]=rng.normal(size=dim)+rng.normal(size=(tokens,dim))*.001
        compare(q,k,v)
        cert_tests+=1
    return {'fractional_optimization_extreme_point_checks':bound_tests,
            'random_attention_certificate_checks':cert_tests,
            'violations_detected':0}


def constructed_controls():
    rng=np.random.default_rng(18471)
    cases={}
    N=4096; D=16
    q=rng.normal(size=D)
    k=rng.normal(size=(N,D))
    baseline=rng.normal(size=D)
    for name,v in (
      ('identical_values',np.tile(baseline,(N,1))),
      ('near_identical_values',np.tile(baseline,(N,1)) + .002*rng.normal(size=(N,D))),
      ('independent_random_values',rng.normal(size=(N,D))),
      ('pagewise_values',np.repeat(rng.normal(size=(N//PAGE,D)),PAGE,axis=0)+.02*rng.normal(size=(N,D))),
    ):
        result=compare(q,k,v)
        cases[name]=result
    return cases


def untrained_traces():
    old.N=512
    old.DECODE=20
    rows=[]
    for seed in (20261103,20261123):
        embeddings,weights=old.make_weights(seed)
        for regime in old.REGIMES:
            traces=old.generate_traces(old.tokens_for(regime,seed,n=old.N),embeddings,weights)
            for layer,(q_all,k_all,v_all) in enumerate(traces):
                for head in (0,2):
                    for t in range(old.N-old.DECODE,old.N):
                        r=compare(q_all[t,head],k_all[:t+1,head],v_all[:t+1,head])
                        r.update({'seed':seed,'regime':regime,'layer':layer,'head':head,'t':t})
                        rows.append(r)
    return rows


def aggregate(rows):
    def med(k):return float(np.median([r[k] for r in rows]))
    return {
        'queries':len(rows),
        'median_mass_page_fraction':float(np.median([r['mass_pages']/r['pages'] for r in rows])),
        'median_value_page_fraction':float(np.median([r['value_pages']/r['pages'] for r in rows])),
        'median_ideal_score_value_page_fraction':float(np.median([r['ideal_score_value_pages']/r['pages'] for r in rows])),
        'median_mass_traffic_fraction':float(np.median([r['mass_bytes']/r['dense_bytes'] for r in rows])),
        'median_value_traffic_fraction':float(np.median([r['value_bytes']/r['dense_bytes'] for r in rows])),
        'fraction_value_fewer_pages':float(np.mean([r['value_pages']<r['mass_pages'] for r in rows])),
        'fraction_ideal_value_fewer_pages_than_dense':float(np.mean([r['ideal_score_value_pages']<r['pages'] for r in rows])),
        'fraction_value_fewer_bytes':float(np.mean([r['value_bytes']<r['mass_bytes'] for r in rows])),
        'worst_value_error':float(max(r['value_error'] for r in rows)),
        'worst_value_certificate':float(max(r['value_certificate'] for r in rows)),
        'average_extra_metadata_bytes_per_query':float(np.mean([r['pages']*(r['dim']+1)*DTYPE_BYTES for r in rows])),
        'build_cost_lower_bound_one_time_bytes_per_trace':(512*16*4),
        'pretrained':False,
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',default='results/g4_value_geometry_certificate.json')
    args=ap.parse_args()
    properties=property_checks()
    constructed=constructed_controls()
    rows=untrained_traces()
    result={
      'metadata':{'version':VERSION,'date':DATE,'gate':'G3/G4 value-aware exploratory',
                  'model':'UNTRAINED random-weight two-layer RoPE transformer',
                  'numeric_precision':'float64 calculation, float32 bytes traffic PROXY; NO finite precision proof',
                  'warnings':['constructed controls are NOT realistic model traces',
                              'no real pretrained model, GPU, latency, power or quality measurements',
                              'metadata build read/write and key/index operating costs excluded from per-query fractions',
                              'ideal-score value bound first reads every score and is an infeasible diagnostic, not a speedup',
                              'no inference or originality claim; no software-hardware speedup measured']},
      'properties':properties,'constructed':constructed,'aggregate':aggregate(rows),'rows':rows}
    p=Path(args.output)
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(result,indent=2)+'\n')
    print('output:',p,'rows:',len(rows))
    print('properties:',properties)
    print('constructed:',json.dumps({k:{'mass_pages':v['mass_pages'],'value_pages':v['value_pages'],
                            'mass_pct':round(100*v['mass_bytes']/v['dense_bytes'],2),
                            'value_pct':round(100*v['value_bytes']/v['dense_bytes'],2)}
                                  for k,v in constructed.items()},indent=2))
    print('aggregate:',json.dumps(result['aggregate'],indent=2))

if __name__=='__main__':main()
