#!/usr/bin/env python3
"""Matched-update local CPU timing for immutable full-copy vs page-granular COW.

Reports only reference-Python update latency; not pretrained LLM or hardware inference.
"""
from __future__ import annotations
import argparse
import json
import os
import platform
from pathlib import Path
import statistics
import time
import numpy as np
from g3_snapshot_consistency_audit import FrozenSnapshot, build_meta
from g3_transactional_kv import TransactionalKV, dense_stream


def percentiles(x):
    return {'median_ms':float(np.median(x)), 'p95_ms':float(np.percentile(x,95)),
            'min_ms':float(np.min(x)),'max_ms':float(np.max(x))}


def bench(*, pages: int, steps: int, page_size: int=16, dim: int=64, vd: int=16, seed: int=2244):
    rng=np.random.default_rng(seed+pages)
    K=rng.normal(size=(pages*page_size,dim)).astype('float16')
    V=rng.normal(size=(pages*page_size,vd)).astype('float64')
    newk=rng.normal(size=(steps,page_size,dim)).astype('float16')
    newv=rng.normal(size=(steps,page_size,vd)).astype('float64')
    old=FrozenSnapshot.from_data(K,V,page_size); oldmeta=build_meta(old)
    new=TransactionalKV(K,V,page_size)
    q=rng.normal(size=dim).astype('float16')
    old_t=[];new_t=[]
    for j in range(steps):
        index=j%pages
        # Matched functional updates, each including summary maintenance.
        t=time.perf_counter_ns()
        old=old.replace_page(index,newk[j],newv[j]);oldmeta=build_meta(old)
        old_t.append((time.perf_counter_ns()-t)/1e6)
        current=new.capture()
        t=time.perf_counter_ns()
        updated=new.commit(current,replacements={index:(newk[j],newv[j])})
        new_t.append((time.perf_counter_ns()-t)/1e6)
        assert updated.pages[index].K.dtype==old.K.dtype
    # Exact final stored-K/V equality, metadata extrema, and stable dense output.
    for idx,p in enumerate(updated.pages):
        sl=slice(idx*page_size,(idx+1)*page_size)
        assert np.array_equal(p.K,old.K[sl]) and np.array_equal(p.V,old.V[sl])
        assert np.array_equal(p.lo,oldmeta.lo[idx]) and np.array_equal(p.hi,oldmeta.hi[idx])
    final_oldK=old.K.astype('float64')
    sc=final_oldK@q.astype('float64')/np.sqrt(dim)
    w=np.exp(sc-sc.max());w/=w.sum()
    ref=w@old.V
    out=dense_stream(updated,q)
    assert np.allclose(ref,out,rtol=1e-11,atol=1e-11)
    # Per-update data payload and the pointer table estimate, not resident memory.
    page_payload=int(page_size*(K.itemsize*dim + V.itemsize*vd))
    full_payload=int(K.nbytes+V.nbytes)
    out={'pages':pages,'page_size':page_size,'dimension':dim,'value_dimension':vd,
         'steps':steps,'baseline_full_copy':percentiles(old_t),
         'candidate_page_cow':percentiles(new_t),
         'median_update_speed_ratio':float(np.median(old_t)/np.median(new_t)),
         'baseline_whole_cache_payload_bytes':full_payload,
         'candidate_changed_page_payload_bytes':page_payload,
         'candidate_pointer_table_bytes_approx':int(pages*8),
         'reference_output_agreement':True,
         'note':'full copy baseline replicates prior G3 snapshot, not a strongest possible optimized updater'}
    return out


def main():
    a=argparse.ArgumentParser();a.add_argument('--output',default='results/g3_transactional_kv_benchmark.json')
    a.add_argument('--steps',type=int,default=50);a.add_argument('--pages',type=int,nargs='+',default=[32,128,512]);args=a.parse_args()
    results=[bench(pages=p,steps=args.steps) for p in args.pages]
    report={'date':'2026-11-03','version':'1.0','gate':'G3 IN PROGRESS / G4 REFERENCE PERFORMANCE ONLY',
            'platform':platform.platform(),'python':platform.python_version(),'numpy':np.__version__,
            'openblas_threads':os.getenv('OPENBLAS_NUM_THREADS',''),
            'measurement':'time.perf_counter_ns local CPU, alternating two Python implementations; includes metadata maintenance; excludes query latency',
            'results':results}
    p=Path(args.output);p.parent.mkdir(exist_ok=True,parents=True)
    p.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
