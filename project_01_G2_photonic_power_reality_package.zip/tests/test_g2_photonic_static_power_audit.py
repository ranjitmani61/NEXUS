import math
import pytest
from g2_photonic_static_power_audit import (
    energy_nj_per_operation, break_even_digital_energy_nj,
    required_rate, global_risk_budget, run_audit)


def test_energy_units():
    assert energy_nj_per_operation(.320,1e6)==pytest.approx(320.)
    assert energy_nj_per_operation(.320,1e8)==pytest.approx(3.2)
    assert energy_nj_per_operation(1.112,1e8)==pytest.approx(11.12)


def test_break_even_solved_directly():
    e=break_even_digital_energy_nj(power_w=.320,rate=1e8,
       dynamic_energy_nj=10.667009751096947,admission_rate=.35547)
    assert e==pytest.approx((3.2+10.667009751096947)/.35547)
    # At the threshold, hybrid including full fallback equals baseline exactly.
    hybrid=3.2+10.667009751096947+(1-.35547)*e
    assert hybrid==pytest.approx(e)


def test_impossible_if_dynamic_cost_dominates():
    assert required_rate(power_w=.320,digital_energy_nj=30,
        dynamic_energy_nj=10.667009751096947,admission_rate=.35547) is None


def test_possible_when_digital_energy_large_enough():
    r=required_rate(power_w=.320,digital_energy_nj=100,
        dynamic_energy_nj=10.667009751096947,admission_rate=.35547)
    assert 12e6 < r < 14e6
    above=r*1.01
    e=break_even_digital_energy_nj(power_w=.320,rate=above,
        dynamic_energy_nj=10.667009751096947,admission_rate=.35547)
    assert e < 100
    below=r*.99
    e2=break_even_digital_energy_nj(power_w=.320,rate=below,
        dynamic_energy_nj=10.667009751096947,admission_rate=.35547)
    assert e2 > 100


def test_zero_acceptance():
    assert break_even_digital_energy_nj(power_w=0.,rate=1e8,dynamic_energy_nj=1.,admission_rate=0.) is None


def test_zero_static_power():
    assert required_rate(power_w=0.,digital_energy_nj=100.,dynamic_energy_nj=10.,admission_rate=.5)==0.

@pytest.mark.parametrize('v',[-1.0,math.inf,math.nan])
def test_invalid_power(v):
    with pytest.raises(ValueError): energy_nj_per_operation(v,1e6)

@pytest.mark.parametrize('v',[0,-1,math.inf,math.nan])
def test_invalid_rate(v):
    with pytest.raises(ValueError): energy_nj_per_operation(.3,v)

@pytest.mark.parametrize('v',[-.1,1.1,math.nan])
def test_invalid_acceptance(v):
    with pytest.raises(ValueError): break_even_digital_energy_nj(
        power_w=.3,rate=1e8,dynamic_energy_nj=1.,admission_rate=v)


def test_global_risk_allocation():
    r=global_risk_budget(cycles=1_000_000,global_failure_budget=.001)
    assert r['required_per_cycle_union_bound']==pytest.approx(1e-9)
    assert r['required_each_data_channel_tail_noncoverage']==pytest.approx(1e-9/1024)
    assert r['old_union_bound_across_cycles']==1.


def test_risk_invalid():
    for bad in (0,-1,1.2):
        with pytest.raises(ValueError): global_risk_budget(cycles=1_000_000,global_failure_budget=bad)
    with pytest.raises(ValueError): global_risk_budget(cycles=0,global_failure_budget=.001)


def test_complete_sweep_and_sources():
    obj=run_audit()
    assert len(obj['scenarios'])==2*5
    assert len(obj['required_rates'])==2*4
    assert len(obj['global_risk'])==4
    assert all('url' in s for s in obj['power_anchors'].values())
    assert all(x['digital_break_even_energy_nj']>0 for x in obj['scenarios'])
