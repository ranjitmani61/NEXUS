"""Project 01: conditional static-power and global-risk audit for optical reductions.

No new photonic hardware is measured. Published device powers are heterogeneous
and serve ONLY as illustrative stress anchors, not implementation specifications.

Run: python tests/g2_photonic_static_power_audit.py --output results/g2_photonic_static_power_audit.json
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path

AUDIT_VERSION = '1.0'
SOURCE_ARCHIVE = 'project_01_G2_photonic_drift_energy_package.zip'
# Verified previously simulated scenario: K=256, kappa=1, rho=1e-4/readout.
# These are observed SIMULATION aggregates, never physical device measurements.
ADMISSION = 0.35547
DYNAMIC_ENERGY_NJ = 10.667009751096947

# Literature power values belong to DIFFERENT devices and workloads; neither
# is a verified power floor for the proposed optical reduction.
PUBLISHED_POWER_ANCHORS = {
    'heater_reference_16tap_2026': {
        'watt': 0.320,
        'basis': 'authors estimate 16 heaters x 20 mW average; excludes full laser/receiver/etc',
        'url': 'https://www.nature.com/articles/s41377-025-02093-5',
    },
    'laser_tuners_reference_2025': {
        'watt': 1.112,
        'basis': 'reported 300 mW laser + 812 mW worst-case phase shifters; NOT our device',
        'url': 'https://www.nature.com/articles/s41467-025-60100-0',
    },
}

def finite_nonnegative(value: float, *, name: str) -> None:
    if not math.isfinite(value) or value < 0:
        raise ValueError(f'{name} must be finite and nonnegative')


def energy_nj_per_operation(power_w: float, operations_per_second: float) -> float:
    finite_nonnegative(power_w, name='power_w')
    if not math.isfinite(operations_per_second) or operations_per_second <= 0:
        raise ValueError('operations_per_second must be finite and positive')
    # 1 W = 1 J/s; at R operations/s => P/R J/op = P*1e9/R nJ/op.
    return power_w * 1e9 / operations_per_second


def break_even_digital_energy_nj(*, power_w: float, rate: float,
                                 dynamic_energy_nj: float, admission_rate: float) -> float | None:
    """Digital energy above which idealized optical+digital-fallback energy wins.

    Ehybrid = P/R + Edynamic + (1-a)*Edigital
    Edigital > (P/R + Edynamic)/a. Return None if a==0 (no benefit).
    """
    finite_nonnegative(dynamic_energy_nj, name='dynamic_energy_nj')
    if not math.isfinite(admission_rate) or not 0 <= admission_rate <= 1:
        raise ValueError('admission_rate outside [0,1]')
    overhead = energy_nj_per_operation(power_w, rate) + dynamic_energy_nj
    return overhead / admission_rate if admission_rate else None


def required_rate(*, power_w: float, digital_energy_nj: float,
                  dynamic_energy_nj: float, admission_rate: float) -> float | None:
    """Minimum sustained R for hybrid energy < digital energy; strict > needed.

    None means there is no finite break-even rate for positive static power.
    0.0 means all rates pass only when P=0 and a*Ed>E_dynamic.
    """
    finite_nonnegative(power_w, name='power_w')
    finite_nonnegative(digital_energy_nj, name='digital_energy_nj')
    finite_nonnegative(dynamic_energy_nj, name='dynamic_energy_nj')
    if not math.isfinite(admission_rate) or not 0 <= admission_rate <= 1:
        raise ValueError('invalid admission_rate')
    surplus_j = (admission_rate * digital_energy_nj - dynamic_energy_nj) * 1e-9
    if surplus_j <= 0:
        return None
    return power_w / surplus_j


def global_risk_budget(*, cycles: int, global_failure_budget: float,
                       readouts_per_cycle: int = 256) -> dict:
    if isinstance(cycles, bool) or not isinstance(cycles, int) or cycles < 1:
        raise ValueError('cycles must be a positive integer')
    if isinstance(readouts_per_cycle, bool) or not isinstance(readouts_per_cycle, int) or readouts_per_cycle < 1:
        raise ValueError('readouts_per_cycle must be a positive integer')
    if not math.isfinite(global_failure_budget) or not 0 < global_failure_budget < 1:
        raise ValueError('global_failure_budget must lie strictly between zero and one')
    per_cycle = global_failure_budget / cycles
    return {
        'cycles': cycles,
        'global_failure_budget': global_failure_budget,
        'required_per_cycle_union_bound': per_cycle,
        'required_each_data_channel_tail_noncoverage': per_cycle/(4*readouts_per_cycle),
        'old_per_cycle_budget': 0.001,
        'old_union_bound_across_cycles': min(1.0, 0.001*cycles),
        'explanation': 'Sufficient Bonferroni allocation, NOT a bound on hardware behavior under unmodeled drift.'
    }


def run_audit() -> dict:
    rates = [10**6, 10**7, 10**8, 10**9, 10**10]
    digital_candidates_nj = [10.0, 30.0, 100.0, 1000.0]
    scenarios = []
    for name, anchor in PUBLISHED_POWER_ANCHORS.items():
        watts = anchor['watt']
        for r in rates:
            scenarios.append({
                'anchor': name,
                'readouts_per_second_hypothetical': r,
                'static_energy_nj_per_readout': energy_nj_per_operation(watts, r),
                'assumed_dynamic_energy_nj_per_readout': DYNAMIC_ENERGY_NJ,
                'simulated_admission_fraction': ADMISSION,
                'digital_break_even_energy_nj': break_even_digital_energy_nj(
                    power_w=watts, rate=r, dynamic_energy_nj=DYNAMIC_ENERGY_NJ,
                    admission_rate=ADMISSION),
            })
    thresholds = []
    for name, anchor in PUBLISHED_POWER_ANCHORS.items():
        for ed in digital_candidates_nj:
            thresholds.append({
                'anchor': name,
                'hypothetical_matched_digital_nj': ed,
                'required_sustained_readouts_per_second': required_rate(
                    power_w=anchor['watt'], digital_energy_nj=ed,
                    dynamic_energy_nj=DYNAMIC_ENERGY_NJ, admission_rate=ADMISSION),
            })
    risk = [global_risk_budget(cycles=cycles,global_failure_budget=1e-3)
            for cycles in (1, 1000, 1000000, 1000000000)]
    return {
        'experiment': 'Analytical stress test of previous simulated photonic readout under published but non-matching device power anchors',
        'date': '2026-11-04', 'version': AUDIT_VERSION,
        'result_type': 'Derived conditional values; no measured processor or new physical power data',
        'source_archive': SOURCE_ARCHIVE,
        'source_simulated_case': {'K':256, 'kappa':1, 'rho_per_readout':1e-4,
                                  'admission_fraction':ADMISSION, 'assumed_dynamic_energy_nj':DYNAMIC_ENERGY_NJ},
        'power_anchors': PUBLISHED_POWER_ANCHORS,
        'rates': rates, 'scenarios': scenarios,
        'hypothetical_digital_energy_candidates_nj': digital_candidates_nj,
        'required_rates': thresholds, 'global_risk': risk,
        'assumptions': [
            'Constant P (watts) whenever active; all overhead fully charged to readouts at assumed sustained rate',
            'Power anchors from distinct published devices; do NOT describe our reduction primitive',
            'Reported 320 mW heater estimate and 1.112 W worst-case estimate are not full matched measured system power',
            'Optical dynamic energy reuses an unverified idealized model including an arbitrary electronics cost',
            'Simulated admission remains fixed with throughput and physical implementation, although reality could differ',
            'Failed admissions pay a full digital fallback; excluded extra delay and duplicated input setup',
            'No measured digital energy baseline, calibration time in seconds, duty-cycle/power gating, accuracy or real workload',
            'A per-cycle union-bound risk is not a full-service reliability guarantee; assumed drift support can fail',
        ],
        'gate_decision': 'G2 physical energy NOT VERIFIED, G1 generic novelty not established, G5 BLOCKED, G6 NOT AUTHORIZED'
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='results/g2_photonic_static_power_audit.json')
    args=parser.parse_args()
    result=run_audit()
    out=Path(args.output)
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,indent=2)+'\n')
    for name, anchor in PUBLISHED_POWER_ANCHORS.items():
        print(f'{name}: P={anchor["watt"]} W')
        for ed in [30,100,1000]:
            r=required_rate(power_w=anchor['watt'],digital_energy_nj=ed,
                            dynamic_energy_nj=DYNAMIC_ENERGY_NJ,admission_rate=ADMISSION)
            print(f'  digital={ed} nJ -> R required > {r if r is not None else "NO FINITE RATE"} per second')
    print('G2 physical-device feasibility NOT VERIFIED; G6 hardware NOT AUTHORIZED')

if __name__ == '__main__':
    main()
