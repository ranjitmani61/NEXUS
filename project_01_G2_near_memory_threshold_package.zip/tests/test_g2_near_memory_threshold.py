"""Unit/property tests for a NON-PHYSICAL analytical sensitivity calculation."""
from dataclasses import replace
import math
import pytest
from g2_near_memory_threshold import Parameters, traffic_and_time, experiments


def test_baseline_kv_bytes():
    p = Parameters()
    assert traffic_and_time(p)['kv_GB_decimal'] == pytest.approx(1.073741824)


def test_weight_bytes():
    assert traffic_and_time(Parameters())['weights_GB_decimal'] == 16.0


def test_reference_arithmetic():
    p = Parameters()
    r = traffic_and_time(p)
    assert r['host_roofline_ms'] == pytest.approx((16e9+1.073741824e9)/3.35e12*1e3)
    assert r['pim_internal_read_ms'] == pytest.approx(2.0)
    assert r['pim_matmul_ms'] == pytest.approx(1.6)
    assert r['pim_launch_ms'] == pytest.approx(.16)


def test_increasing_compute_does_not_make_pim_slower():
    p=Parameters()
    fast=traffic_and_time(replace(p, near_memory_compute_Fps=30e12))
    slow=traffic_and_time(replace(p, near_memory_compute_Fps=1e12))
    assert fast['pim_model_ms'] <= slow['pim_model_ms']


def test_increasing_internal_bandwidth_does_not_make_pim_slower():
    p=Parameters()
    assert traffic_and_time(replace(p, internal_bandwidth_Bps=16e12))['pim_model_ms'] <= traffic_and_time(replace(p, internal_bandwidth_Bps=1e12))['pim_model_ms']


def test_increasing_launch_cannot_help():
    p=Parameters()
    assert traffic_and_time(replace(p, launch_us_per_layer=100))['pim_model_ms'] > traffic_and_time(replace(p, launch_us_per_layer=5))['pim_model_ms']


def test_launch_breakeven_sanity():
    p=Parameters()
    t=traffic_and_time(p)['launch_breakeven_us_per_layer']
    assert t>0
    equal=traffic_and_time(replace(p,launch_us_per_layer=t))
    assert equal['pim_model_ms'] == pytest.approx(equal['host_roofline_ms'], rel=1e-12)
    assert traffic_and_time(replace(p,launch_us_per_layer=t+1))['modeled_win'] is False
    assert traffic_and_time(replace(p,launch_us_per_layer=max(0,t-1)))['modeled_win'] is True


def test_low_internal_bandwidth_cannot_win():
    p=Parameters()
    assert not traffic_and_time(replace(p,internal_bandwidth_Bps=1e12))['modeled_win']


def test_batch32_compute_slowdown():
    r=traffic_and_time(replace(Parameters(),batch_size=32))
    assert r['pim_matmul_ms'] == pytest.approx(51.2)
    assert not r['modeled_win']


def test_no_zero_context():
    with pytest.raises(ValueError):
        traffic_and_time(replace(Parameters(),context_tokens=0))


def test_no_nan():
    with pytest.raises(ValueError):
        traffic_and_time(replace(Parameters(),near_memory_compute_Fps=float('nan')))


def test_negative_launch_rejected():
    with pytest.raises(ValueError):
        traffic_and_time(replace(Parameters(),launch_us_per_layer=-1))


def test_invalid_bandwidth():
    with pytest.raises(ValueError):
        traffic_and_time(replace(Parameters(),host_bandwidth_Bps=0))


def test_more_banks_communication_cost():
    p=Parameters()
    a=traffic_and_time(p)
    b=traffic_and_time(replace(p,fanout_banks=1024))
    assert b['pim_communication_ms'] > a['pim_communication_ms']
    assert b['pim_model_ms'] > a['pim_model_ms']


def test_all_grid_values_finite():
    r=experiments()
    assert len(r['grid_80_cases']) == 4*5*4
    assert all(math.isfinite(x['ratio']) and x['ratio']>0 for x in r['grid_80_cases'])


def test_no_pim_compute_assumption_cannot_fake_speedup():
    p=Parameters()
    slow=traffic_and_time(replace(p,near_memory_compute_Fps=0.5e12))
    assert slow['pim_model_ms'] > slow['host_roofline_ms']


def test_batch1_activation_comm_is_not_zero():
    assert traffic_and_time(Parameters())['pim_communication_ms'] > 0


def test_internal_BW_1TB_slower_than_8TB():
    p=Parameters()
    a=traffic_and_time(replace(p,internal_bandwidth_Bps=1e12))
    b=traffic_and_time(replace(p,internal_bandwidth_Bps=8e12))
    assert a['pim_model_ms'] > b['pim_model_ms']
