"""G2 analytical threshold test for a hypothetical near-memory decoder datapath.

NOT a physical simulator, chip measurement, performance forecast, or novelty proof.
Run: python tests/g2_near_memory_threshold.py
     python -m pytest -q tests/test_g2_near_memory_threshold.py
No external dependencies.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, replace
import json
import math
import platform
from pathlib import Path


@dataclass(frozen=True)
class Parameters:
    parameters: int = 8_000_000_000
    weight_bytes_per_parameter: int = 2
    layers: int = 32
    kv_heads: int = 8
    head_dim: int = 128
    context_tokens: int = 8192
    batch_size: int = 1
    hidden_size: int = 4096
    activation_bytes: int = 2
    fanout_banks: int = 64
    host_bandwidth_Bps: float = 3.35e12
    host_compute_Fps: float = 989e12
    internal_bandwidth_Bps: float = 8e12
    near_memory_compute_Fps: float = 10e12
    launch_us_per_layer: float = 5.0
    # Each output vector is returned once per layer. Real implementations may require
    # more collective traffic, not modeled here.

    def validate(self) -> None:
        for name in ('parameters', 'weight_bytes_per_parameter', 'layers', 'kv_heads',
                     'head_dim', 'context_tokens', 'batch_size', 'hidden_size',
                     'activation_bytes', 'fanout_banks'):
            if not isinstance(getattr(self, name), int) or getattr(self, name) <= 0:
                raise ValueError(f'{name} must be a positive integer')
        for name in ('host_bandwidth_Bps', 'host_compute_Fps',
                     'internal_bandwidth_Bps', 'near_memory_compute_Fps'):
            v = getattr(self, name)
            if not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0:
                raise ValueError(f'{name} must be positive and finite')
        if not math.isfinite(self.launch_us_per_layer) or self.launch_us_per_layer < 0:
            raise ValueError('launch must be nonnegative and finite')


def traffic_and_time(p: Parameters) -> dict:
    p.validate()
    # Both key and value; one read per decode step and per live sequence, assuming
    # non-compressed full-cache attention. Both variants are charged the same KV read.
    wbytes = p.parameters * p.weight_bytes_per_parameter
    kvbytes = (p.batch_size * p.context_tokens * p.layers * 2
               * p.kv_heads * p.head_dim * p.activation_bytes)
    flops = 2 * p.parameters * p.batch_size
    # This is an optimistic GPU roofline bound, *not* a measured real baseline.
    host_memory_s = (wbytes + kvbytes) / p.host_bandwidth_Bps
    host_compute_s = flops / p.host_compute_Fps
    host_roofline_s = max(host_memory_s, host_compute_s)
    # Weight memory is read internally; PIM processing is limited by internal
    # bandwidth OR aggregate near-memory compute throughput.
    pim_weight_read_s = wbytes / p.internal_bandwidth_Bps
    pim_compute_s = flops / p.near_memory_compute_Fps
    pim_weight_stage_s = max(pim_weight_read_s, pim_compute_s)
    pim_kv_s = kvbytes / p.host_bandwidth_Bps
    activation_bytes = (p.layers * p.batch_size * p.hidden_size
                        * p.activation_bytes * (p.fanout_banks + 1))
    pim_communication_s = activation_bytes / p.host_bandwidth_Bps
    pim_launch_s = p.layers * p.launch_us_per_layer * 1e-6
    # Sequential additive model: no overlap between modeled stages, excludes
    # nontrivial operations (softmax/normalization/routing) equally from both.
    pim_model_s = (pim_weight_stage_s + pim_kv_s + pim_communication_s
                   + pim_launch_s)
    # If threshold <= 0, even zero launch overhead cannot win under this model.
    launch_margin_us_per_layer = ((host_roofline_s - pim_weight_stage_s
                                   - pim_kv_s - pim_communication_s)
                                  / p.layers * 1e6)
    return {
        'parameters': asdict(p),
        'weights_GB_decimal': wbytes / 1e9,
        'kv_GB_decimal': kvbytes / 1e9,
        'activation_communication_MB_decimal': activation_bytes / 1e6,
        'total_matmul_GFLOPs': flops / 1e9,
        'host_roofline_ms': host_roofline_s * 1000,
        'host_weight_plus_kv_ms': host_memory_s * 1000,
        'host_matmul_ms': host_compute_s * 1000,
        'pim_internal_read_ms': pim_weight_read_s * 1000,
        'pim_matmul_ms': pim_compute_s * 1000,
        'pim_kv_ms': pim_kv_s * 1000,
        'pim_communication_ms': pim_communication_s * 1000,
        'pim_launch_ms': pim_launch_s * 1000,
        'pim_model_ms': pim_model_s * 1000,
        'modeled_ratio_host_over_pim': host_roofline_s / pim_model_s,
        'launch_breakeven_us_per_layer': launch_margin_us_per_layer,
        'modeled_win': pim_model_s < host_roofline_s,
    }


def experiments() -> dict:
    p = Parameters()
    cases = {
        'reference_assumptions': p,
        'low_pim_compute_1_TFps': replace(p, near_memory_compute_Fps=1e12),
        'high_launch_100_us': replace(p, launch_us_per_layer=100.0),
        'same_bandwidth': replace(p, internal_bandwidth_Bps=3.35e12),
        'batch_32': replace(p, batch_size=32),
        'long_context_131072': replace(p, context_tokens=131072),
        'large_bank_fanout_1024': replace(p, fanout_banks=1024),
        'low_internal_bw_1_TBps': replace(p, internal_bandwidth_Bps=1e12),
    }
    # Pre-specified grid, including negative controls. No parameter tuning after reading.
    grid = []
    for ibw_TBps in (1.0, 3.35, 8.0, 16.0):
        for pim_TFps in (0.5, 1.0, 5.0, 10.0, 40.0):
            for launch_us in (0.0, 5.0, 25.0, 100.0):
                scenario = replace(p, internal_bandwidth_Bps=ibw_TBps*1e12,
                                   near_memory_compute_Fps=pim_TFps*1e12,
                                   launch_us_per_layer=launch_us)
                r = traffic_and_time(scenario)
                grid.append({'internal_TBps': ibw_TBps, 'pim_TFps': pim_TFps,
                             'launch_us_per_layer': launch_us,
                             'ratio': r['modeled_ratio_host_over_pim'],
                             'win': r['modeled_win']})
    return {
        'analysis_type': 'analytical deterministic sensitivity model; no hardware execution',
        'units': 'decimal TB/s, TFLOP/s, ms, MB, GB',
        'code_environment': {'python': platform.python_version(),
                             'machine': platform.machine(),
                             'system': platform.system()},
        'cases': {name: traffic_and_time(params) for name, params in cases.items()},
        'grid_80_cases': grid,
        'grid_win_count': sum(x['win'] for x in grid),
        'grid_ratio_min': min(x['ratio'] for x in grid),
        'grid_ratio_max': max(x['ratio'] for x in grid),
    }


if __name__ == '__main__':
    results = experiments()
    out = Path(__file__).resolve().parent.parent / 'results' / 'g2_near_memory_threshold.json'
    out.write_text(json.dumps(results, indent=2, sort_keys=True) + '\n')
    print('Saved:', out)
    print('Grid cases:', len(results['grid_80_cases']), 'win:', results['grid_win_count'])
    for name, c in results['cases'].items():
        print(f"{name}: {c['modeled_ratio_host_over_pim']:.4f}x, "
              f"host {c['host_roofline_ms']:.4f} ms, hypothetical PIM {c['pim_model_ms']:.4f} ms; "
              f"launch threshold {c['launch_breakeven_us_per_layer']:.2f} us/layer")
