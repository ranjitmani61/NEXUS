"""Streaming metadata correctness, fail-closed checks, boundary tests."""
import math
import numpy as np
import pytest
from g4_dynamic_kv_stream_benchmark import Cache,Metadata,certified_one_page,dense,PAGE

@pytest.mark.parametrize('mode',['box','fixed'])
@pytest.mark.parametrize('seed',[1,2,3,4])
def test_dynamic_bound_and_certicate(seed,mode):
    rng=np.random.default_rng(seed)
    n0=PAGE*2
    k=rng.normal(size=(n0+2*PAGE+1,8))
    v=rng.normal(size=k.shape)
    q=rng.normal(size=8)
    cache=Cache(k[:n0],v[:n0],len(k)); m=Metadata(cache,mode)
    for ii in range(n0,len(k)):
        cache.append(k[ii],v[ii]); m.append(cache)
        low,high,c=m.boundaries(q)
        assert sum(c)==cache.n
        for page in range(len(c)):
            score=cache.keys[page*PAGE:page*PAGE+c[page]]@q/math.sqrt(len(q))
            assert np.min(score)>=low[page]-1e-12
            assert np.max(score)<=high[page]+1e-12
        y,p,status,cert=certified_one_page(q,cache,m)
        truth=dense(q,cache)
        vmax=np.linalg.norm(cache.values[:cache.n],axis=1).max()
        assert np.linalg.norm(y-truth)/vmax<=cert+1e-12
        assert cert<=0.02+1e-12

@pytest.mark.parametrize('mode',['box','fixed'])
def test_stale_metadata_forces_exact_fallback(mode):
    rng=np.random.default_rng(7)
    k=rng.normal(size=(PAGE,8));v=rng.normal(size=k.shape)
    cache=Cache(k,v,PAGE+1);m=Metadata(cache,mode)
    cache.append(100*rng.normal(size=8),100*rng.normal(size=8))
    q=rng.normal(size=8)
    got,p,status,cert=certified_one_page(q,cache,m)
    assert status=='stale_dense_fallback'
    assert np.allclose(got,dense(q,cache))
    assert cert==0

@pytest.mark.parametrize('mode',['box','fixed'])
def test_skipped_update_is_rejected(mode):
    rng=np.random.default_rng(3);k=rng.normal(size=(PAGE,8));v=rng.normal(size=(PAGE,8))
    cache=Cache(k,v,PAGE+2);m=Metadata(cache,mode)
    cache.append(rng.normal(size=8),rng.normal(size=8))
    cache.append(rng.normal(size=8),rng.normal(size=8))
    with pytest.raises(ValueError):m.append(cache)

@pytest.mark.parametrize('mode',['box','fixed'])
def test_zero_q_uniform_means_fallback(mode):
    k=np.zeros((2*PAGE,8));v=np.ones_like(k)
    cache=Cache(k,v,len(k));m=Metadata(cache,mode)
    out,p,status,cert=certified_one_page(np.zeros(8),cache,m)
    assert status=='bound_dense_fallback'
    assert np.allclose(out,np.ones(8))

@pytest.mark.parametrize('mode',['box','fixed'])
@pytest.mark.parametrize('initial',[1,2,31,32,33,65])
def test_vectorized_metadata_equals_streaming_reference(mode,initial):
    rng=np.random.default_rng(874+initial)
    k=rng.normal(size=(initial,8));v=rng.normal(size=(initial,8))
    batched=Cache(k,v,initial)
    metadata_fast=Metadata(batched,mode)
    from g4_dynamic_kv_stream_benchmark import Metadata as Meta
    single_cache=Cache(k[:1],v[:1],initial)
    metadata_slow=Meta(single_cache,mode)
    for i in range(1,initial):
        single_cache.append(k[i],v[i]);metadata_slow.append(single_cache)
    np.testing.assert_array_equal(metadata_fast.count,metadata_slow.count)
    q=rng.normal(size=8)
    for a,b in zip(metadata_fast.boundaries(q),metadata_slow.boundaries(q)):
        np.testing.assert_allclose(a,b,rtol=0,atol=1e-12)
